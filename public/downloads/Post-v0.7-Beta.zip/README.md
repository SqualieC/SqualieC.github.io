# Post

A lightweight Windows desktop note overlay for gaming.  
It stays on top, supports semi-transparency, can be click-through while playing, and saves plain text files.

## Run

```powershell
python post_overlay.py
```

## Double-click launch

- Double-click `Post.pyw` to open Post directly (no terminal window).
- If needed, double-click `Post.bat` as a fallback launcher.

## Quick use guide

1. Launch the app with `python post_overlay.py`.
2. Type directly into the note (it now starts in `Edit` mode by default).
3. Press `Esc` when you start gaming to switch to `Lock` (click-through) mode.
4. Press `Ctrl+Alt+N` any time to toggle back to `Edit`.
5. If input ever gets stuck, press `Ctrl+Alt+E` to force recovery to editable mode.
6. Press `Ctrl+S` to save, or use `Save As` to create a new note file.
7. Use the opacity slider to make it less visible/more visible over your game.

## Core controls

- `Ctrl+Alt+N`: Toggle `Lock` / `Edit` mode globally.
- `Ctrl+Alt+M`: Show/hide overlay globally.
- `Ctrl+Alt+E`: Force recovery back to editable mode.
- `Esc`: Lock immediately.
- `Ctrl+S`: Save.
- `Ctrl+O`: Open a note file.
- `Ctrl+Shift+C`: Insert checklist marker `- [ ]`.
- `Ctrl+Shift+X`: Toggle checklist state on current line.

## Behavior

- `Lock` mode enables click-through so it does not steal input while gaming.
- `Edit` mode allows direct typing in the note.
- Overlay is always on top and semi-transparent.
- On supported Windows builds, the native title bar is tinted to match the yellow theme.
- Notes are plain `.txt` files (easy to manage anywhere).
- App remembers size/position/opacity/last file in `post_state.json`.
- Default note file is `post_note.txt`.

## Notes

- Most games require borderless/windowed mode for overlays to appear consistently.
- If a global hotkey conflicts with other software, edit the key bindings in `post_overlay.py` inside `HotkeyListener.hotkeys`.
- If you cannot type, press `Ctrl+Alt+N` once (or click `Edit`) to leave click-through mode.

## Troubleshooting

- Theme still white:
  - Close all running overlay instances in Task Manager (`python.exe`/`pythonw.exe`).
  - Run from this folder specifically: `python .\post_overlay.py`
  - If needed, delete `post_state.json` and relaunch.
- Still cannot type:
  - Press `Ctrl+Alt+E` to force-reset input mode.
  - Click the `Edit` button once, then type in the note area.

## Hard reset sequence

1. Close all `python.exe` and `pythonw.exe` processes.
2. Delete `post_state.json`.
3. Run `python .\post_overlay.py`.
4. Confirm title shows `v0.7`.
5. Confirm the top control rows are yellow and the `Force Edit` button is visible.
