from __future__ import annotations

import ctypes
import ctypes.wintypes
import json
import threading
from pathlib import Path
from tkinter import filedialog, messagebox
import tkinter as tk


APP_DIR = Path(__file__).resolve().parent
DEFAULT_NOTE_FILE = APP_DIR / "post_note.txt"
STATE_FILE = APP_DIR / "post_state.json"
APP_NAME = "Post"
APP_VERSION = "v0.7"

WINDOW_BG = "#ffe082"
HEADER_BG = "#ffd54f"
HEADER_BG_2 = "#ffcc33"
BUTTON_BG = "#ffb300"
BUTTON_HOVER = "#ffca28"
TEXT_FG = "#2e2a00"
NOTE_BG = "#fff3a0"
NOTE_BORDER = "#e0b312"
STATUS_BG = "#f7cf48"


# Win32 constants
GWL_EXSTYLE = -20
WS_EX_LAYERED = 0x00080000
WS_EX_TRANSPARENT = 0x00000020
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOZORDER = 0x0004
SWP_FRAMECHANGED = 0x0020
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
WM_HOTKEY = 0x0312
WM_QUIT = 0x0012
DWMWA_BORDER_COLOR = 34
DWMWA_CAPTION_COLOR = 35
DWMWA_TEXT_COLOR = 36


class HotkeyListener(threading.Thread):
    def __init__(self, on_hotkey):
        super().__init__(daemon=True)
        self.on_hotkey = on_hotkey
        self.thread_id = None
        self.user32 = ctypes.windll.user32
        self.running = True

        self.hotkeys = {
            1: (MOD_CONTROL | MOD_ALT, ord("N")),  # Ctrl+Alt+N -> lock/unlock
            2: (MOD_CONTROL | MOD_ALT, ord("M")),  # Ctrl+Alt+M -> show/hide
            3: (MOD_CONTROL | MOD_ALT, ord("E")),  # Ctrl+Alt+E -> force edit recovery
        }

    def run(self):
        self.thread_id = ctypes.windll.kernel32.GetCurrentThreadId()
        for hotkey_id, (mods, key) in self.hotkeys.items():
            self.user32.RegisterHotKey(None, hotkey_id, mods, key)

        msg = ctypes.wintypes.MSG()
        while self.running and self.user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
            if msg.message == WM_HOTKEY:
                self.on_hotkey(msg.wParam)
            self.user32.TranslateMessage(ctypes.byref(msg))
            self.user32.DispatchMessageW(ctypes.byref(msg))

        for hotkey_id in self.hotkeys:
            self.user32.UnregisterHotKey(None, hotkey_id)

    def stop(self):
        self.running = False
        if self.thread_id is not None:
            self.user32.PostThreadMessageW(self.thread_id, WM_QUIT, 0, 0)


class PostOverlay:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title(f"{APP_NAME} {APP_VERSION}")
        self.root.configure(bg=WINDOW_BG)
        self.root.attributes("-topmost", True)
        self.root.minsize(280, 140)
        self.user32 = ctypes.windll.user32

        self.current_file: Path = DEFAULT_NOTE_FILE
        self.is_locked = False
        self.is_hidden = False
        self.dirty = False
        self.edit_geometry: str | None = None
        self.edit_note_anchor: tuple[int, int] | None = None
        self.loaded_state = self._load_state()

        self._build_ui()
        self._apply_loaded_state()
        self._load_note(self.current_file)
        self._update_title()

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.bind("<Control-s>", lambda _e: self._save_note())
        self.root.bind("<Control-o>", lambda _e: self._open_note())
        self.root.bind("<Control-Shift-C>", lambda _e: self._insert_checklist_line())
        self.root.bind("<Control-Shift-X>", lambda _e: self._toggle_checklist_line())
        self.root.bind("<Escape>", lambda _e: self._set_locked(True))

        self.hotkey_listener = HotkeyListener(self._on_global_hotkey)
        self.hotkey_listener.start()
        self._autosave_loop()
        self.root.after(250, self._force_editable_startup)
        self.root.after(350, self._apply_windows_caption_theme)

    def _build_ui(self) -> None:
        self.top_row = tk.Frame(self.root, bg=HEADER_BG)
        self.top_row.pack(fill="x", padx=8, pady=(8, 2))

        self.bottom_row = tk.Frame(self.root, bg=HEADER_BG_2)
        self.bottom_row.pack(fill="x", padx=8, pady=(0, 6))

        btn_kwargs = {
            "bg": BUTTON_BG,
            "fg": TEXT_FG,
            "activebackground": BUTTON_HOVER,
            "activeforeground": TEXT_FG,
            "relief": "flat",
            "bd": 0,
            "padx": 10,
            "pady": 4,
            "font": ("Segoe UI", 9, "bold"),
            "cursor": "hand2",
        }

        self.lock_btn = tk.Button(self.top_row, text="Lock", command=lambda: self._set_locked(True), **btn_kwargs)
        self.lock_btn.pack(side="left", padx=(6, 2), pady=4)
        self.edit_btn = tk.Button(self.top_row, text="Edit", command=lambda: self._set_locked(False), **btn_kwargs)
        self.edit_btn.pack(side="left", padx=2, pady=4)
        self.force_btn = tk.Button(self.top_row, text="Force Edit", command=self._force_input_recovery, **btn_kwargs)
        self.force_btn.pack(side="left", padx=(2, 10), pady=4)

        alpha_frame = tk.Frame(self.top_row, bg=HEADER_BG)
        alpha_frame.pack(side="right", padx=8)
        tk.Label(alpha_frame, text="Opacity", bg=HEADER_BG, fg=TEXT_FG, font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 6))
        self.alpha_scale = tk.Scale(
            alpha_frame,
            from_=30,
            to=100,
            orient="horizontal",
            length=120,
            showvalue=False,
            command=self._on_alpha_change,
            bg=HEADER_BG,
            troughcolor="#ddb100",
            fg=TEXT_FG,
            highlightthickness=0,
            bd=0,
        )
        self.alpha_scale.pack(side="right", pady=4)

        tk.Button(self.bottom_row, text="Open", command=self._open_note, **btn_kwargs).pack(side="left", padx=(6, 2), pady=4)
        tk.Button(self.bottom_row, text="Save", command=self._save_note, **btn_kwargs).pack(side="left", padx=2, pady=4)
        tk.Button(self.bottom_row, text="Save As", command=self._save_note_as, **btn_kwargs).pack(side="left", padx=2, pady=4)
        tk.Button(self.bottom_row, text="Checklist +", command=self._insert_checklist_line, **btn_kwargs).pack(side="left", padx=(10, 2), pady=4)
        tk.Button(self.bottom_row, text="Toggle Check", command=self._toggle_checklist_line, **btn_kwargs).pack(side="left", padx=2, pady=4)

        note_shell = tk.Frame(self.root, bg=NOTE_BORDER, bd=0, highlightthickness=0)
        note_shell.pack(fill="both", expand=True, padx=8, pady=(0, 6))
        self.note_shell = note_shell

        text_frame = tk.Frame(note_shell, bg=NOTE_BG, bd=0, highlightthickness=0)
        text_frame.pack(fill="both", expand=True, padx=1, pady=1)

        self.text = tk.Text(
            text_frame,
            wrap="word",
            undo=True,
            font=("Segoe UI", 12),
            bg=NOTE_BG,
            fg=TEXT_FG,
            insertbackground=TEXT_FG,
            relief="flat",
            padx=10,
            pady=8,
            highlightthickness=0,
            bd=0,
        )
        self.text.pack(side="left", fill="both", expand=True)
        self.text.bind("<<Modified>>", self._on_text_modified)
        self.text.bind("<Button-1>", lambda _e: self.text.focus_force())

        scrollbar = tk.Scrollbar(text_frame, command=self.text.yview, bg=HEADER_BG_2, activebackground=BUTTON_HOVER, relief="flat")
        scrollbar.pack(side="right", fill="y")
        self.text.configure(yscrollcommand=scrollbar.set)

        self.status = tk.Label(
            self.root,
            bg=STATUS_BG,
            fg=TEXT_FG,
            anchor="w",
            font=("Segoe UI", 9),
            text=f"{APP_VERSION} | Ctrl+Alt+N Lock/Edit | Ctrl+Alt+M Show/Hide | Ctrl+Alt+E Force Edit",
        )
        self.status.pack(fill="x", padx=8, pady=(0, 8))

    def _load_state(self) -> dict:
        if not STATE_FILE.exists():
            return {}
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def _save_state(self) -> None:
        payload = {
            "geometry": self.root.geometry(),
            "opacity": self.alpha_scale.get(),
            "current_file": str(self.current_file),
            "locked": self.is_locked,
        }
        try:
            STATE_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except OSError:
            pass

    def _apply_loaded_state(self) -> None:
        geometry = self.loaded_state.get("geometry")
        if geometry:
            self.root.geometry(geometry)
        else:
            width = 390
            height = 250
            x = 40
            y = max(40, self.root.winfo_screenheight() - height - 80)
            self.root.geometry(f"{width}x{height}+{x}+{y}")

        opacity = int(self.loaded_state.get("opacity", 92))
        opacity = min(100, max(30, opacity))
        self.alpha_scale.set(opacity)
        self.root.attributes("-alpha", opacity / 100)

        file_candidate = self.loaded_state.get("current_file")
        if file_candidate:
            path = Path(file_candidate)
            if path.exists():
                self.current_file = path

        # Always start editable so typing works immediately on launch.
        self.is_locked = False

    def _update_title(self) -> None:
        lock_state = "LOCKED" if self.is_locked else "EDIT"
        self.root.title(f"{APP_NAME} {APP_VERSION} [{lock_state}] - {self.current_file.name}")

    def _on_alpha_change(self, value: str) -> None:
        try:
            alpha_value = int(float(value)) / 100
        except ValueError:
            alpha_value = 1.0
        self.root.attributes("-alpha", alpha_value)
        self._save_state()

    def _on_text_modified(self, _event=None) -> None:
        self.dirty = True
        self.text.edit_modified(False)

    def _load_note(self, path: Path) -> None:
        if path.exists():
            try:
                content = path.read_text(encoding="utf-8")
            except OSError:
                content = ""
        else:
            content = (
                "- [ ] Goals\n"
                "- [ ] Ideas\n"
                "- [ ] Gameplay tips\n\n"
                "Quick shortcuts:\n"
                "Ctrl+Shift+C -> insert checklist line\n"
                "Ctrl+Shift+X -> toggle checked on current line\n"
            )
            try:
                path.write_text(content, encoding="utf-8")
            except OSError:
                pass

        self.text.delete("1.0", "end")
        self.text.insert("1.0", content)
        self.text.edit_modified(False)
        self.dirty = False

    def _save_note(self) -> None:
        try:
            self.current_file.write_text(self.text.get("1.0", "end-1c"), encoding="utf-8")
            self.dirty = False
            self.status.config(text=f"Saved: {self.current_file}")
            self._save_state()
        except OSError as exc:
            messagebox.showerror("Save failed", f"Could not save file:\n{exc}")

    def _save_note_as(self) -> None:
        picked = filedialog.asksaveasfilename(
            title="Save overlay note as",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialfile=self.current_file.name,
        )
        if not picked:
            return
        self.current_file = Path(picked)
        self._save_note()
        self._update_title()

    def _open_note(self) -> None:
        picked = filedialog.askopenfilename(
            title="Open overlay note",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
        )
        if not picked:
            return
        self.current_file = Path(picked)
        self._load_note(self.current_file)
        self.status.config(text=f"Opened: {self.current_file}")
        self._update_title()
        self._save_state()

    def _insert_checklist_line(self) -> None:
        self.text.insert("insert", "- [ ] ")
        self.text.focus_set()

    def _toggle_checklist_line(self) -> None:
        line_start = self.text.index("insert linestart")
        line_end = self.text.index("insert lineend")
        line_text = self.text.get(line_start, line_end)

        if "- [ ]" in line_text:
            line_text = line_text.replace("- [ ]", "- [x]", 1)
        elif "- [x]" in line_text:
            line_text = line_text.replace("- [x]", "- [ ]", 1)
        elif "- [X]" in line_text:
            line_text = line_text.replace("- [X]", "- [ ]", 1)
        else:
            line_text = f"- [ ] {line_text}".rstrip()

        self.text.delete(line_start, line_end)
        self.text.insert(line_start, line_text)
        self.text.focus_set()

    def _overlay_hwnd(self) -> int:
        return int(self.root.winfo_id())

    def _target_hwnd(self) -> int:
        child = self._overlay_hwnd()
        parent = int(self.user32.GetParent(child))
        return parent if parent else child

    @staticmethod
    def _hex_to_colorref(hex_color: str) -> ctypes.c_uint32:
        color = hex_color.lstrip("#")
        if len(color) != 6:
            return ctypes.c_uint32(0)
        red = int(color[0:2], 16)
        green = int(color[2:4], 16)
        blue = int(color[4:6], 16)
        return ctypes.c_uint32((blue << 16) | (green << 8) | red)

    def _apply_windows_caption_theme(self) -> None:
        try:
            hwnd = self._target_hwnd()
            dwmapi = ctypes.windll.dwmapi
            caption = self._hex_to_colorref(HEADER_BG)
            text_color = self._hex_to_colorref(TEXT_FG)
            border = self._hex_to_colorref(HEADER_BG_2)

            for attribute, value in (
                (DWMWA_CAPTION_COLOR, caption),
                (DWMWA_TEXT_COLOR, text_color),
                (DWMWA_BORDER_COLOR, border),
            ):
                dwmapi.DwmSetWindowAttribute(
                    hwnd,
                    attribute,
                    ctypes.byref(value),
                    ctypes.sizeof(value),
                )
        except Exception:
            # Older Windows builds/themes may ignore caption color customization.
            pass

    def _apply_clickthrough(self, enabled: bool) -> None:
        hwnd = self._target_hwnd()
        exstyle = int(self.user32.GetWindowLongW(hwnd, GWL_EXSTYLE))
        if enabled:
            exstyle |= WS_EX_TRANSPARENT
        else:
            exstyle &= ~WS_EX_TRANSPARENT
        self.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, exstyle)
        self.user32.SetWindowPos(
            hwnd,
            None,
            0,
            0,
            0,
            0,
            SWP_NOSIZE | SWP_NOMOVE | SWP_NOZORDER | SWP_FRAMECHANGED,
        )

    def _note_box_screen_box(self) -> tuple[int, int, int, int]:
        self.root.update_idletasks()
        return (
            int(self.note_shell.winfo_rootx()),
            int(self.note_shell.winfo_rooty()),
            int(self.note_shell.winfo_width()),
            int(self.note_shell.winfo_height()),
        )

    def _align_note_box_to(self, target_x: int, target_y: int) -> None:
        self.root.update_idletasks()
        actual_x = int(self.note_shell.winfo_rootx())
        actual_y = int(self.note_shell.winfo_rooty())
        dx = target_x - actual_x
        dy = target_y - actual_y
        if not dx and not dy:
            return
        new_x = int(self.root.winfo_x()) + dx
        new_y = int(self.root.winfo_y()) + dy
        self.root.geometry(f"+{new_x}+{new_y}")

    def _schedule_edit_anchor_alignment(self) -> None:
        if not self.edit_note_anchor:
            return
        target_x, target_y = self.edit_note_anchor

        def run_pass(remaining: int) -> None:
            self._align_note_box_to(target_x, target_y)
            if remaining > 0:
                self.root.after(35, lambda: run_pass(remaining - 1))

        self.root.after(0, lambda: run_pass(3))

    def _show_full_ui(self) -> None:
        self.root.configure(bg=WINDOW_BG)
        self.note_shell.configure(bg=NOTE_BORDER)

        self.top_row.pack_forget()
        self.bottom_row.pack_forget()
        self.note_shell.pack_forget()
        self.status.pack_forget()

        self.top_row.pack(fill="x", padx=8, pady=(8, 2))
        self.bottom_row.pack(fill="x", padx=8, pady=(0, 6))
        self.note_shell.pack(fill="both", expand=True, padx=8, pady=(0, 6))
        self.status.pack(fill="x", padx=8, pady=(0, 8))

    def _show_locked_ui(self) -> None:
        self.root.configure(bg=NOTE_BG)
        self.note_shell.configure(bg=NOTE_BG)

        self.top_row.pack_forget()
        self.bottom_row.pack_forget()
        self.status.pack_forget()
        self.note_shell.pack_forget()
        self.note_shell.pack(fill="both", expand=True, padx=0, pady=0)

    def _force_editable_startup(self) -> None:
        self.is_locked = False
        self.root.overrideredirect(False)
        self._apply_clickthrough(False)
        self._show_full_ui()
        self.root.deiconify()
        self.root.lift()
        self.text.config(state="normal")
        self.lock_btn.config(state="normal")
        self.edit_btn.config(state="disabled")
        self.text.focus_force()

    def _force_input_recovery(self) -> None:
        if bool(self.root.overrideredirect()):
            self.root.overrideredirect(False)
            if self.edit_geometry:
                self.root.geometry(self.edit_geometry)
            self._show_full_ui()
            self._schedule_edit_anchor_alignment()
            self.root.after(40, self._apply_windows_caption_theme)

        self._apply_clickthrough(False)
        self.is_locked = False
        self._show_full_ui()
        self.text.config(state="normal")
        self.lock_btn.config(state="normal")
        self.edit_btn.config(state="disabled")
        if float(self.root.attributes("-alpha")) < 0.7:
            self.alpha_scale.set(92)
            self.root.attributes("-alpha", 0.92)
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()
        self.text.focus_force()
        self._update_title()
        self.status.config(text="RECOVERED EDIT MODE. Type directly now.")

    def _set_locked(self, lock: bool, from_hotkey: bool = True) -> None:
        was_locked = self.is_locked
        self.is_locked = lock
        self.root.update_idletasks()
        if lock and not was_locked:
            box_x, box_y, box_w, box_h = self._note_box_screen_box()
            self.edit_geometry = self.root.geometry()
            self.edit_note_anchor = (box_x, box_y)
            self._show_locked_ui()
            self.root.overrideredirect(True)
            self.root.geometry(f"{box_w}x{box_h}+{box_x}+{box_y}")
            self.root.attributes("-topmost", True)

            # Window-manager moves can settle asynchronously; do two correction passes
            # so locked mode lands exactly where the edit-mode note box was.
            for _ in range(2):
                self.root.update()
                actual_x = int(self.note_shell.winfo_rootx())
                actual_y = int(self.note_shell.winfo_rooty())
                dx = box_x - actual_x
                dy = box_y - actual_y
                if not dx and not dy:
                    break
                fixed_x = int(self.root.winfo_rootx()) + dx
                fixed_y = int(self.root.winfo_rooty()) + dy
                self.root.geometry(f"{box_w}x{box_h}+{fixed_x}+{fixed_y}")
        elif not lock and was_locked:
            self.root.overrideredirect(False)
            if self.edit_geometry:
                self.root.geometry(self.edit_geometry)
            self._show_full_ui()
            self._schedule_edit_anchor_alignment()
            self.root.after(40, self._apply_windows_caption_theme)

        self._apply_clickthrough(lock)

        if lock:
            self.text.config(state="disabled")
            self.status.config(text="LOCKED (click-through). Press Ctrl+Alt+N to edit.")
        else:
            self.text.config(state="normal")
            self.status.config(text="EDIT MODE. Type directly. Press Esc or Ctrl+Alt+N to lock.")
            self.root.deiconify()
            self.root.lift()
            self.text.focus_force()

        self.lock_btn.config(state=("disabled" if lock else "normal"))
        self.edit_btn.config(state=("normal" if lock else "disabled"))
        self._update_title()
        self._save_state()
        if lock and from_hotkey:
            self._save_note()

    def _on_global_hotkey(self, hotkey_id: int) -> None:
        self.root.after(0, lambda: self._handle_hotkey_on_ui_thread(hotkey_id))

    def _handle_hotkey_on_ui_thread(self, hotkey_id: int) -> None:
        if hotkey_id == 1:
            self._set_locked(not self.is_locked)
        elif hotkey_id == 2:
            if self.is_hidden:
                self.root.deiconify()
                self.root.lift()
                self.status.config(text="Overlay shown.")
            else:
                self.root.withdraw()
            self.is_hidden = not self.is_hidden
        elif hotkey_id == 3:
            self._force_input_recovery()

    def _autosave_loop(self) -> None:
        if self.dirty and not self.is_locked:
            self._save_note()
        self.root.after(4000, self._autosave_loop)

    def _on_close(self) -> None:
        if self.dirty:
            self._save_note()
        self._save_state()
        self.hotkey_listener.stop()
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def main() -> None:
    app = PostOverlay()
    app.run()


if __name__ == "__main__":
    main()
