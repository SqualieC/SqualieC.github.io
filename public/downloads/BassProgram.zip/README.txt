BassProgram download package

This is a placeholder package currently used to verify download flow on the website.
Replace this zip with your real BassProgram build artifact when ready.
