BassProgram Core Build

This package contains the core standalone desktop app.

How to run:
1. Unzip this folder.
2. Double-click Launch-BassProgram.bat.

Note:
- Some advanced PSARC/toolchain features are not bundled in this core web package.
