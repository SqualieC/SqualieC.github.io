import math
import zlib


class PSARCError(Exception):
    pass


def _read_u32_be(f):
    data = f.read(4)
    if len(data) != 4:
        raise PSARCError("Unexpected EOF")
    return int.from_bytes(data, "big")


def _read_u40_be(f):
    data = f.read(5)
    if len(data) != 5:
        raise PSARCError("Unexpected EOF")
    return int.from_bytes(data, "big")


class PSARC:
    def __init__(self, path):
        self.path = path
        self.magic = None
        self.version = None
        self.compression_type = None
        self.data_offset = None
        self.entry_size = None
        self.file_count = None
        self.max_chunk_size = None
        self.flags = None
        self.entries = []
        self.chunk_sizes = []
        self.paths = []

        self._load()

    def _load(self):
        with open(self.path, "rb") as f:
            self.magic = f.read(4)
            if self.magic != b"PSAR":
                raise PSARCError("Not a PSARC file")
            self.version = _read_u32_be(f)
            self.compression_type = f.read(4)
            self.data_offset = _read_u32_be(f)
            self.entry_size = _read_u32_be(f)
            self.file_count = _read_u32_be(f)
            self.max_chunk_size = _read_u32_be(f)
            self.flags = _read_u32_be(f)

            if self.entry_size < 0x1E:
                raise PSARCError("Unsupported entry size")

            for _ in range(self.file_count):
                digest = f.read(16)
                chunk_index = _read_u32_be(f)
                file_size = _read_u40_be(f)
                data_offset = _read_u40_be(f)
                self.entries.append(
                    {
                        "digest": digest,
                        "chunk_index": chunk_index,
                        "file_size": file_size,
                        "data_offset": data_offset,
                    }
                )

            toc_end = 32 + self.file_count * self.entry_size
            if self.data_offset < toc_end:
                raise PSARCError("Invalid data offset")
            table_size = self.data_offset - toc_end
            table_bytes = f.read(table_size)

            def parse_sizes(width):
                if table_size % width != 0:
                    return None
                sizes = []
                for i in range(0, table_size, width):
                    raw = int.from_bytes(table_bytes[i : i + width], "big")
                    if raw == 0:
                        raw = self.max_chunk_size
                    sizes.append(raw)
                return sizes

            def required_chunks():
                if self.max_chunk_size == 0:
                    return 0
                max_idx = 0
                for e in self.entries:
                    count = int(math.ceil(e["file_size"] / self.max_chunk_size)) if e["file_size"] else 0
                    max_idx = max(max_idx, e["chunk_index"] + count)
                return max_idx

            needed = required_chunks()
            chosen = None
            for width in (3, 2, 4):
                sizes = parse_sizes(width)
                if sizes is None:
                    continue
                if len(sizes) >= needed:
                    chosen = sizes
                    break
            if chosen is None:
                raise PSARCError("Invalid chunk size table")
            self.chunk_sizes = chosen

        self.paths = self._read_manifest()

    def _read_manifest(self):
        data = self.read_file(0)
        try:
            text = data.decode("utf-8")
        except Exception:
            text = data.decode("latin-1", errors="ignore")
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        return lines

    def list_files(self):
        files = []
        for idx in range(1, self.file_count):
            path = self.paths[idx - 1] if idx - 1 < len(self.paths) else f"(file_{idx})"
            size = self.entries[idx]["file_size"]
            files.append({"index": idx, "path": path, "size": size})
        return files

    def read_file(self, index):
        if index < 0 or index >= self.file_count:
            raise PSARCError("File index out of range")
        entry = self.entries[index]
        chunk_count = int(math.ceil(entry["file_size"] / self.max_chunk_size)) if entry["file_size"] else 0
        if chunk_count == 0:
            return b""

        out = bytearray()
        with open(self.path, "rb") as f:
            f.seek(entry["data_offset"])
            for i in range(chunk_count):
                chunk_size = self.chunk_sizes[entry["chunk_index"] + i]
                comp = f.read(chunk_size)
                if self.compression_type == b"zlib" and chunk_size < self.max_chunk_size:
                    out.extend(zlib.decompress(comp))
                else:
                    out.extend(comp)
        return bytes(out[: entry["file_size"]])
