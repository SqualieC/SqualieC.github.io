import json
import math
import os
import queue
import random
import threading
import time
from collections import deque
from datetime import datetime
import subprocess
import shutil
import xml.etree.ElementTree as ET

import numpy as np
import sounddevice as sd
import librosa
import soundfile as sf
import psarc
from PySide6 import QtCore, QtGui, QtWidgets


class ArrowSpinStyle(QtWidgets.QProxyStyle):
    def drawPrimitive(self, element, option, painter, widget=None):
        if element in (QtWidgets.QStyle.PE_IndicatorSpinUp, QtWidgets.QStyle.PE_IndicatorSpinDown):
            painter.save()
            painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
            rect = option.rect.adjusted(2, 2, -2, -2)
            color = option.palette.color(QtGui.QPalette.Text)
            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(QtGui.QBrush(color))
            cx = rect.center().x()
            if element == QtWidgets.QStyle.PE_IndicatorSpinUp:
                points = [
                    QtCore.QPointF(cx, rect.top()),
                    QtCore.QPointF(rect.left(), rect.bottom()),
                    QtCore.QPointF(rect.right(), rect.bottom()),
                ]
            else:
                points = [
                    QtCore.QPointF(rect.left(), rect.top()),
                    QtCore.QPointF(rect.right(), rect.top()),
                    QtCore.QPointF(cx, rect.bottom()),
                ]
            painter.drawPolygon(QtGui.QPolygonF(points))
            painter.restore()
            return
        super().drawPrimitive(element, option, painter, widget)

    def drawComplexControl(self, control, option, painter, widget=None):
        if control == QtWidgets.QStyle.CC_SpinBox:
            super().drawComplexControl(control, option, painter, widget)
            painter.save()
            painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
            color = option.palette.color(QtGui.QPalette.Text)
            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(QtGui.QBrush(color))

            up_rect = self.subControlRect(control, option, QtWidgets.QStyle.SC_SpinBoxUp, widget)
            down_rect = self.subControlRect(control, option, QtWidgets.QStyle.SC_SpinBoxDown, widget)

            def draw_triangle(rect, up=True):
                r = rect.adjusted(4, 4, -4, -4)
                if r.width() <= 0 or r.height() <= 0:
                    return
                cx = r.center().x()
                if up:
                    points = [
                        QtCore.QPointF(cx, r.top()),
                        QtCore.QPointF(r.left(), r.bottom()),
                        QtCore.QPointF(r.right(), r.bottom()),
                    ]
                else:
                    points = [
                        QtCore.QPointF(r.left(), r.top()),
                        QtCore.QPointF(r.right(), r.top()),
                        QtCore.QPointF(cx, r.bottom()),
                    ]
                painter.drawPolygon(QtGui.QPolygonF(points))

            draw_triangle(up_rect, up=True)
            draw_triangle(down_rect, up=False)
            painter.restore()
            return
        super().drawComplexControl(control, option, painter, widget)

NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
MIN_MIDI = 28  # E1

BASS_TUNING = [
    ("E1", 28),
    ("A1", 33),
    ("D2", 38),
    ("G2", 43),
]

GUITAR_TUNING = [
    ("E2", 40),
    ("A2", 45),
    ("D3", 50),
    ("G3", 55),
    ("B3", 59),
    ("E4", 64),
]

MAJOR_SCALE = [0, 2, 4, 5, 7, 9, 11, 12]
NATURAL_MINOR_SCALE = [0, 2, 3, 5, 7, 8, 10, 12]
ARPEGGIOS = {
    "Major triad": [0, 4, 7, 12],
    "Minor triad": [0, 3, 7, 12],
    "Dominant 7": [0, 4, 7, 10, 12],
    "Major 7": [0, 4, 7, 11, 12],
    "Minor 7": [0, 3, 7, 10, 12],
}
INTERVALS = [
    ("m2", 1),
    ("M2", 2),
    ("m3", 3),
    ("M3", 4),
    ("P4", 5),
    ("TT", 6),
    ("P5", 7),
    ("m6", 8),
    ("M6", 9),
    ("m7", 10),
    ("M7", 11),
    ("P8", 12),
]
CHORD_TYPES = {
    "Major": [0, 4, 7],
    "Minor": [0, 3, 7],
    "Power": [0, 7],
    "Dom7": [0, 4, 7, 10],
    "Maj7": [0, 4, 7, 11],
    "Min7": [0, 3, 7, 10],
}


def midi_to_name(midi_note: int) -> str:
    name = NOTE_NAMES[midi_note % 12]
    octave = (midi_note // 12) - 1
    return f"{name}{octave}"


def midi_to_freq(midi_note: int) -> float:
    return 440.0 * (2 ** ((midi_note - 69) / 12))


def name_to_midi(name: str) -> int:
    name = name.strip().upper()
    if len(name) < 2:
        raise ValueError("Invalid note name")
    if name[1] == "#":
        note = name[:2]
        octave = int(name[2:])
    else:
        note = name[0]
        octave = int(name[1:])
    if note not in NOTE_NAMES:
        raise ValueError("Invalid note name")
    return NOTE_NAMES.index(note) + (octave + 1) * 12


def clamp_min_midi(midi_note: int) -> int:
    while midi_note < MIN_MIDI:
        midi_note += 12
    return midi_note


def build_chord_templates(selected_types):
    templates = {}
    for root in range(12):
        root_name = NOTE_NAMES[root]
        for chord_name, intervals in selected_types.items():
            vec = np.zeros(12, dtype=np.float64)
            for step in intervals:
                vec[(root + step) % 12] = 1.0
            label = f"{root_name}{chord_name if chord_name != 'Major' else ''}"
            templates[label] = vec
    return templates


def normalize_chroma(chroma: np.ndarray) -> np.ndarray:
    total = np.linalg.norm(chroma)
    if total <= 1e-8:
        return chroma
    return chroma / total


def detect_chord_from_audio(audio: np.ndarray, sr: int, templates: dict, fmin: float = 65.0) -> tuple[str | None, float]:
    if audio.size < 2048:
        return None, 0.0
    audio = audio.astype(np.float32)
    chroma = librosa.feature.chroma_cqt(y=audio, sr=sr, fmin=fmin, n_chroma=12)
    chroma_vec = np.mean(chroma, axis=1)
    chroma_vec = normalize_chroma(chroma_vec)
    if np.sum(chroma_vec) <= 1e-8:
        return None, 0.0
    best_label = None
    best_score = 0.0
    for label, template in templates.items():
        score = float(np.dot(chroma_vec, normalize_chroma(template)))
        if score > best_score:
            best_score = score
            best_label = label
    return best_label, best_score


def parse_song_xml(xml_path: str) -> dict:
    tree = ET.parse(xml_path)
    root = tree.getroot()
    title = root.findtext("title") or "Unknown"
    artist = root.findtext("artistName") or "Unknown"
    arrangement = root.findtext("arrangement") or "Unknown"
    song_length = float(root.findtext("songLength") or 0.0)
    offset = float(root.findtext("offset") or 0.0)
    start_beat = float(root.findtext("startBeat") or 0.0)

    levels = root.find("levels")
    best_level = None
    best_count = -1
    if levels is not None:
        for level in levels.findall("level"):
            notes = level.findall("notes/note")
            count = len(notes)
            difficulty = int(level.get("difficulty", "0"))
            if count > best_count or (count == best_count and best_level is not None and difficulty > int(best_level.get("difficulty", "0"))):
                best_level = level
                best_count = count

    notes_out = []
    ebeats_out = []
    if best_level is not None:
        for note in best_level.findall("notes/note"):
            time_val = float(note.get("time", "0"))
            string_val = int(note.get("string", "0"))
            fret_val = int(note.get("fret", "0"))
            sustain_val = float(note.get("sustain", "0"))
            slide_to = int(note.get("slideTo", "-1"))
            notes_out.append(
                {
                    "time": time_val,
                    "string": string_val,
                    "fret": fret_val,
                    "sustain": sustain_val,
                    "slide_to": slide_to if slide_to >= 0 else None,
                }
            )

    ebeats = root.find("ebeats")
    if ebeats is not None:
        for eb in ebeats.findall("ebeat"):
            try:
                ebeats_out.append(float(eb.get("time", "0")))
            except Exception:
                continue

    notes_out.sort(key=lambda n: n["time"])
    return {
        "title": title,
        "artist": artist,
        "arrangement": arrangement,
        "length": song_length,
        "offset": offset,
        "startBeat": start_beat,
        "notes": notes_out,
        "ebeats": ebeats_out,
    }


def freq_to_midi(freq: float, cents_offset: float) -> tuple[int, float, str]:
    if freq <= 0:
        raise ValueError("Frequency must be positive")
    midi = 69 + 12 * math.log2(freq / 440.0) - (cents_offset / 100.0)
    nearest = int(round(midi))
    cents = (midi - nearest) * 100.0
    return nearest, cents, midi_to_name(nearest)


def detect_pitch(signal: np.ndarray, sr: int, fmin: float = 30.0, fmax: float = 2000.0) -> float | None:
    if signal.size < 2:
        return None
    signal = signal.astype(np.float64)
    signal -= np.mean(signal)
    if np.max(np.abs(signal)) < 1e-4:
        return None

    window = np.hanning(len(signal))
    signal *= window

    corr = np.correlate(signal, signal, mode="full")
    corr = corr[len(corr) // 2 :]

    if corr[0] == 0:
        return None
    corr = corr / (corr[0] + 1e-12)

    min_lag = int(sr / fmax)
    max_lag = int(sr / fmin)
    max_lag = min(max_lag, len(corr) - 1)
    if min_lag >= max_lag:
        return None

    d = np.diff(corr)
    min_idx = None
    for i in range(min_lag + 1, max_lag - 1):
        if d[i - 1] < 0 and d[i] >= 0:
            min_idx = i
            break
    if min_idx is None:
        min_idx = min_lag

    segment = corr[min_idx:max_lag]
    peak = int(np.argmax(segment)) + min_idx

    if corr[peak] < 0.05:
        return None

    if 1 <= peak < len(corr) - 1:
        alpha = corr[peak - 1]
        beta = corr[peak]
        gamma = corr[peak + 1]
        denom = (alpha - 2 * beta + gamma)
        if denom != 0:
            peak = peak + 0.5 * (alpha - gamma) / denom

    freq = sr / peak
    return float(freq)


def yin_pitch(signal: np.ndarray, sr: int, fmin: float = 30.0, fmax: float = 2000.0) -> tuple[float | None, float]:
    if signal.size < 2:
        return None, 0.0
    signal = signal.astype(np.float64)
    signal -= np.mean(signal)
    if np.max(np.abs(signal)) < 1e-4:
        return None, 0.0

    window = np.hanning(len(signal))
    signal *= window

    tau_min = int(sr / fmax)
    tau_max = int(sr / fmin)
    if tau_min < 2:
        tau_min = 2
    if tau_max >= len(signal):
        tau_max = len(signal) - 1
    if tau_min >= tau_max:
        return None, 0.0

    d = np.zeros(tau_max + 1, dtype=np.float64)
    for tau in range(1, tau_max + 1):
        diff = signal[:-tau] - signal[tau:]
        d[tau] = np.dot(diff, diff)

    cmnd = np.zeros_like(d)
    cmnd[0] = 1.0
    running = 0.0
    for tau in range(1, tau_max + 1):
        running += d[tau]
        cmnd[tau] = d[tau] * tau / (running + 1e-12)

    threshold = 0.1
    candidates = np.where(cmnd[tau_min:tau_max + 1] < threshold)[0]
    if len(candidates) > 0:
        tau = int(candidates[0] + tau_min)
        while tau + 1 <= tau_max and cmnd[tau + 1] < cmnd[tau]:
            tau += 1
    else:
        tau = int(tau_min + np.argmin(cmnd[tau_min:tau_max + 1]))

    if 1 <= tau < tau_max:
        x0 = cmnd[tau - 1]
        x1 = cmnd[tau]
        x2 = cmnd[tau + 1]
        denom = (x0 - 2 * x1 + x2)
        if denom != 0:
            tau = tau + 0.5 * (x0 - x2) / denom

    freq = sr / tau
    confidence = max(0.0, min(1.0, 1.0 - float(cmnd[int(round(tau))])))
    return float(freq), confidence


class AudioEngine:
    def __init__(self):
        self.samplerate = 44100
        self.blocksize = 2048
        self.buffer_size = 8192
        self.buffer = np.zeros(self.buffer_size, dtype=np.float32)
        self.lock = threading.Lock()
        self.stream = None
        self.running = False
        self.worker = None
        self.last_freq = None
        self.last_midi = None
        self.last_cents = None
        self.last_note = None
        self.cents_offset = 0.0
        self.last_rms = 0.0
        self.last_confidence = 0.0
        self.min_rms = 0.004
        self.min_confidence = 0.6
        self.device = None
        self.stable_required = 2
        self.stable_cents = 30.0
        self._stable_midi = None
        self._stable_count = 0
        self.fmin = 30.0
        self.fmax = 2000.0
        self.analysis_size = 4096

    def start(self):
        if self.running:
            return
        if self.device is not None:
            try:
                info = sd.query_devices(self.device, "input")
                self.samplerate = int(info.get("default_samplerate", self.samplerate))
            except Exception:
                pass
        self.running = True
        self.stream = sd.InputStream(
            samplerate=self.samplerate,
            channels=1,
            blocksize=self.blocksize,
            callback=self._audio_callback,
            device=self.device,
        )
        self.stream.start()
        self.worker = threading.Thread(target=self._worker_loop, daemon=True)
        self.worker.start()

    def stop(self):
        self.running = False
        if self.stream is not None:
            self.stream.stop()
            self.stream.close()
            self.stream = None
        self._stable_midi = None
        self._stable_count = 0

    def set_device(self, device_index: int | None):
        self.device = device_index
        if self.running:
            self.stop()
            self.start()

    def get_buffer(self):
        with self.lock:
            return self.buffer.copy()

    def _audio_callback(self, indata, frames, time_info, status):
        if status:
            return
        data = indata[:, 0]
        with self.lock:
            n = len(data)
            if n >= self.buffer_size:
                self.buffer[:] = data[-self.buffer_size :]
            else:
                self.buffer[:-n] = self.buffer[n:]
                self.buffer[-n:] = data

    def _worker_loop(self):
        while self.running:
            with self.lock:
                if self.analysis_size >= self.buffer_size:
                    chunk = self.buffer.copy()
                else:
                    chunk = self.buffer[-self.analysis_size :].copy()
            rms = float(np.sqrt(np.mean(chunk * chunk)))
            self.last_rms = rms
            if rms < self.min_rms:
                self.last_freq = None
                self.last_midi = None
                self.last_cents = None
                self.last_note = None
                self.last_confidence = 0.0
                self._stable_midi = None
                self._stable_count = 0
                time.sleep(0.01)
                continue
            freq, confidence = yin_pitch(chunk, self.samplerate, fmin=self.fmin, fmax=self.fmax)
            self.last_confidence = confidence
            if freq is None or freq <= 0 or confidence < self.min_confidence:
                self.last_freq = None
                self.last_midi = None
                self.last_cents = None
                self.last_note = None
                self.last_confidence = confidence
                self._stable_midi = None
                self._stable_count = 0
            else:
                try:
                    midi, cents, name = freq_to_midi(freq, self.cents_offset)
                except ValueError:
                    self.last_freq = None
                    self.last_midi = None
                    self.last_cents = None
                    self.last_note = None
                    self.last_confidence = confidence
                    self._stable_midi = None
                    self._stable_count = 0
                else:
                    if abs(cents) <= self.stable_cents:
                        if self._stable_midi == midi:
                            self._stable_count += 1
                        else:
                            self._stable_midi = midi
                            self._stable_count = 1
                    else:
                        self._stable_midi = None
                        self._stable_count = 0

                    if self._stable_count >= self.stable_required:
                        self.last_freq = freq
                        self.last_midi = midi
                        self.last_cents = cents
                        self.last_note = name
                        self.last_confidence = confidence
                    else:
                        self.last_freq = None
                        self.last_midi = None
                        self.last_cents = None
                        self.last_note = None
                        self.last_confidence = confidence
            time.sleep(0.01)


class AudioTools:
    def __init__(self):
        self.samplerate = 44100
        self.stream = None
        self.lock = threading.Lock()
        self.metronome_on = False
        self.bpm = 90.0
        self.click_volume = 0.3
        self.tone_on = False
        self.tone_freq = 440.0
        self.tone_volume = 0.2
        self.tone_harmonic_mix = 0.4
        self.low_tone_boost_db = 6.0
        self.loudness_balance = True
        self._phase = 0.0
        self._tone_phase = 0.0
        self._samples_per_beat = int(self.samplerate * 60.0 / self.bpm)
        self._beat_sample = 0
        self._click_length = int(self.samplerate * 0.03)
        self._click_phase = -1

    def start(self):
        if self.stream is not None:
            return
        self.stream = sd.OutputStream(
            samplerate=self.samplerate,
            channels=1,
            callback=self._callback,
            blocksize=512,
        )
        self.stream.start()

    def stop(self):
        if self.stream is not None:
            self.stream.stop()
            self.stream.close()
            self.stream = None

    def set_metronome(self, enabled: bool):
        with self.lock:
            self.metronome_on = enabled
            self._beat_sample = 0
            self._click_phase = -1

    def set_bpm(self, bpm: float):
        with self.lock:
            self.bpm = max(30.0, min(240.0, bpm))
            self._samples_per_beat = int(self.samplerate * 60.0 / self.bpm)

    def set_click_volume(self, vol: float):
        with self.lock:
            self.click_volume = max(0.0, min(1.0, vol))

    def set_tone(self, enabled: bool):
        with self.lock:
            self.tone_on = enabled

    def set_tone_freq(self, freq: float):
        with self.lock:
            self.tone_freq = max(20.0, min(2000.0, freq))

    def set_tone_volume(self, vol: float):
        with self.lock:
            self.tone_volume = max(0.0, min(1.0, vol))

    def set_tone_harmonic_mix(self, mix: float):
        with self.lock:
            self.tone_harmonic_mix = max(0.0, min(1.0, mix))

    def set_low_tone_boost_db(self, db: float):
        with self.lock:
            self.low_tone_boost_db = max(0.0, min(18.0, db))

    def set_loudness_balance(self, enabled: bool):
        with self.lock:
            self.loudness_balance = enabled

    def _callback(self, outdata, frames, time_info, status):
        with self.lock:
            metronome_on = self.metronome_on
            bpm = self.bpm
            click_volume = self.click_volume
            tone_on = self.tone_on
            tone_freq = self.tone_freq
            tone_volume = self.tone_volume
            tone_harmonic_mix = self.tone_harmonic_mix
            low_tone_boost_db = self.low_tone_boost_db
            loudness_balance = self.loudness_balance
            samples_per_beat = self._samples_per_beat
            beat_sample = self._beat_sample
            click_phase = self._click_phase
            click_length = self._click_length
            tone_phase = self._tone_phase

        out = np.zeros(frames, dtype=np.float32)

        if metronome_on and samples_per_beat > 0:
            for i in range(frames):
                if beat_sample % samples_per_beat == 0:
                    click_phase = 0
                if 0 <= click_phase < click_length:
                    env = math.exp(-8.0 * click_phase / click_length)
                    out[i] += click_volume * env * math.sin(2 * math.pi * 1000.0 * (click_phase / self.samplerate))
                    click_phase += 1
                beat_sample += 1

        if tone_on:
            phase_inc = 2 * math.pi * tone_freq / self.samplerate
            # Boost low tones so perceived volume is more consistent.
            if tone_freq < 110.0 and low_tone_boost_db > 0.0:
                t = (110.0 - tone_freq) / 80.0
                t = max(0.0, min(1.0, t))
                boost_db = low_tone_boost_db * t
                boost = 10 ** (boost_db / 20.0)
            else:
                boost = 1.0
            if loudness_balance:
                # Light equal-loudness compensation (roughly inverse of Fletcher-Munson trend).
                if tone_freq < 250.0:
                    freq_boost = 1.0 + (250.0 - tone_freq) / 250.0 * 0.9
                elif tone_freq > 1000.0:
                    freq_boost = 1.0 - min(0.35, (tone_freq - 1000.0) / 2000.0 * 0.35)
                else:
                    freq_boost = 1.0
            else:
                freq_boost = 1.0
            for i in range(frames):
                base = math.sin(tone_phase)
                harm = math.sin(2 * tone_phase)
                out[i] += boost * tone_volume * (
                    (1.0 - tone_harmonic_mix) * base + tone_harmonic_mix * harm
                ) * freq_boost
                tone_phase += phase_inc
                if tone_phase > 2 * math.pi:
                    tone_phase -= 2 * math.pi

        outdata[:] = np.clip(out, -1.0, 1.0).reshape(-1, 1)

        with self.lock:
            self._beat_sample = beat_sample
            self._click_phase = click_phase
            self._tone_phase = tone_phase


class SfzRegion:
    def __init__(self, sample_path: str, lokey: int, hikey: int, pitch_keycenter: int | None):
        self.sample_path = sample_path
        self.lokey = lokey
        self.hikey = hikey
        self.pitch_keycenter = pitch_keycenter

    def matches(self, midi_note: int) -> bool:
        return self.lokey <= midi_note <= self.hikey

    def base_key(self) -> int:
        if self.pitch_keycenter is not None:
            return self.pitch_keycenter
        return int((self.lokey + self.hikey) / 2)


class SfzMapSampler:
    def __init__(self, target_sr: int = 44100):
        self.target_sr = target_sr
        self.map_path = ""
        self.regions: list[SfzRegion] = []
        self._sample_cache: dict[str, tuple[np.ndarray, int]] = {}
        self.last_error = ""
        self._lock = threading.Lock()
        self.attack_s = 0.01
        self.decay_s = 0.05
        self.sustain_level = 0.8
        self.release_s = 0.08
        self.enable_loop = True
        self.loop_fade_s = 0.03
        self.lowpass_enabled = True
        self.harmonics_enabled = True
        self.harmonics_mix = 0.08
        self.harmonics_count = 3

    def load_map(self, map_path: str) -> bool:
        self.last_error = ""
        self.map_path = map_path or ""
        self.regions = []
        self._sample_cache.clear()
        if not map_path or not os.path.exists(map_path):
            self.last_error = "SFZ map not found."
            return False
        try:
            self.regions = self._parse_map(map_path)
        except Exception as exc:
            self.last_error = f"SFZ map parse error: {exc}"
            self.regions = []
            return False
        if not self.regions:
            self.last_error = "SFZ map has no playable regions."
            return False
        return True

    def is_ready(self) -> bool:
        return bool(self.regions)

    def play_midi(self, midi_note: int, duration: float = 1.0):
        if not self.is_ready():
            return
        thread = threading.Thread(target=self._render_and_play, args=(midi_note, duration), daemon=True)
        thread.start()

    def _render_and_play(self, midi_note: int, duration: float):
        region = self._select_region(midi_note)
        if region is None:
            self.last_error = "No matching SFZ region."
            return
        audio, sr = self._load_sample(region.sample_path)
        if audio is None:
            self.last_error = "Sample load failed."
            return
        base_key = region.base_key()
        play_sr = self.target_sr
        resample_after_shift = True
        if midi_note != base_key:
            steps = midi_note - base_key
            # Large downshifts on bass samples can sound choppy with phase vocoding.
            # For those, use a resample-only shift (changes duration a bit, but is cleaner).
            use_resample_shift = steps <= -4
            if use_resample_shift:
                try:
                    ratio = 2 ** (steps / 12)
                    shift_sr = int(round(self.target_sr / ratio))
                    shift_sr = max(8000, min(192000, shift_sr))
                    audio = librosa.resample(audio, orig_sr=sr, target_sr=shift_sr)
                    sr = shift_sr
                    resample_after_shift = False
                except Exception:
                    self.last_error = "Pitch shift failed; using unshifted sample."
            else:
                try:
                    audio = librosa.effects.pitch_shift(audio, sr=sr, n_steps=steps)
                except Exception:
                    # Fall back to unshifted sample so we still hear something.
                    self.last_error = "Pitch shift failed; using unshifted sample."
        if resample_after_shift and sr != play_sr:
            try:
                # Resample to the playback rate only if we didn't already do a resample-only shift.
                audio = librosa.resample(audio, orig_sr=sr, target_sr=play_sr)
                sr = play_sr
            except Exception:
                self.last_error = "Resample failed; using original sample rate."
        if duration > 0:
            max_len = int(play_sr * duration)
            if len(audio) > max_len:
                audio = audio[:max_len]
            elif self.enable_loop and len(audio) > 0 and len(audio) < max_len:
                audio = self._loop_extend(audio, play_sr, max_len)
        if self.lowpass_enabled:
            audio = self._lowpass_if_needed(audio, midi_note, play_sr)
        if self.harmonics_enabled and self.harmonics_mix > 0.0:
            audio = self._add_harmonic_layer(audio, midi_note, play_sr)
        audio = self._normalize(audio)
        audio = self._apply_envelope(audio, play_sr)
        audio = self._apply_fade(audio, play_sr)
        try:
            sd.stop()
            sd.play(audio, play_sr, blocking=False)
        except Exception:
            pass

    def _apply_fade(self, audio: np.ndarray, sr: int) -> np.ndarray:
        if audio.size == 0:
            return audio
        fade_len = int(sr * 0.01)
        fade_len = max(1, min(fade_len, audio.size // 2))
        fade_in = np.linspace(0.0, 1.0, fade_len)
        fade_out = np.linspace(1.0, 0.0, fade_len)
        audio[:fade_len] *= fade_in
        audio[-fade_len:] *= fade_out
        return audio

    def _apply_envelope(self, audio: np.ndarray, sr: int) -> np.ndarray:
        if audio.size == 0:
            return audio
        n = audio.size
        a = int(self.attack_s * sr)
        d = int(self.decay_s * sr)
        r = int(self.release_s * sr)
        sustain_len = n - (a + d + r)
        if sustain_len < 0:
            # Scale segments to fit.
            total = max(1, a + d + r)
            scale = n / total
            a = int(a * scale)
            d = int(d * scale)
            r = n - (a + d)
            sustain_len = 0
        env = np.ones(n, dtype=np.float32) * self.sustain_level
        idx = 0
        if a > 0:
            env[:a] = np.linspace(0.0, 1.0, a, dtype=np.float32)
            idx = a
        if d > 0:
            env[idx:idx + d] = np.linspace(1.0, self.sustain_level, d, dtype=np.float32)
            idx += d
        if sustain_len > 0:
            env[idx:idx + sustain_len] = self.sustain_level
            idx += sustain_len
        if r > 0 and idx < n:
            env[idx:] = np.linspace(self.sustain_level, 0.0, n - idx, dtype=np.float32)
        return audio * env

    def _lowpass_if_needed(self, audio: np.ndarray, midi_note: int, sr: int) -> np.ndarray:
        if audio.size == 0:
            return audio
        if midi_note > 40:
            return audio
        # Simple one-pole low-pass to tame jagged harmonics on very low notes.
        cutoff = 220.0 + (midi_note - 28) * 6.0
        cutoff = max(120.0, min(500.0, cutoff))
        alpha = cutoff / (cutoff + sr / (2 * math.pi))
        out = np.empty_like(audio)
        y = 0.0
        for i, x in enumerate(audio):
            y = alpha * x + (1.0 - alpha) * y
            out[i] = y
        return out

    def _add_harmonic_layer(self, audio: np.ndarray, midi_note: int, sr: int) -> np.ndarray:
        if audio.size == 0:
            return audio
        freq = midi_to_freq(midi_note)
        if freq <= 0:
            return audio
        rms = float(np.sqrt(np.mean(audio * audio)))
        if rms <= 1e-6:
            return audio
        n = audio.size
        t = np.arange(n, dtype=np.float32) / float(sr)
        harm = np.zeros(n, dtype=np.float32)
        for idx in range(self.harmonics_count):
            h = idx + 2
            amp = 1.0 / (h ** 1.3)
            harm += amp * np.sin(2.0 * math.pi * freq * h * t)
        peak = float(np.max(np.abs(harm)))
        if peak > 1e-6:
            harm *= (1.0 / peak)
        return audio + harm * rms * self.harmonics_mix

    def _loop_extend(self, audio: np.ndarray, sr: int, target_len: int) -> np.ndarray:
        if audio.size == 0 or target_len <= audio.size:
            return audio
        loop_start = int(audio.size * 0.25)
        loop_end = int(audio.size * 0.85)
        if loop_end - loop_start < int(sr * 0.05):
            return audio
        segment = audio[loop_start:loop_end]
        if segment.size == 0:
            return audio
        fade_len = int(sr * self.loop_fade_s)
        fade_len = max(1, min(fade_len, segment.size // 2))
        extended = audio.copy()
        while extended.size < target_len:
            need = target_len - extended.size
            chunk = segment[: min(need, segment.size)]
            if extended.size >= fade_len:
                xf = min(fade_len, chunk.size)
                if xf > 0:
                    fade_in = np.linspace(0.0, 1.0, xf, dtype=np.float32)
                    fade_out = 1.0 - fade_in
                    extended[-xf:] = extended[-xf:] * fade_out + chunk[:xf] * fade_in
                    chunk = chunk[xf:]
            if chunk.size > 0:
                extended = np.concatenate([extended, chunk])
        return extended[:target_len]

    def _normalize(self, audio: np.ndarray) -> np.ndarray:
        if audio.size == 0:
            return audio
        peak = float(np.max(np.abs(audio)))
        if peak <= 1e-6:
            return audio
        target = 0.8
        gain = min(5.0, target / peak)
        return audio * gain

    def _load_sample(self, path: str) -> tuple[np.ndarray | None, int | None]:
        with self._lock:
            if path in self._sample_cache:
                return self._sample_cache[path]
        try:
            data, sr = sf.read(path, dtype="float32")
        except Exception:
            self.last_error = f"Could not read sample: {os.path.basename(path)}"
            return None, None
        if data.ndim > 1:
            data = np.mean(data, axis=1)
        with self._lock:
            self._sample_cache[path] = (data, sr)
        return data, sr

    def _select_region(self, midi_note: int) -> SfzRegion | None:
        matches = [r for r in self.regions if r.matches(midi_note)]
        if matches:
            return random.choice(matches)
        # No direct match: choose nearest region and pitch-shift.
        return min(self.regions, key=lambda r: abs(midi_note - r.base_key()))

    def _parse_map(self, map_path: str) -> list[SfzRegion]:
        regions: list[SfzRegion] = []
        current: dict[str, str] | None = None
        base_dir = os.path.dirname(map_path)
        with open(map_path, "r", encoding="utf-8", errors="ignore") as f:
            for raw in f:
                line = raw.strip()
                if not line:
                    continue
                if line.startswith("//") or line.startswith(";"):
                    continue
                if "//" in line:
                    line = line.split("//", 1)[0].strip()
                if ";" in line:
                    line = line.split(";", 1)[0].strip()
                if not line:
                    continue
                if "<region>" in line:
                    if current:
                        regions.append(self._build_region(current, base_dir))
                    current = {}
                    line = line.replace("<region>", " ").strip()
                if current is None:
                    continue
                for token in line.split():
                    if "=" not in token:
                        continue
                    key, value = token.split("=", 1)
                    current[key.strip()] = value.strip()
        if current:
            regions.append(self._build_region(current, base_dir))
        return [r for r in regions if r is not None]

    def _build_region(self, data: dict[str, str], base_dir: str) -> SfzRegion | None:
        sample = data.get("sample")
        if not sample:
            return None
        sample_path = os.path.normpath(os.path.join(base_dir, sample))
        if not os.path.exists(sample_path):
            normalized = sample.replace("\\", "/")
            if normalized.startswith("../Samples/") or normalized.startswith("..\\Samples\\"):
                tail = normalized.split("Samples/", 1)[-1]
                alt_base = os.path.normpath(os.path.join(base_dir, "..", "..", "Samples"))
                alt_path = os.path.normpath(os.path.join(alt_base, tail))
                if os.path.exists(alt_path):
                    sample_path = alt_path
        try:
            key = int(data.get("key", "-1"))
        except Exception:
            key = -1
        lokey = int(data.get("lokey", key if key >= 0 else 0))
        hikey = int(data.get("hikey", key if key >= 0 else 127))
        try:
            pitch_keycenter = int(data.get("pitch_keycenter", key if key >= 0 else -1))
        except Exception:
            pitch_keycenter = -1
        if pitch_keycenter < 0:
            pitch_keycenter = None
        return SfzRegion(sample_path, lokey, hikey, pitch_keycenter)


class FretboardWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(180)
        self._tuning = []
        self._max_fret = 12
        self._current_positions = []
        self._target_positions = []
        self._show_labels = False

    def set_state(self, tuning, max_fret, current_positions, target_positions, show_labels):
        self._tuning = tuning
        self._max_fret = max_fret
        self._current_positions = current_positions
        self._target_positions = target_positions
        self._show_labels = show_labels
        self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)

        rect = self.rect().adjusted(12, 12, -12, -12)
        if rect.width() <= 0 or rect.height() <= 0:
            return

        string_count = max(1, len(self._tuning))
        fret_count = max(1, self._max_fret)

        bg = QtGui.QColor("#1c1f24")
        painter.fillRect(self.rect(), bg)

        string_color = QtGui.QColor("#c8cbd1")
        fret_color = QtGui.QColor("#3a3f47")
        nut_color = QtGui.QColor("#e2a86f")

        for s in range(string_count):
            y = rect.top() + (rect.height() * s) / (string_count - 1 if string_count > 1 else 1)
            pen = QtGui.QPen(string_color)
            pen.setWidth(2)
            painter.setPen(pen)
            painter.drawLine(rect.left(), int(y), rect.right(), int(y))

        for f in range(fret_count + 1):
            x = rect.left() + (rect.width() * f) / fret_count
            pen = QtGui.QPen(fret_color)
            pen.setWidth(3 if f == 0 else 1)
            pen.setColor(nut_color if f == 0 else fret_color)
            painter.setPen(pen)
            painter.drawLine(int(x), rect.top(), int(x), rect.bottom())

        inlay_frets = [3, 5, 7, 9, 12, 15, 17, 19, 21, 24]
        inlay_color = QtGui.QColor("#596070")
        for fret in inlay_frets:
            if fret > fret_count:
                continue
            x = rect.left() + (rect.width() * (fret - 0.5)) / fret_count
            if fret in (12, 24):
                y1 = rect.center().y() - rect.height() * 0.26
                y2 = rect.center().y() + rect.height() * 0.26
                painter.setBrush(QtGui.QBrush(inlay_color))
                painter.setPen(QtGui.QPen(QtCore.Qt.NoPen))
                painter.drawEllipse(QtCore.QPointF(x, y1), 6, 6)
                painter.drawEllipse(QtCore.QPointF(x, y2), 6, 6)
            else:
                painter.setBrush(QtGui.QBrush(inlay_color))
                painter.setPen(QtGui.QPen(QtCore.Qt.NoPen))
                painter.drawEllipse(QtCore.QPointF(x, rect.center().y()), 6, 6)

        def draw_positions(positions, color, radius=8, text_color=QtGui.QColor("#0b0e12")):
            painter.setPen(QtGui.QPen(QtCore.Qt.NoPen))
            for entry in positions:
                if len(entry) == 4:
                    string_index, fret, label, custom_color = entry
                    painter.setBrush(QtGui.QBrush(custom_color))
                else:
                    string_index, fret, label = entry
                    painter.setBrush(QtGui.QBrush(color))
                if fret < 0 or fret > fret_count:
                    continue
                if string_count > 1:
                    y = rect.top() + (rect.height() * (string_count - 1 - string_index)) / (string_count - 1)
                else:
                    y = rect.center().y()
                x = rect.left() + (rect.width() * fret) / fret_count
                painter.drawEllipse(QtCore.QPointF(x, y), radius, radius)
                if self._show_labels and label:
                    painter.setPen(QtGui.QPen(text_color))
                    font = painter.font()
                    font.setPointSize(8)
                    font.setBold(True)
                    painter.setFont(font)
                    text_rect = QtCore.QRectF(x - 18, y - 9, 36, 18)
                    painter.drawText(text_rect, QtCore.Qt.AlignCenter, label)
                    painter.setPen(QtGui.QPen(QtCore.Qt.NoPen))

        draw_positions(self._target_positions, QtGui.QColor("#3ddc84"), radius=9)
        draw_positions(self._current_positions, QtGui.QColor("#56a3ff"), radius=7)


class SongFretboardWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(220)
        self._lane_count = 4
        self._notes = []
        self._progress = 0.0
        self._duration = 8.0
        self._external_progress = None
        self._visible_before = 0.2
        self._visible_after = 3.0
        self._display_delay = -0.25
        self._ebeats = []
        self._palette = ["#d9534f", "#f7d14a", "#5bc0de", "#f0ad4e", "#5cb85c", "#9b59b6"]
        self._note_scale = 2.0
        self._timer = QtCore.QTimer(self)
        self._timer.setInterval(60)
        self._timer.timeout.connect(self._tick)
        self._build_demo_notes()

    def set_lane_count(self, count: int):
        self._lane_count = max(1, count)
        self._build_demo_notes()
        self.update()

    def set_palette(self, colors):
        if colors:
            self._palette = colors
        self.update()

    def set_notes(self, notes, duration=None, ebeats=None):
        self._notes = notes or []
        if duration is not None:
            self._duration = max(1.0, float(duration))
        self._ebeats = ebeats or []
        self._progress = 0.0
        self._external_progress = None
        self.update()

    def set_progress(self, value: float | None):
        self._external_progress = value
        self.update()

    def start(self):
        self._timer.start()

    def stop(self):
        self._timer.stop()
        self._progress = 0.0
        self._external_progress = None
        self.update()

    def _build_demo_notes(self):
        self._notes = []
        for i in range(8):
            lane = i % self._lane_count
            fret = 3 + (i % 6)
            time_offset = i * 1.0
            duration = 0.0 if i % 3 else 1.6
            slide_to = None
            if i % 4 == 0:
                slide_to = fret + 2
            self._notes.append((lane, fret, time_offset, duration, slide_to))

    def _tick(self):
        self._progress += 0.06
        if self._progress > self._duration:
            self._progress = 0.0
        self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
        rect = self.rect()

        grad = QtGui.QLinearGradient(rect.topLeft(), rect.bottomLeft())
        grad.setColorAt(0.0, QtGui.QColor("#0a0f1a"))
        grad.setColorAt(1.0, QtGui.QColor("#0f1626"))
        painter.fillRect(rect, grad)

        margin = 16
        bottom_reserved = 12
        grid = rect.adjusted(margin, margin, -margin, -margin - bottom_reserved)
        fret_count = 12
        painter.setPen(QtGui.QPen(QtGui.QColor("#2b3651")))
        for f in range(fret_count + 1):
            x = grid.left() + (grid.width() * f) / fret_count
            painter.drawLine(int(x), grid.top(), int(x), grid.bottom())

        # Fret inlays (place between strings to avoid overlap)
        inlay_frets = [3, 5, 7, 9, 12]
        inlay_color = QtGui.QColor("#596070")
        string_ys = [
            grid.top() + (grid.height() * (i / max(1, self._lane_count - 1)))
            for i in range(self._lane_count)
        ]
        def midpoint(a, b):
            return (a + b) / 2.0
        for fret in inlay_frets:
            if fret > fret_count:
                continue
            x = grid.left() + (grid.width() * (fret - 0.5)) / fret_count
            painter.setBrush(QtGui.QBrush(inlay_color))
            painter.setPen(QtGui.QPen(QtCore.Qt.NoPen))
            if fret == 12:
                if self._lane_count >= 4:
                    y1 = midpoint(string_ys[0], string_ys[1])
                    y2 = midpoint(string_ys[-2], string_ys[-1])
                else:
                    y1 = grid.center().y() - grid.height() * 0.18
                    y2 = grid.center().y() + grid.height() * 0.18
                painter.drawEllipse(QtCore.QPointF(x, y1), 5, 5)
                painter.drawEllipse(QtCore.QPointF(x, y2), 5, 5)
            else:
                y_mid = midpoint(string_ys[0], string_ys[-1]) if string_ys else grid.center().y()
                painter.drawEllipse(QtCore.QPointF(x, y_mid), 5, 5)

        # Fret numbers (below grid, inside widget)
        painter.setPen(QtGui.QPen(QtGui.QColor("#8b95a7")))
        font = painter.font()
        font.setPointSize(8)
        painter.setFont(font)
        for fret in [3, 5, 7, 9, 12]:
            if fret > fret_count:
                continue
            x = grid.left() + (grid.width() * (fret - 0.5)) / fret_count
            painter.drawText(QtCore.QRectF(x - 10, grid.bottom() + 2, 20, 14), QtCore.Qt.AlignCenter, str(fret))

        current_time = self._external_progress if self._external_progress is not None else self._progress
        current_time -= self._display_delay

        for i in range(self._lane_count):
            y = int(grid.top() + grid.height() * (i / max(1, self._lane_count - 1)))
            lane_color = QtGui.QColor(self._palette[(self._lane_count - 1 - i) % len(self._palette)])
            pen = QtGui.QPen(lane_color)
            pen.setWidth(2)
            painter.setPen(pen)
            painter.drawLine(grid.left(), y, grid.right(), y)

        # Notes within window: show only upcoming and just-passed notes
        window_before = 0.2
        window_after = 1.5
        windowed = [n for n in self._notes if (current_time - window_before) <= n[2] <= (current_time + window_after)]
        for (lane, fret, t, _duration, slide_to) in windowed:
            time_until = t - current_time
            scale = 1.0
            alpha = 220
            x = grid.left() + (grid.width() * (fret / fret_count))
            y = grid.top() + grid.height() * ((self._lane_count - 1 - lane) / max(1, self._lane_count - 1))
            w = 18 * scale * self._note_scale
            h = 12 * scale * self._note_scale
            rect_note = QtCore.QRectF(x - w / 2, y - h / 2, w, h)
            # Match note color to the string line (lowest string is bottom)
            color = QtGui.QColor(self._palette[lane % len(self._palette)])
            color.setAlpha(alpha)
            painter.setBrush(QtGui.QBrush(color))
            painter.setPen(QtGui.QPen(QtGui.QColor(0, 0, 0, 120)))
            painter.drawRoundedRect(rect_note, 6, 6)

            painter.setPen(QtGui.QPen(QtGui.QColor("#0b0f17")))
            font = painter.font()
            font.setPointSize(8)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(rect_note, QtCore.Qt.AlignCenter, str(fret))


class TabViewWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(320)
        self._lane_count = 4
        self._notes = []
        self._external_progress = None
        self._duration = 8.0
        self._palette = ["#d9534f", "#f7d14a", "#5bc0de", "#f0ad4e", "#5cb85c", "#9b59b6"]
        self._window_before = 1.0
        self._window_after = 8.5
        self._px_per_sec = 180.0
        self._note_size = 56.0

    def set_lane_count(self, count: int):
        self._lane_count = max(1, count)
        self.update()

    def set_palette(self, colors):
        if colors:
            self._palette = colors
        self.update()

    def set_notes(self, notes, duration=None):
        self._notes = notes or []
        if duration is not None:
            self._duration = max(1.0, float(duration))
        self.update()

    def set_progress(self, value: float | None):
        self._external_progress = value
        self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
        rect = self.rect()

        bg = QtGui.QColor("#14161a")
        painter.fillRect(rect, bg)

        margin = 16
        grid = rect.adjusted(margin, margin, -margin, -margin)
        playhead_x = grid.left() + 120

        for i in range(self._lane_count):
            y = int(grid.top() + grid.height() * (i / max(1, self._lane_count - 1)))
            pen = QtGui.QPen(QtGui.QColor("#40454f"))
            pen.setWidth(1)
            painter.setPen(pen)
            painter.drawLine(grid.left(), y, grid.right(), y)

        ph_color = QtGui.QColor("#2ecc71")
        pen = QtGui.QPen(ph_color)
        pen.setWidth(4)
        painter.setPen(pen)
        painter.drawLine(int(playhead_x), grid.top(), int(playhead_x), grid.bottom())

        current_time = self._external_progress if self._external_progress is not None else 0.0
        window_start = current_time - self._window_before
        window_end = current_time + self._window_after

        for lane, fret, t, _duration, _slide_to in self._notes:
            if t < window_start or t > window_end:
                continue
            x = playhead_x + (t - current_time) * self._px_per_sec
            y = grid.top() + grid.height() * ((self._lane_count - 1 - lane) / max(1, self._lane_count - 1))
            note_rect = QtCore.QRectF(
                x - self._note_size / 2,
                y - self._note_size / 2,
                self._note_size,
                self._note_size,
            )
            if not note_rect.intersects(grid):
                continue
            color = QtGui.QColor(self._palette[lane % len(self._palette)])
            painter.setBrush(QtGui.QBrush(color))
            painter.setPen(QtGui.QPen(QtGui.QColor("#0b0f17")))
            painter.drawRoundedRect(note_rect, 4, 4)

            painter.setPen(QtGui.QPen(QtGui.QColor("#ffffff")))
            font = painter.font()
            font.setPointSize(16)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(note_rect, QtCore.Qt.AlignCenter, str(fret))

            # Slide indicator (Songsterr-style)
            if _slide_to is not None and _slide_to >= 0:
                slide_x = playhead_x + (t - current_time) * self._px_per_sec
                target_x = slide_x + (self._px_per_sec * 0.6) * (1 if _slide_to >= fret else -1)
                line_y = y - (self._note_size / 2 + 10)
                slide_color = QtGui.QColor("#ffffff")
                slide_color.setAlpha(235)
                pen = QtGui.QPen(slide_color)
                pen.setWidth(6)
                pen.setCapStyle(QtCore.Qt.RoundCap)
                painter.setPen(pen)
                path = QtGui.QPainterPath()
                path.moveTo(slide_x, line_y)
                mid_x = (slide_x + target_x) / 2
                path.quadTo(mid_x, line_y - 18, target_x, line_y)
                painter.drawPath(path)
                # arrow head
                direction = 1 if target_x >= slide_x else -1
                head = 12
                p1 = QtCore.QPointF(target_x, line_y)
                p2 = QtCore.QPointF(target_x - direction * head, line_y - head * 0.7)
                p3 = QtCore.QPointF(target_x - direction * head, line_y + head * 0.7)
                painter.setBrush(QtGui.QBrush(slide_color))
                painter.setPen(QtGui.QPen(QtCore.Qt.NoPen))
                painter.drawPolygon(QtGui.QPolygonF([p1, p2, p3]))
                # target fret text
                painter.setPen(QtGui.QPen(QtGui.QColor("#ffffff")))
                font = painter.font()
                font.setPointSize(10)
                font.setBold(True)
                painter.setFont(font)
                txt = f"/{_slide_to}"
                painter.drawText(
                    QtCore.QRectF(target_x - 16, line_y - 30, 48, 16),
                    QtCore.Qt.AlignLeft,
                    txt,
                )


class PitchHistoryGraph(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(220)
        self._history = deque(maxlen=360)
        self._time_window = 6.0
        self._midi_center = 60.0
        self._midi_span = 24.0

    def clear(self):
        self._history.clear()
        self.update()

    def push_point(self, midi_value: float | None):
        now = time.time()
        self._history.append((now, midi_value))
        while self._history and now - self._history[0][0] > self._time_window:
            self._history.popleft()
        valid = [v for _, v in self._history if v is not None]
        if valid:
            target_center = float(np.median(valid))
            self._midi_center = 0.88 * self._midi_center + 0.12 * target_center
        self.update()

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
        rect = self.rect().adjusted(10, 10, -10, -10)
        if rect.width() < 40 or rect.height() < 40:
            return

        bg = QtGui.QColor(30, 36, 44, 235)
        painter.setPen(QtCore.Qt.NoPen)
        painter.setBrush(QtGui.QBrush(bg))
        painter.drawRoundedRect(rect, 10, 10)

        now = time.time()
        min_midi = self._midi_center - (self._midi_span / 2.0)
        max_midi = self._midi_center + (self._midi_span / 2.0)

        grid_pen = QtGui.QPen(QtGui.QColor(105, 120, 136, 110), 1)
        for i in range(int(math.floor(min_midi)), int(math.ceil(max_midi)) + 1):
            y = rect.bottom() - ((i - min_midi) / max(0.001, (max_midi - min_midi))) * rect.height()
            if y < rect.top() or y > rect.bottom():
                continue
            painter.setPen(grid_pen)
            painter.drawLine(rect.left(), y, rect.right(), y)
            if i % 12 == 0 or i % 12 == 9:
                painter.setPen(QtGui.QPen(QtGui.QColor(200, 210, 220, 180), 1))
                painter.drawText(rect.left() + 8, int(y - 2), midi_to_name(i))

        path = QtGui.QPainterPath()
        pen = QtGui.QPen(QtGui.QColor("#4fd1c5"), 2.2)
        painter.setPen(pen)
        started = False
        for ts, midi_value in self._history:
            if midi_value is None:
                started = False
                continue
            age = now - ts
            if age > self._time_window:
                continue
            x = rect.right() - (age / self._time_window) * rect.width()
            y = rect.bottom() - ((midi_value - min_midi) / max(0.001, (max_midi - min_midi))) * rect.height()
            if not started:
                path.moveTo(x, y)
                started = True
            else:
                path.lineTo(x, y)
        painter.drawPath(path)

        painter.setPen(QtGui.QPen(QtGui.QColor(210, 220, 235, 170)))
        painter.drawText(rect.adjusted(8, 6, -8, -6), QtCore.Qt.AlignTop | QtCore.Qt.AlignRight, "6s pitch history")


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("BassProgram")
        self.resize(1200, 820)

        self.engine = AudioEngine()
        self.audio_tools = AudioTools()
        self.sfz_sampler = SfzMapSampler(target_sr=self.audio_tools.samplerate)
        self.sfz_map_path = self._default_sfz_map_path()
        self.ear_playback_mode = "Tone Generator"
        self.instrument = "Bass"
        self.max_fret = 12
        self._device_map = []
        self._noise_samples = []
        self._noise_timer = None
        self._noise_until = 0.0

        self.practice_active = False
        self.practice_target_midi = None
        self.practice_target_label = None
        self.practice_target_position = None
        self.practice_score = 0
        self.practice_cooldown_until = 0.0
        self.practice_grace_until = 0.0
        self.practice_grace_seconds = 0.6
        self.practice_duration_seconds = 60
        self.practice_end_time = None
        self.practice_target_started = 0.0
        self.high_scores = self._load_scores()
        self.practice_require_position = False
        self.practice_box_enabled = False
        self.practice_box_low = 0
        self.practice_box_high = 12
        self.practice_string_lock_index = None
        self.practice_correct = 0
        self.practice_total_time = 0.0
        self.practice_history = self._load_history()
        self.practice_sets = self._load_sets()
        self.current_set_name = "All Notes"

        self.scale_active = False
        self.scale_notes = []
        self.scale_index = 0
        self.scale_cooldown_until = 0.0
        self.scale_box_enabled = False
        self.scale_box_low = 0
        self.scale_box_high = 12

        self.interval_active = False
        self.interval_target_midi = None
        self.interval_label = None
        self.interval_random = True
        self.interval_cooldown_until = 0.0

        self.arpeggio_active = False
        self.arpeggio_notes = []
        self.arpeggio_index = 0
        self.arpeggio_cooldown_until = 0.0
        self.arpeggio_box_enabled = False
        self.arpeggio_box_low = 0
        self.arpeggio_box_high = 12
        self.ear_active = False
        self.ear_target_midi = None
        self.ear_score = 0
        self.ear_cooldown_until = 0.0
        self.ear_feedback = ""
        self.ear_hide_label = False
        self.ear_hide_target = False
        self.ear_repeat_seconds = 3.0
        self.ear_last_play = 0.0
        self.sfz_octave_offset = 12
        self.ear_combo_enabled = False
        self.ear_combo_length = 3
        self.ear_combo_sequence = []
        self.ear_combo_index = 0
        self.ear_combo_attempted_notes = 0
        self.ear_combo_gap = 0.7
        self.ear_combo_note_duration = 0.6
        self.ear_combo_positions = []
        self.ear_combo_grace_until = 0.0
        self.ear_combo_last_match_time = 0.0
        self.ear_combo_last_midi = None
        self.ear_combo_last_advance_time = 0.0
        self.ear_sr_enabled = False
        self.ear_sr_intervals = [0.0, 10.0, 60.0, 300.0, 900.0, 3600.0]
        self.ear_sr_stats = self._load_ear_stats()
        self.ear_single_string = False
        self.ear_single_string_index = 0
        self.vocal_active = False
        self.vocal_target_midi = None
        self.vocal_score = 0
        self.vocal_cooldown_until = 0.0
        self.vocal_feedback = ""
        self.vocal_range_low = name_to_midi("A2")
        self.vocal_range_high = name_to_midi("E5")
        self._vocal_prev_pitch_bounds = None
        self.chord_active = False
        self.chord_last_time = 0.0
        self.chord_interval = 0.25
        self.chord_conf_threshold = 0.45
        self.chord_smooth_alpha = 0.6
        self.chord_smoothed = np.zeros(12, dtype=np.float64)
        self.chord_templates = build_chord_templates(CHORD_TYPES)
        self.tuner_window_seconds = 0.25
        self._tuner_samples = deque()
        self.show_note_labels = False
        self.presets = self._load_presets()
        self.song_audio = None
        self.song_audio_sr = None
        self.song_audio_start = None
        self.song_title = "Song Mode"
        self.song_artist = ""
        self.song_offset = 0.0
        self.song_offset_ms = -300
        self.song_library = self._load_song_library()
        self.theme_name = "Slate Glass"

        self._build_ui()
        self._update_chord_types()

        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(16)
        self.timer.timeout.connect(self._update_ui)
        self.timer.start()

        self.engine.start()
        self.audio_tools.start()

    def closeEvent(self, event):
        self.engine.stop()
        self.audio_tools.stop()
        event.accept()

    def _build_ui(self):
        self._apply_theme(self.theme_name)
        central = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(central)

        header = QtWidgets.QHBoxLayout()
        self.live_note = QtWidgets.QLabel("--")
        self.live_note.setStyleSheet("font-size: 32px; font-weight: bold;")
        self.live_freq = QtWidgets.QLabel("Hz: --")
        self.live_cents = QtWidgets.QLabel("Cents: --")
        self.live_rms = QtWidgets.QLabel("Level: --")
        self.live_conf = QtWidgets.QLabel("Conf: --")
        header.addWidget(self.live_note)
        header.addStretch(1)
        header.addWidget(self.live_freq)
        header.addWidget(self.live_cents)
        header.addWidget(self.live_rms)
        header.addWidget(self.live_conf)
        layout.addLayout(header)

        self.positions_label = QtWidgets.QLabel("Positions: --")
        layout.addWidget(self.positions_label)

        self.fretboard = FretboardWidget()
        layout.addWidget(self.fretboard)

        tabs = QtWidgets.QTabWidget()
        tabs.addTab(self._build_song_tab(), "Song")
        tabs.addTab(self._build_theory_tab(), "Theory Practice")
        tabs.addTab(self._build_ear_tab(), "Ear Training")
        tabs.addTab(self._build_tools_tab(), "Tools")
        tabs.addTab(self._build_settings_tab(), "Settings")
        layout.addWidget(tabs)

        self.setCentralWidget(central)
        self._refresh_devices()
        self._refresh_practice_string_lock()
        self._refresh_practice_sets()
        self._refresh_presets()
        self._update_tone_freq()
        self._bind_note_octave_pairs()
        self._refresh_song_library()
        self._load_sfz_map(self.sfz_map_path)

    def _build_practice_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        self.practice_target = QtWidgets.QLabel("Target: --")
        self.practice_target.setStyleSheet("font-size: 24px; font-weight: bold;")
        layout.addWidget(self.practice_target)

        self.practice_score_label = QtWidgets.QLabel("Score: 0")
        layout.addWidget(self.practice_score_label)

        self.practice_timer_label = QtWidgets.QLabel("Time: 60.0s")
        layout.addWidget(self.practice_timer_label)

        self.practice_mode_note = QtWidgets.QLabel("Mode: Note only")
        layout.addWidget(self.practice_mode_note)

        self.practice_stats_label = QtWidgets.QLabel("Stats: --")
        layout.addWidget(self.practice_stats_label)

        set_row = QtWidgets.QHBoxLayout()
        self.practice_set_combo = QtWidgets.QComboBox()
        self.practice_set_combo.currentIndexChanged.connect(self._select_practice_set)
        self.practice_set_refresh = QtWidgets.QPushButton("Refresh Sets")
        self.practice_set_refresh.clicked.connect(self._refresh_practice_sets)
        set_row.addWidget(QtWidgets.QLabel("Practice set"))
        set_row.addWidget(self.practice_set_combo, 1)
        set_row.addWidget(self.practice_set_refresh)
        layout.addLayout(set_row)

        self.practice_set_editor = QtWidgets.QPlainTextEdit()
        self.practice_set_editor.setPlaceholderText("Enter notes like: E1 A1 D2 G2 C3 F#3")
        self.practice_set_editor.setFixedHeight(70)
        layout.addWidget(self.practice_set_editor)

        set_btn_row = QtWidgets.QHBoxLayout()
        self.practice_set_name = QtWidgets.QLineEdit()
        self.practice_set_name.setPlaceholderText("Set name")
        self.practice_set_save = QtWidgets.QPushButton("Save Set")
        self.practice_set_save.clicked.connect(self._save_current_set)
        self.practice_set_load = QtWidgets.QPushButton("Load Set")
        self.practice_set_load.clicked.connect(self._load_selected_set)
        set_btn_row.addWidget(self.practice_set_name)
        set_btn_row.addWidget(self.practice_set_save)
        set_btn_row.addWidget(self.practice_set_load)
        layout.addLayout(set_btn_row)

        self.practice_position_check = QtWidgets.QCheckBox("Exact position mode (unique notes only)")
        self.practice_position_check.stateChanged.connect(self._toggle_position_mode)
        layout.addWidget(self.practice_position_check)

        box_row = QtWidgets.QHBoxLayout()
        self.practice_box_check = QtWidgets.QCheckBox("Position box (fret range)")
        self.practice_box_check.stateChanged.connect(self._toggle_box_mode)
        self.practice_box_low_spin = QtWidgets.QSpinBox()
        self.practice_box_low_spin.setRange(0, 24)
        self.practice_box_low_spin.setValue(self.practice_box_low)
        self.practice_box_low_spin.valueChanged.connect(self._set_box_range)
        self.practice_box_high_spin = QtWidgets.QSpinBox()
        self.practice_box_high_spin.setRange(0, 24)
        self.practice_box_high_spin.setValue(self.practice_box_high)
        self.practice_box_high_spin.valueChanged.connect(self._set_box_range)
        box_row.addWidget(self.practice_box_check)
        box_row.addWidget(QtWidgets.QLabel("Low"))
        box_row.addWidget(self.practice_box_low_spin)
        box_row.addWidget(QtWidgets.QLabel("High"))
        box_row.addWidget(self.practice_box_high_spin)
        layout.addLayout(box_row)

        string_row = QtWidgets.QHBoxLayout()
        self.practice_string_lock = QtWidgets.QComboBox()
        self.practice_string_lock.currentIndexChanged.connect(self._set_practice_string_lock)
        string_row.addWidget(QtWidgets.QLabel("Target string"))
        string_row.addWidget(self.practice_string_lock)
        layout.addLayout(string_row)

        self.practice_high_scores = QtWidgets.QLabel(self._high_scores_text())
        layout.addWidget(self.practice_high_scores)

        self.practice_history_label = QtWidgets.QLabel(self._history_text())
        layout.addWidget(self.practice_history_label)

        button_row = QtWidgets.QHBoxLayout()
        self.practice_start_btn = QtWidgets.QPushButton("Start")
        self.practice_start_btn.clicked.connect(self._toggle_practice)
        button_row.addWidget(self.practice_start_btn)
        layout.addLayout(button_row)

        layout.addStretch(1)
        return widget

    def _build_song_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)
        sub_tabs = QtWidgets.QTabWidget()
        sub_tabs.addTab(self._build_song_page(), "Song")
        sub_tabs.addTab(self._build_tab_tab(), "Tab View")
        layout.addWidget(sub_tabs)
        return widget

    def _build_song_page(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        header = QtWidgets.QHBoxLayout()
        self.song_title_label = QtWidgets.QLabel("Song Mode")
        self.song_title_label.setStyleSheet("font-size: 20px; font-weight: bold;")
        self.song_artist_label = QtWidgets.QLabel("--")
        self.song_artist_label.setStyleSheet("color: #9fb0c5;")
        header.addWidget(self.song_title_label)
        header.addStretch(1)
        header.addWidget(self.song_artist_label)
        layout.addLayout(header)

        self.song_fretboard = SongFretboardWidget()
        if self.instrument == "Bass":
            self.song_fretboard.set_lane_count(4)
            self.song_fretboard.set_palette(["#d9534f", "#f7d14a", "#5bc0de", "#f0ad4e"])
        else:
            self.song_fretboard.set_lane_count(6)
            self.song_fretboard.set_palette(["#d9534f", "#f7d14a", "#5bc0de", "#f0ad4e", "#5cb85c", "#9b59b6"])
        layout.addWidget(self.song_fretboard)
        layout.addSpacing(4)

        controls = QtWidgets.QHBoxLayout()
        self.song_start = QtWidgets.QPushButton("Start Demo")
        self.song_start.clicked.connect(self._toggle_song_demo)
        controls.addWidget(self.song_start)
        self.song_convert_one = QtWidgets.QPushButton("Convert PSARC -> Song (1-click)")
        self.song_convert_one.clicked.connect(self._convert_psarc_oneclick)
        controls.addWidget(self.song_convert_one)
        self.song_convert_bulk = QtWidgets.QPushButton("Bulk Convert PSARCs")
        self.song_convert_bulk.clicked.connect(self._convert_psarc_bulk)
        controls.addWidget(self.song_convert_bulk)
        layout.addLayout(controls)

        play_row = QtWidgets.QHBoxLayout()
        self.play_audio_btn = QtWidgets.QPushButton("Play + Sync")
        self.play_audio_btn.clicked.connect(self._play_audio)
        self.stop_audio_btn = QtWidgets.QPushButton("Stop Audio")
        self.stop_audio_btn.clicked.connect(self._stop_audio)
        play_row.addWidget(self.play_audio_btn)
        play_row.addWidget(self.stop_audio_btn)
        layout.addLayout(play_row)

        library_row = QtWidgets.QHBoxLayout()
        self.song_library_combo = QtWidgets.QComboBox()
        self.song_library_combo.currentIndexChanged.connect(self._load_library_selection)
        self.song_library_add = QtWidgets.QPushButton("Add Current")
        self.song_library_add.clicked.connect(self._add_current_to_library)
        self.song_library_refresh = QtWidgets.QPushButton("Refresh")
        self.song_library_refresh.clicked.connect(self._refresh_song_library)
        library_row.addWidget(QtWidgets.QLabel("Library"))
        library_row.addWidget(self.song_library_combo, 1)
        library_row.addWidget(self.song_library_add)
        library_row.addWidget(self.song_library_refresh)
        layout.addLayout(library_row)

        sync_row = QtWidgets.QHBoxLayout()
        self.offset_label = QtWidgets.QLabel("Sync Offset (ms)")
        self.offset_spin = QtWidgets.QSpinBox()
        self.offset_spin.setRange(-5000, 5000)
        self.offset_spin.setSingleStep(50)
        self.offset_spin.setValue(-300)
        self.offset_spin.valueChanged.connect(self._set_sync_offset)
        sync_row.addWidget(self.offset_label)
        sync_row.addWidget(self.offset_spin)
        self.display_delay_label = QtWidgets.QLabel("Display Delay (ms)")
        self.display_delay_spin = QtWidgets.QSpinBox()
        self.display_delay_spin.setRange(-5000, 2000)
        self.display_delay_spin.setSingleStep(50)
        self.display_delay_spin.setValue(-250)
        self.display_delay_spin.valueChanged.connect(self._set_display_delay)
        sync_row.addWidget(self.display_delay_label)
        sync_row.addWidget(self.display_delay_spin)
        layout.addLayout(sync_row)

        psarc_row = QtWidgets.QHBoxLayout()
        self.psarc_path_label = QtWidgets.QLabel("PSARC: --")
        self.psarc_load_btn = QtWidgets.QPushButton("Load PSARC")
        self.psarc_load_btn.clicked.connect(self._load_psarc)
        psarc_row.addWidget(self.psarc_path_label, 1)
        psarc_row.addWidget(self.psarc_load_btn)
        layout.addLayout(psarc_row)

        self.psarc_list = QtWidgets.QPlainTextEdit()
        self.psarc_list.setReadOnly(True)
        self.psarc_list.setPlaceholderText("Status messages will appear here...")
        self.psarc_list.setFixedHeight(90)
        layout.addWidget(self.psarc_list)

        layout.addStretch(1)
        return widget

    def _build_tab_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        header = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("Tab View")
        title.setStyleSheet("font-size: 20px; font-weight: bold;")
        self.tab_loaded_label = QtWidgets.QLabel("Loaded: --")
        self.tab_loaded_label.setStyleSheet("color: #9fb0c5;")
        header.addWidget(title)
        header.addStretch(1)
        header.addWidget(self.tab_loaded_label)
        layout.addLayout(header)

        self.tab_view = TabViewWidget()
        if self.instrument == "Bass":
            self.tab_view.set_lane_count(4)
            self.tab_view.set_palette(["#d9534f", "#f7d14a", "#5bc0de", "#f0ad4e"])
        else:
            self.tab_view.set_lane_count(6)
            self.tab_view.set_palette(["#d9534f", "#f7d14a", "#5bc0de", "#f0ad4e", "#5cb85c", "#9b59b6"])
        layout.addWidget(self.tab_view)

        tab_controls = QtWidgets.QHBoxLayout()
        self.tab_library_combo = QtWidgets.QComboBox()
        self.tab_library_combo.currentIndexChanged.connect(self._load_library_selection)
        self.tab_play_btn = QtWidgets.QPushButton("Play + Sync")
        self.tab_play_btn.clicked.connect(self._play_audio)
        self.tab_pause_btn = QtWidgets.QPushButton("Pause")
        self.tab_pause_btn.clicked.connect(self._pause_audio)
        tab_controls.addWidget(QtWidgets.QLabel("Library"))
        tab_controls.addWidget(self.tab_library_combo, 1)
        tab_controls.addWidget(self.tab_play_btn)
        tab_controls.addWidget(self.tab_pause_btn)
        layout.addLayout(tab_controls)

        layout.addStretch(1)
        return widget

    def _build_theory_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)
        sub_tabs = QtWidgets.QTabWidget()
        sub_tabs.addTab(self._build_practice_tab(), "Random Note")
        sub_tabs.addTab(self._build_scale_tab(), "Scales")
        sub_tabs.addTab(self._build_intervals_tab(), "Intervals & Arps")
        sub_tabs.addTab(self._build_chord_tab(), "Chords")
        sub_tabs.addTab(self._build_vocal_tab(), "Vocal Pitch")
        layout.addWidget(sub_tabs)
        return widget

    def _build_tools_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)
        sub_tabs = QtWidgets.QTabWidget()
        sub_tabs.addTab(self._build_audio_tab(), "Audio Tools")
        sub_tabs.addTab(self._build_tuner_tab(), "Tuner")
        layout.addWidget(sub_tabs)
        return widget

    def _build_scale_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        control_row = QtWidgets.QHBoxLayout()
        self.scale_root = QtWidgets.QComboBox()
        self.scale_root.addItems(NOTE_NAMES)
        self.scale_octave = QtWidgets.QComboBox()
        self.scale_octave.addItems([str(i) for i in range(1, 6)])
        self.scale_type = QtWidgets.QComboBox()
        self.scale_type.addItems(["Major", "Natural Minor"])
        control_row.addWidget(QtWidgets.QLabel("Root"))
        control_row.addWidget(self.scale_root)
        control_row.addWidget(QtWidgets.QLabel("Octave"))
        control_row.addWidget(self.scale_octave)
        control_row.addWidget(QtWidgets.QLabel("Type"))
        control_row.addWidget(self.scale_type)
        layout.addLayout(control_row)

        self.scale_target = QtWidgets.QLabel("Target: --")
        self.scale_target.setStyleSheet("font-size: 24px; font-weight: bold;")
        layout.addWidget(self.scale_target)

        self.scale_progress = QtWidgets.QLabel("Progress: --")
        layout.addWidget(self.scale_progress)

        self.scale_start_btn = QtWidgets.QPushButton("Start Scale")
        self.scale_start_btn.clicked.connect(self._toggle_scale)
        layout.addWidget(self.scale_start_btn)

        scale_box_row = QtWidgets.QHBoxLayout()
        self.scale_box_check = QtWidgets.QCheckBox("Position box (fret range)")
        self.scale_box_check.stateChanged.connect(self._toggle_scale_box)
        self.scale_box_low_spin = QtWidgets.QSpinBox()
        self.scale_box_low_spin.setRange(0, 24)
        self.scale_box_low_spin.setValue(self.scale_box_low)
        self.scale_box_low_spin.valueChanged.connect(self._set_scale_box_range)
        self.scale_box_high_spin = QtWidgets.QSpinBox()
        self.scale_box_high_spin.setRange(0, 24)
        self.scale_box_high_spin.setValue(self.scale_box_high)
        self.scale_box_high_spin.valueChanged.connect(self._set_scale_box_range)
        scale_box_row.addWidget(self.scale_box_check)
        scale_box_row.addWidget(QtWidgets.QLabel("Low"))
        scale_box_row.addWidget(self.scale_box_low_spin)
        scale_box_row.addWidget(QtWidgets.QLabel("High"))
        scale_box_row.addWidget(self.scale_box_high_spin)
        layout.addLayout(scale_box_row)

        layout.addStretch(1)
        return widget

    def _build_intervals_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        interval_row = QtWidgets.QHBoxLayout()
        self.interval_root = QtWidgets.QComboBox()
        self.interval_root.addItems(NOTE_NAMES)
        self.interval_octave = QtWidgets.QComboBox()
        self.interval_octave.addItems([str(i) for i in range(1, 6)])
        self.interval_type = QtWidgets.QComboBox()
        self.interval_type.addItems([name for name, _ in INTERVALS])
        interval_row.addWidget(QtWidgets.QLabel("Root"))
        interval_row.addWidget(self.interval_root)
        interval_row.addWidget(QtWidgets.QLabel("Octave"))
        interval_row.addWidget(self.interval_octave)
        interval_row.addWidget(QtWidgets.QLabel("Interval"))
        interval_row.addWidget(self.interval_type)
        layout.addLayout(interval_row)

        self.interval_random_check = QtWidgets.QCheckBox("Randomize root + interval")
        self.interval_random_check.setChecked(True)
        self.interval_random_check.stateChanged.connect(self._toggle_interval_random)
        layout.addWidget(self.interval_random_check)

        self.interval_target = QtWidgets.QLabel("Target: --")
        self.interval_target.setStyleSheet("font-size: 24px; font-weight: bold;")
        layout.addWidget(self.interval_target)

        self.interval_start_btn = QtWidgets.QPushButton("Start Interval")
        self.interval_start_btn.clicked.connect(self._toggle_interval)
        layout.addWidget(self.interval_start_btn)

        arpeggio_row = QtWidgets.QHBoxLayout()
        self.arpeggio_root = QtWidgets.QComboBox()
        self.arpeggio_root.addItems(NOTE_NAMES)
        self.arpeggio_octave = QtWidgets.QComboBox()
        self.arpeggio_octave.addItems([str(i) for i in range(1, 6)])
        self.arpeggio_type = QtWidgets.QComboBox()
        self.arpeggio_type.addItems(list(ARPEGGIOS.keys()))
        arpeggio_row.addWidget(QtWidgets.QLabel("Arpeggio root"))
        arpeggio_row.addWidget(self.arpeggio_root)
        arpeggio_row.addWidget(QtWidgets.QLabel("Octave"))
        arpeggio_row.addWidget(self.arpeggio_octave)
        arpeggio_row.addWidget(QtWidgets.QLabel("Type"))
        arpeggio_row.addWidget(self.arpeggio_type)
        layout.addLayout(arpeggio_row)

        self.arpeggio_target = QtWidgets.QLabel("Target: --")
        self.arpeggio_target.setStyleSheet("font-size: 24px; font-weight: bold;")
        layout.addWidget(self.arpeggio_target)

        self.arpeggio_progress = QtWidgets.QLabel("Progress: --")
        layout.addWidget(self.arpeggio_progress)

        self.arpeggio_start_btn = QtWidgets.QPushButton("Start Arpeggio")
        self.arpeggio_start_btn.clicked.connect(self._toggle_arpeggio)
        layout.addWidget(self.arpeggio_start_btn)

        arpeggio_box_row = QtWidgets.QHBoxLayout()
        self.arpeggio_box_check = QtWidgets.QCheckBox("Position box (fret range)")
        self.arpeggio_box_check.stateChanged.connect(self._toggle_arpeggio_box)
        self.arpeggio_box_low_spin = QtWidgets.QSpinBox()
        self.arpeggio_box_low_spin.setRange(0, 24)
        self.arpeggio_box_low_spin.setValue(self.arpeggio_box_low)
        self.arpeggio_box_low_spin.valueChanged.connect(self._set_arpeggio_box_range)
        self.arpeggio_box_high_spin = QtWidgets.QSpinBox()
        self.arpeggio_box_high_spin.setRange(0, 24)
        self.arpeggio_box_high_spin.setValue(self.arpeggio_box_high)
        self.arpeggio_box_high_spin.valueChanged.connect(self._set_arpeggio_box_range)
        arpeggio_box_row.addWidget(self.arpeggio_box_check)
        arpeggio_box_row.addWidget(QtWidgets.QLabel("Low"))
        arpeggio_box_row.addWidget(self.arpeggio_box_low_spin)
        arpeggio_box_row.addWidget(QtWidgets.QLabel("High"))
        arpeggio_box_row.addWidget(self.arpeggio_box_high_spin)
        layout.addLayout(arpeggio_box_row)

        layout.addStretch(1)
        return widget

    def _build_audio_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        met_row = QtWidgets.QHBoxLayout()
        self.metronome_check = QtWidgets.QCheckBox("Metronome")
        self.metronome_check.stateChanged.connect(self._toggle_metronome)
        self.metronome_bpm = QtWidgets.QSpinBox()
        self.metronome_bpm.setRange(30, 240)
        self.metronome_bpm.setValue(90)
        self.metronome_bpm.valueChanged.connect(self._set_metronome_bpm)
        met_row.addWidget(self.metronome_check)
        met_row.addWidget(QtWidgets.QLabel("BPM"))
        met_row.addWidget(self.metronome_bpm)
        layout.addLayout(met_row)

        met_vol_row = QtWidgets.QHBoxLayout()
        self.metronome_vol = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.metronome_vol.setRange(0, 100)
        self.metronome_vol.setValue(30)
        self.metronome_vol.valueChanged.connect(self._set_metronome_volume)
        met_vol_row.addWidget(QtWidgets.QLabel("Click volume"))
        met_vol_row.addWidget(self.metronome_vol)
        layout.addLayout(met_vol_row)

        tone_row = QtWidgets.QHBoxLayout()
        self.tone_check = QtWidgets.QCheckBox("Tone generator")
        self.tone_check.stateChanged.connect(self._toggle_tone)
        self.tone_note = QtWidgets.QComboBox()
        self.tone_note.addItems(NOTE_NAMES)
        self.tone_octave = QtWidgets.QComboBox()
        self.tone_octave.addItems([str(i) for i in range(1, 6)])
        self.tone_note.currentIndexChanged.connect(self._update_tone_freq)
        self.tone_octave.currentIndexChanged.connect(self._update_tone_freq)
        self.tone_freq_label = QtWidgets.QLabel("Freq: --")
        tone_row.addWidget(self.tone_check)
        tone_row.addWidget(self.tone_note)
        tone_row.addWidget(self.tone_octave)
        tone_row.addWidget(self.tone_freq_label)
        layout.addLayout(tone_row)

        tone_vol_row = QtWidgets.QHBoxLayout()
        self.tone_vol = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.tone_vol.setRange(0, 100)
        self.tone_vol.setValue(20)
        self.tone_vol.valueChanged.connect(self._set_tone_volume)
        tone_vol_row.addWidget(QtWidgets.QLabel("Tone volume"))
        tone_vol_row.addWidget(self.tone_vol)
        layout.addLayout(tone_vol_row)

        tone_low_row = QtWidgets.QHBoxLayout()
        self.tone_octave_boost = QtWidgets.QCheckBox("Auto-octave up for low notes")
        self.tone_octave_boost.setChecked(False)
        self.tone_octave_boost.stateChanged.connect(self._update_tone_freq)
        tone_low_row.addWidget(self.tone_octave_boost)
        layout.addLayout(tone_low_row)

        tone_harm_row = QtWidgets.QHBoxLayout()
        self.tone_harm_check = QtWidgets.QCheckBox("Add 2nd harmonic for audibility")
        self.tone_harm_check.setChecked(True)
        self.tone_harm_check.stateChanged.connect(self._update_tone_harmonic)
        tone_harm_row.addWidget(self.tone_harm_check)
        layout.addLayout(tone_harm_row)

        tone_boost_row = QtWidgets.QHBoxLayout()
        self.tone_low_boost = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.tone_low_boost.setRange(0, 18)
        self.tone_low_boost.setValue(6)
        self.tone_low_boost.valueChanged.connect(self._update_low_tone_boost)
        tone_boost_row.addWidget(QtWidgets.QLabel("Low tone boost (dB)"))
        tone_boost_row.addWidget(self.tone_low_boost)
        layout.addLayout(tone_boost_row)

        loud_row = QtWidgets.QHBoxLayout()
        self.tone_loudness_check = QtWidgets.QCheckBox("Balance loudness across range")
        self.tone_loudness_check.setChecked(True)
        self.tone_loudness_check.stateChanged.connect(self._update_loudness_balance)
        loud_row.addWidget(self.tone_loudness_check)
        layout.addLayout(loud_row)

        layout.addStretch(1)
        return widget

    def _build_ear_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        self.ear_target_label = QtWidgets.QLabel("Target: --")
        self.ear_target_label.setStyleSheet("font-size: 24px; font-weight: bold;")
        layout.addWidget(self.ear_target_label)

        hide_row = QtWidgets.QHBoxLayout()
        self.ear_hide_label_check = QtWidgets.QCheckBox("Hide target label")
        self.ear_hide_label_check.stateChanged.connect(self._toggle_ear_hide_label)
        self.ear_hide_target_check = QtWidgets.QCheckBox("Hide target on fretboard")
        self.ear_hide_target_check.stateChanged.connect(self._toggle_ear_hide_target)
        hide_row.addWidget(self.ear_hide_label_check)
        hide_row.addWidget(self.ear_hide_target_check)
        layout.addLayout(hide_row)

        self.ear_feedback_label = QtWidgets.QLabel("Feedback: --")
        layout.addWidget(self.ear_feedback_label)

        self.ear_score_label = QtWidgets.QLabel("Score: 0")
        layout.addWidget(self.ear_score_label)

        playback_row = QtWidgets.QHBoxLayout()
        self.ear_playback_combo = QtWidgets.QComboBox()
        self.ear_playback_combo.addItems(["Tone Generator", "Sampled Bass (SFZ)"])
        self.ear_playback_combo.currentIndexChanged.connect(self._set_ear_playback_mode)
        playback_row.addWidget(QtWidgets.QLabel("Playback"))
        playback_row.addWidget(self.ear_playback_combo)
        layout.addLayout(playback_row)

        mode_row = QtWidgets.QHBoxLayout()
        self.ear_sr_check = QtWidgets.QCheckBox("Spaced repetition")
        self.ear_sr_check.setChecked(False)
        self.ear_sr_check.stateChanged.connect(self._set_ear_sr_enabled)
        self.ear_sr_reset = QtWidgets.QPushButton("Reset SR")
        self.ear_sr_reset.clicked.connect(self._reset_ear_sr)
        mode_row.addWidget(self.ear_sr_check)
        mode_row.addWidget(self.ear_sr_reset)
        layout.addLayout(mode_row)

        string_row = QtWidgets.QHBoxLayout()
        self.ear_single_string_check = QtWidgets.QCheckBox("Single-string mode")
        self.ear_single_string_check.setChecked(False)
        self.ear_single_string_check.stateChanged.connect(self._set_ear_single_string)
        self.ear_string_combo = QtWidgets.QComboBox()
        self.ear_string_combo.currentIndexChanged.connect(self._set_ear_string_index)
        string_row.addWidget(self.ear_single_string_check)
        string_row.addWidget(QtWidgets.QLabel("String"))
        string_row.addWidget(self.ear_string_combo)
        layout.addLayout(string_row)

        combo_row = QtWidgets.QHBoxLayout()
        self.ear_combo_check = QtWidgets.QCheckBox("Combo mode")
        self.ear_combo_check.setChecked(False)
        self.ear_combo_check.stateChanged.connect(self._set_ear_combo_enabled)
        self.ear_combo_len = QtWidgets.QComboBox()
        self.ear_combo_len.addItems(["2", "3", "4", "5"])
        self.ear_combo_len.setCurrentText("3")
        self.ear_combo_len.currentIndexChanged.connect(self._set_ear_combo_length)
        combo_row.addWidget(self.ear_combo_check)
        combo_row.addWidget(QtWidgets.QLabel("Notes"))
        combo_row.addWidget(self.ear_combo_len)
        layout.addLayout(combo_row)

        offset_row = QtWidgets.QHBoxLayout()
        self.sfz_octave_combo = QtWidgets.QComboBox()
        self.sfz_octave_combo.addItems(["-24", "-12", "0", "+12", "+24"])
        self.sfz_octave_combo.setCurrentText("+12")
        self.sfz_octave_combo.currentIndexChanged.connect(self._set_sfz_octave_offset)
        offset_row.addWidget(QtWidgets.QLabel("Sample Octave Offset"))
        offset_row.addWidget(self.sfz_octave_combo)
        layout.addLayout(offset_row)

        harmonics_row = QtWidgets.QHBoxLayout()
        self.sfz_harmonics_check = QtWidgets.QCheckBox("Harmonic overlay")
        self.sfz_harmonics_check.setChecked(True)
        self.sfz_harmonics_check.stateChanged.connect(self._set_sfz_harmonics_enabled)
        self.sfz_harmonics_mix = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sfz_harmonics_mix.setRange(0, 20)
        self.sfz_harmonics_mix.setValue(int(self.sfz_sampler.harmonics_mix * 100))
        self.sfz_harmonics_mix.valueChanged.connect(self._set_sfz_harmonics_mix)
        harmonics_row.addWidget(self.sfz_harmonics_check)
        harmonics_row.addWidget(QtWidgets.QLabel("Mix"))
        harmonics_row.addWidget(self.sfz_harmonics_mix)
        layout.addLayout(harmonics_row)

        self.ear_sample_status = QtWidgets.QLabel("Sample map: --")
        layout.addWidget(self.ear_sample_status)

        btn_row = QtWidgets.QHBoxLayout()
        self.ear_start_btn = QtWidgets.QPushButton("Start")
        self.ear_start_btn.clicked.connect(self._toggle_ear_training)
        self.ear_play_btn = QtWidgets.QPushButton("Play Tone")
        self.ear_play_btn.clicked.connect(self._play_ear_tone)
        btn_row.addWidget(self.ear_start_btn)
        btn_row.addWidget(self.ear_play_btn)
        layout.addLayout(btn_row)

        layout.addStretch(1)
        self._refresh_ear_string_combo()
        return widget

    def _build_chord_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        self.chord_label = QtWidgets.QLabel("Chord: --")
        self.chord_label.setStyleSheet("font-size: 24px; font-weight: bold;")
        layout.addWidget(self.chord_label)

        self.chord_conf_label = QtWidgets.QLabel("Confidence: --")
        layout.addWidget(self.chord_conf_label)

        self.chord_start_btn = QtWidgets.QPushButton("Start")
        self.chord_start_btn.clicked.connect(self._toggle_chords)
        layout.addWidget(self.chord_start_btn)

        type_row = QtWidgets.QHBoxLayout()
        self.chord_type_checks = {}
        for name in ["Major", "Minor", "Power", "Dom7", "Maj7", "Min7"]:
            cb = QtWidgets.QCheckBox(name)
            cb.setChecked(name in ("Major", "Minor", "Power"))
            cb.stateChanged.connect(self._update_chord_types)
            self.chord_type_checks[name] = cb
            type_row.addWidget(cb)
        layout.addLayout(type_row)

        thresh_row = QtWidgets.QHBoxLayout()
        self.chord_thresh = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.chord_thresh.setRange(20, 80)
        self.chord_thresh.setValue(int(self.chord_conf_threshold * 100))
        self.chord_thresh.valueChanged.connect(self._update_chord_threshold)
        thresh_row.addWidget(QtWidgets.QLabel("Confidence threshold"))
        thresh_row.addWidget(self.chord_thresh)
        layout.addLayout(thresh_row)

        smooth_row = QtWidgets.QHBoxLayout()
        self.chord_smooth = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.chord_smooth.setRange(10, 90)
        self.chord_smooth.setValue(int(self.chord_smooth_alpha * 100))
        self.chord_smooth.valueChanged.connect(self._update_chord_smoothing)
        smooth_row.addWidget(QtWidgets.QLabel("Smoothing"))
        smooth_row.addWidget(self.chord_smooth)
        layout.addLayout(smooth_row)

        layout.addStretch(1)
        return widget

    def _build_tuner_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        self.tuner_label = QtWidgets.QLabel("Tune to the desired note and watch cents.")
        layout.addWidget(self.tuner_label)

        self.tuner_meter = QtWidgets.QProgressBar()
        self.tuner_meter.setRange(-50, 50)
        self.tuner_meter.setValue(0)
        self.tuner_meter.setFormat("Cents: %v")
        layout.addWidget(self.tuner_meter)

        self.tuner_status = QtWidgets.QLabel("Status: --")
        layout.addWidget(self.tuner_status)

        calib_row = QtWidgets.QHBoxLayout()
        self.calib_note = QtWidgets.QComboBox()
        self.calib_note.addItems([name for name, _ in BASS_TUNING] + [name for name, _ in GUITAR_TUNING])
        self.calib_button = QtWidgets.QPushButton("Calibrate to Note")
        self.calib_button.clicked.connect(self._calibrate)
        self.calib_reset = QtWidgets.QPushButton("Reset Calibration")
        self.calib_reset.clicked.connect(self._reset_calibration)
        calib_row.addWidget(QtWidgets.QLabel("Calibrate using"))
        calib_row.addWidget(self.calib_note)
        calib_row.addWidget(self.calib_button)
        calib_row.addWidget(self.calib_reset)
        layout.addLayout(calib_row)

        self.calib_status = QtWidgets.QLabel("Calibration offset: 0.0 cents")
        layout.addWidget(self.calib_status)

        layout.addStretch(1)
        return widget

    def _build_vocal_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        self.vocal_target_label = QtWidgets.QLabel("Target: --")
        self.vocal_target_label.setStyleSheet("font-size: 24px; font-weight: bold;")
        layout.addWidget(self.vocal_target_label)

        self.vocal_current_label = QtWidgets.QLabel("Current: --")
        self.vocal_current_label.setStyleSheet("font-size: 20px;")
        layout.addWidget(self.vocal_current_label)

        self.vocal_feedback_label = QtWidgets.QLabel("Feedback: --")
        layout.addWidget(self.vocal_feedback_label)

        self.vocal_score_label = QtWidgets.QLabel("Score: 0")
        layout.addWidget(self.vocal_score_label)

        range_row = QtWidgets.QHBoxLayout()
        self.vocal_low_note = QtWidgets.QComboBox()
        self.vocal_low_note.addItems(NOTE_NAMES)
        self.vocal_low_octave = QtWidgets.QComboBox()
        self.vocal_low_octave.addItems([str(i) for i in range(1, 7)])
        self.vocal_high_note = QtWidgets.QComboBox()
        self.vocal_high_note.addItems(NOTE_NAMES)
        self.vocal_high_octave = QtWidgets.QComboBox()
        self.vocal_high_octave.addItems([str(i) for i in range(1, 7)])
        self.vocal_low_note.setCurrentText("A")
        self.vocal_low_octave.setCurrentText("2")
        self.vocal_high_note.setCurrentText("E")
        self.vocal_high_octave.setCurrentText("5")
        self.vocal_low_note.currentIndexChanged.connect(self._set_vocal_range_low)
        self.vocal_low_octave.currentIndexChanged.connect(self._set_vocal_range_low)
        self.vocal_high_note.currentIndexChanged.connect(self._set_vocal_range_high)
        self.vocal_high_octave.currentIndexChanged.connect(self._set_vocal_range_high)
        range_row.addWidget(QtWidgets.QLabel("Range"))
        range_row.addWidget(self.vocal_low_note)
        range_row.addWidget(self.vocal_low_octave)
        range_row.addWidget(QtWidgets.QLabel("to"))
        range_row.addWidget(self.vocal_high_note)
        range_row.addWidget(self.vocal_high_octave)
        layout.addLayout(range_row)

        self.vocal_graph = PitchHistoryGraph()
        layout.addWidget(self.vocal_graph)

        btn_row = QtWidgets.QHBoxLayout()
        self.vocal_start_btn = QtWidgets.QPushButton("Start Vocal Training")
        self.vocal_start_btn.clicked.connect(self._toggle_vocal_training)
        self.vocal_new_target_btn = QtWidgets.QPushButton("New Target")
        self.vocal_new_target_btn.clicked.connect(self._new_vocal_target)
        btn_row.addWidget(self.vocal_start_btn)
        btn_row.addWidget(self.vocal_new_target_btn)
        layout.addLayout(btn_row)

        layout.addStretch(1)
        return widget

    def _build_settings_tab(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(widget)

        theme_row = QtWidgets.QHBoxLayout()
        self.theme_combo = QtWidgets.QComboBox()
        self.theme_combo.addItems(["Soft Grid", "Edge-Lite", "Slate Glass"])
        self.theme_combo.setCurrentText(self.theme_name)
        self.theme_combo.currentIndexChanged.connect(self._set_theme)
        theme_row.addWidget(QtWidgets.QLabel("Theme"))
        theme_row.addWidget(self.theme_combo)
        layout.addLayout(theme_row)

        device_row = QtWidgets.QHBoxLayout()
        self.device_combo = QtWidgets.QComboBox()
        self.device_refresh = QtWidgets.QPushButton("Refresh Devices")
        self.device_refresh.clicked.connect(self._refresh_devices)
        self.device_combo.currentIndexChanged.connect(self._set_device)
        device_row.addWidget(QtWidgets.QLabel("Input Device"))
        device_row.addWidget(self.device_combo, 1)
        device_row.addWidget(self.device_refresh)
        layout.addLayout(device_row)

        instrument_row = QtWidgets.QHBoxLayout()
        self.instrument_combo = QtWidgets.QComboBox()
        self.instrument_combo.addItems(["Bass", "Guitar"])
        self.instrument_combo.currentTextChanged.connect(self._set_instrument)
        instrument_row.addWidget(QtWidgets.QLabel("Instrument"))
        instrument_row.addWidget(self.instrument_combo)
        layout.addLayout(instrument_row)

        fret_row = QtWidgets.QHBoxLayout()
        self.max_fret_spin = QtWidgets.QSpinBox()
        self.max_fret_spin.setRange(5, 24)
        self.max_fret_spin.setValue(self.max_fret)
        self.max_fret_spin.valueChanged.connect(self._set_max_fret)
        fret_row.addWidget(QtWidgets.QLabel("Max Fret for Practice"))
        fret_row.addWidget(self.max_fret_spin)
        layout.addLayout(fret_row)

        level_row = QtWidgets.QHBoxLayout()
        self.min_rms_spin = QtWidgets.QDoubleSpinBox()
        self.min_rms_spin.setRange(0.001, 0.2)
        self.min_rms_spin.setSingleStep(0.001)
        self.min_rms_spin.setDecimals(3)
        self.min_rms_spin.setValue(self.engine.min_rms)
        self.min_rms_spin.valueChanged.connect(self._set_min_rms)
        level_row.addWidget(QtWidgets.QLabel("Min Volume (RMS)"))
        level_row.addWidget(self.min_rms_spin)
        layout.addLayout(level_row)

        conf_row = QtWidgets.QHBoxLayout()
        self.min_conf_spin = QtWidgets.QDoubleSpinBox()
        self.min_conf_spin.setRange(0.1, 0.95)
        self.min_conf_spin.setSingleStep(0.05)
        self.min_conf_spin.setDecimals(2)
        self.min_conf_spin.setValue(self.engine.min_confidence)
        self.min_conf_spin.valueChanged.connect(self._set_min_confidence)
        conf_row.addWidget(QtWidgets.QLabel("Min Confidence"))
        conf_row.addWidget(self.min_conf_spin)
        layout.addLayout(conf_row)
        auto_row = QtWidgets.QHBoxLayout()
        self.auto_noise_btn = QtWidgets.QPushButton("Auto-Calibrate Noise Floor")
        self.auto_noise_btn.clicked.connect(self._auto_calibrate_noise)
        auto_row.addWidget(self.auto_noise_btn)
        layout.addLayout(auto_row)

        hold_row = QtWidgets.QHBoxLayout()
        self.hold_frames_spin = QtWidgets.QSpinBox()
        self.hold_frames_spin.setRange(1, 8)
        self.hold_frames_spin.setValue(self.engine.stable_required)
        self.hold_frames_spin.valueChanged.connect(self._set_hold_frames)
        self.hold_cents_spin = QtWidgets.QDoubleSpinBox()
        self.hold_cents_spin.setRange(5.0, 50.0)
        self.hold_cents_spin.setSingleStep(1.0)
        self.hold_cents_spin.setDecimals(1)
        self.hold_cents_spin.setValue(self.engine.stable_cents)
        self.hold_cents_spin.valueChanged.connect(self._set_hold_cents)
        hold_row.addWidget(QtWidgets.QLabel("Note Hold (frames)"))
        hold_row.addWidget(self.hold_frames_spin)
        hold_row.addWidget(QtWidgets.QLabel("Note Hold (cents)"))
        hold_row.addWidget(self.hold_cents_spin)
        layout.addLayout(hold_row)

        label_row = QtWidgets.QHBoxLayout()
        self.show_labels_check = QtWidgets.QCheckBox("Show note labels on fretboard")
        self.show_labels_check.setChecked(self.show_note_labels)
        self.show_labels_check.stateChanged.connect(self._toggle_note_labels)
        label_row.addWidget(self.show_labels_check)
        layout.addLayout(label_row)

        sfz_row = QtWidgets.QHBoxLayout()
        self.sfz_path_edit = QtWidgets.QLineEdit()
        self.sfz_path_edit.setPlaceholderText("SFZ map file (e.g., Black-Blue-Bass/Programs/maps/...)")
        self.sfz_path_edit.setText(self.sfz_map_path)
        self.sfz_path_edit.editingFinished.connect(self._load_sfz_map_from_edit)
        self.sfz_browse_btn = QtWidgets.QPushButton("Browse SFZ Map")
        self.sfz_browse_btn.clicked.connect(self._browse_sfz_map)
        self.sfz_reload_btn = QtWidgets.QPushButton("Load SFZ Map")
        self.sfz_reload_btn.clicked.connect(self._reload_sfz_map)
        sfz_row.addWidget(QtWidgets.QLabel("Ear Training Sample Map"))
        sfz_row.addWidget(self.sfz_path_edit, 1)
        sfz_row.addWidget(self.sfz_browse_btn)
        sfz_row.addWidget(self.sfz_reload_btn)
        layout.addLayout(sfz_row)

        preset_row = QtWidgets.QHBoxLayout()
        self.preset_combo = QtWidgets.QComboBox()
        self.preset_combo.currentIndexChanged.connect(self._select_preset)
        self.preset_refresh = QtWidgets.QPushButton("Refresh Presets")
        self.preset_refresh.clicked.connect(self._refresh_presets)
        preset_row.addWidget(QtWidgets.QLabel("Preset"))
        preset_row.addWidget(self.preset_combo, 1)
        preset_row.addWidget(self.preset_refresh)
        layout.addLayout(preset_row)

        preset_btn_row = QtWidgets.QHBoxLayout()
        self.preset_name = QtWidgets.QLineEdit()
        self.preset_name.setPlaceholderText("Preset name")
        self.preset_save = QtWidgets.QPushButton("Save Preset")
        self.preset_save.clicked.connect(self._save_preset)
        self.preset_load = QtWidgets.QPushButton("Load Preset")
        self.preset_load.clicked.connect(self._load_selected_preset)
        preset_btn_row.addWidget(self.preset_name)
        preset_btn_row.addWidget(self.preset_save)
        preset_btn_row.addWidget(self.preset_load)
        layout.addLayout(preset_btn_row)

        layout.addStretch(1)
        return widget

    def _set_instrument(self, text: str):
        self.instrument = text
        if text == "Bass":
            self.engine.fmin = 30.0
            self.engine.fmax = 1200.0
        else:
            self.engine.fmin = 70.0
            self.engine.fmax = 2000.0
        if hasattr(self, "song_fretboard"):
            if text == "Bass":
                self.song_fretboard.set_lane_count(4)
                self.song_fretboard.set_palette(["#d9534f", "#f7d14a", "#5bc0de", "#f0ad4e"])
            else:
                self.song_fretboard.set_lane_count(6)
                self.song_fretboard.set_palette(["#d9534f", "#f7d14a", "#5bc0de", "#f0ad4e", "#5cb85c", "#9b59b6"])
        if hasattr(self, "tab_view"):
            if text == "Bass":
                self.tab_view.set_lane_count(4)
                self.tab_view.set_palette(["#d9534f", "#f7d14a", "#5bc0de", "#f0ad4e"])
            else:
                self.tab_view.set_lane_count(6)
                self.tab_view.set_palette(["#d9534f", "#f7d14a", "#5bc0de", "#f0ad4e", "#5cb85c", "#9b59b6"])
        self._refresh_practice_string_lock()
        self._refresh_ear_string_combo()
        if self.vocal_active:
            self.engine.fmin = 70.0
            self.engine.fmax = 1400.0
        self._update_fretboard(None)

    def _set_max_fret(self, value: int):
        self.max_fret = value
        self._update_fretboard(None)

    def _set_min_rms(self, value: float):
        self.engine.min_rms = float(value)

    def _set_min_confidence(self, value: float):
        self.engine.min_confidence = float(value)

    def _set_hold_frames(self, value: int):
        self.engine.stable_required = int(value)

    def _set_hold_cents(self, value: float):
        self.engine.stable_cents = float(value)

    def _toggle_note_labels(self):
        self.show_note_labels = self.show_labels_check.isChecked()
        self._update_fretboard(self.engine.last_midi)

    def _set_theme(self):
        if not hasattr(self, "theme_combo"):
            return
        name = self.theme_combo.currentText().strip()
        if not name:
            return
        self.theme_name = name
        self._apply_theme(name)

    def _apply_theme(self, name: str):
        themes = self._theme_styles()
        qss = themes.get(name, themes.get("Soft Grid", ""))
        if qss:
            self.setStyleSheet(qss)

    def _theme_styles(self) -> dict:
        base_dir = os.path.dirname(__file__)
        arrow_up = os.path.join(base_dir, "assets", "arrow-up.svg").replace("\\", "/")
        arrow_down = os.path.join(base_dir, "assets", "arrow-down.svg").replace("\\", "/")
        return {
            "Soft Grid": (
                "QMainWindow { background-color: #0b0f17; }"
                "QLabel { color: #e4e7ee; }"
                "QTabWidget::pane { border: 1px solid #1f2a3a; border-radius: 8px; }"
                "QTabBar::tab { background: #141b2b; color: #cbd5e1; padding: 6px 12px; border-radius: 8px; margin-right: 4px; }"
                "QTabBar::tab:selected { background: #1f2a3a; color: #ffffff; }"
                "QPushButton { background: #223049; color: #e4e7ee; padding: 6px 10px; border-radius: 8px; }"
                "QPushButton:hover { background: #2b3a57; }"
                "QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit, QPlainTextEdit {"
                " background: #121826; color: #e4e7ee; border: 1px solid #1f2a3a; border-radius: 6px; padding: 2px 6px; }"
                "QSlider::groove:horizontal { height: 6px; background: #1f2a3a; border-radius: 3px; }"
                "QSlider::handle:horizontal { width: 14px; background: #5bbf8a; margin: -4px 0; border-radius: 7px; }"
            ),
            "Edge-Lite": (
                "QMainWindow { background-color: #0a0e16; }"
                "QLabel { color: #dfe6ef; }"
                "QTabWidget::pane { border: 1px solid #222c3d; border-radius: 4px; }"
                "QTabBar::tab { background: #101726; color: #b7c3d6; padding: 6px 12px; border-radius: 5px; margin-right: 3px; }"
                "QTabBar::tab:selected { background: #1b2738; color: #ffffff; }"
                "QPushButton { background: #1f2c43; color: #e4e7ee; padding: 6px 10px; border-radius: 5px; }"
                "QPushButton:hover { background: #2b3a57; }"
                "QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit, QPlainTextEdit {"
                " background: #0f1624; color: #e4e7ee; border: 1px solid #222c3d; border-radius: 4px; padding: 2px 6px; }"
                "QSlider::groove:horizontal { height: 6px; background: #222c3d; border-radius: 3px; }"
                "QSlider::handle:horizontal { width: 14px; background: #56a3ff; margin: -4px 0; border-radius: 7px; }"
            ),
            "Slate Glass": (
                "QMainWindow { background-color: #0b111b; }"
                "QLabel { color: #e6edf7; }"
                "QTabWidget::pane { border: 1px solid #2b3a53; border-radius: 12px; background: rgba(18, 27, 45, 0.92);"
                " margin-top: 6px; padding-top: 6px; }"
                "QTabBar::base { border: none; background: transparent; margin: 0px; }"
                "QTabBar::tab { background: rgba(22, 33, 54, 0.9); color: #c7d4e6; padding: 9px 16px;"
                " border-radius: 12px; margin-right: 6px; margin-top: 2px; }"
                "QTabBar::tab:selected { background: rgba(36, 50, 75, 0.98); color: #ffffff; border: 1px solid #55e0c4; }"
                "QPushButton { background: rgba(36, 52, 79, 0.95); color: #e8f0fb; padding: 7px 12px; border-radius: 12px; border: 1px solid #2f425f; }"
                "QPushButton:hover { background: rgba(52, 72, 104, 0.98); border: 1px solid #55e0c4; }"
                "QPushButton:pressed { background: rgba(30, 44, 68, 0.98); }"
                "QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit, QPlainTextEdit {"
                " background: rgba(14, 21, 36, 0.9); color: #e6edf7; border: 1px solid #2b3a53; border-radius: 10px; padding: 3px 8px; }"
                "QComboBox { padding-right: 24px; }"
                "QComboBox::drop-down { subcontrol-origin: padding; subcontrol-position: top right; width: 22px;"
                " border-left: 1px solid #2b3a53; border-top-right-radius: 10px; border-bottom-right-radius: 10px;"
                " background: rgba(20, 30, 48, 0.95); }"
                f"QComboBox::down-arrow {{ image: url('{arrow_down}'); width: 10px; height: 6px; }}"
                "QSpinBox, QDoubleSpinBox { padding-right: 24px; }"
                "QSpinBox::up-button, QDoubleSpinBox::up-button { subcontrol-origin: border; subcontrol-position: top right; width: 16px;"
                " border: none; background: transparent; }"
                "QSpinBox::down-button, QDoubleSpinBox::down-button { subcontrol-origin: border; subcontrol-position: bottom right; width: 16px;"
                " border: none; background: transparent; }"
                f"QSpinBox::up-arrow, QDoubleSpinBox::up-arrow {{ image: url('{arrow_up}'); width: 10px; height: 6px; }}"
                f"QSpinBox::down-arrow, QDoubleSpinBox::down-arrow {{ image: url('{arrow_down}'); width: 10px; height: 6px; }}"
                "QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QLineEdit:focus, QPlainTextEdit:focus {"
                " border: 1px solid #55e0c4; }"
                "QSlider::groove:horizontal { height: 7px; background: #2b3a53; border-radius: 4px; }"
                "QSlider::sub-page:horizontal { background: #55e0c4; border-radius: 4px; }"
                "QSlider::handle:horizontal { width: 16px; background: #7af0d6; margin: -5px 0; border-radius: 8px; }"
            ),
        }

    def _set_ear_playback_mode(self):
        if hasattr(self, "ear_playback_combo"):
            self.ear_playback_mode = self.ear_playback_combo.currentText()

    def _set_ear_sr_enabled(self):
        self.ear_sr_enabled = self.ear_sr_check.isChecked() if hasattr(self, "ear_sr_check") else False
        if self.ear_active and not self.ear_combo_enabled:
            self._new_ear_target(play_tone=True)

    def _reset_ear_sr(self):
        self.ear_sr_stats = {}
        self._save_ear_stats()
        if self.ear_active and not self.ear_combo_enabled:
            self._new_ear_target(play_tone=True)

    def _set_ear_single_string(self):
        self.ear_single_string = (
            self.ear_single_string_check.isChecked() if hasattr(self, "ear_single_string_check") else False
        )
        if self.ear_active:
            self._new_ear_target(play_tone=True)

    def _set_ear_string_index(self):
        if not hasattr(self, "ear_string_combo"):
            return
        self.ear_single_string_index = max(0, self.ear_string_combo.currentIndex())
        if self.ear_active and self.ear_single_string:
            self._new_ear_target(play_tone=True)

    def _refresh_ear_string_combo(self):
        if not hasattr(self, "ear_string_combo"):
            return
        self.ear_string_combo.blockSignals(True)
        self.ear_string_combo.clear()
        for name, _midi in self._current_tuning():
            self.ear_string_combo.addItem(name)
        if self.ear_string_combo.count() > 0:
            self.ear_string_combo.setCurrentIndex(min(self.ear_single_string_index, self.ear_string_combo.count() - 1))
        self.ear_string_combo.blockSignals(False)

    def _set_ear_combo_enabled(self):
        self.ear_combo_enabled = self.ear_combo_check.isChecked() if hasattr(self, "ear_combo_check") else False
        if self.ear_active:
            self._new_ear_target(play_tone=True)

    def _set_ear_combo_length(self):
        if not hasattr(self, "ear_combo_len"):
            return
        text = self.ear_combo_len.currentText().strip()
        try:
            self.ear_combo_length = int(text)
        except Exception:
            self.ear_combo_length = 3
        if self.ear_active and self.ear_combo_enabled:
            self._new_ear_target(play_tone=True)

    def _set_sfz_octave_offset(self):
        if not hasattr(self, "sfz_octave_combo"):
            return
        text = self.sfz_octave_combo.currentText().strip()
        try:
            self.sfz_octave_offset = int(text)
        except Exception:
            self.sfz_octave_offset = 12

    def _set_sfz_harmonics_enabled(self):
        enabled = self.sfz_harmonics_check.isChecked() if hasattr(self, "sfz_harmonics_check") else True
        self.sfz_sampler.harmonics_enabled = bool(enabled)

    def _set_sfz_harmonics_mix(self, value: int):
        mix = max(0.0, min(0.2, float(value) / 100.0))
        self.sfz_sampler.harmonics_mix = mix

    def _ear_stats_path(self):
        return os.path.join(os.path.dirname(__file__), "ear_stats.json")

    def _load_ear_stats(self):
        path = self._ear_stats_path()
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
        except Exception:
            pass
        return {}

    def _save_ear_stats(self):
        path = self._ear_stats_path()
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.ear_sr_stats, f)
        except Exception:
            pass

    def _default_sfz_map_path(self) -> str:
        base = os.path.join(os.path.dirname(__file__), "Black-Blue-Bass", "Programs", "maps", "babyblue_reg_f_map.sfz")
        if os.path.exists(base):
            return base
        return ""

    def _load_sfz_map_from_edit(self):
        path = self.sfz_path_edit.text().strip()
        self._load_sfz_map(path)

    def _reload_sfz_map(self):
        self._load_sfz_map(self.sfz_path_edit.text().strip())

    def _browse_sfz_map(self):
        start_dir = os.path.dirname(self.sfz_map_path) if self.sfz_map_path else os.path.dirname(__file__)
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select SFZ Map File",
            start_dir,
            "SFZ files (*.sfz)",
        )
        if not path:
            return
        self.sfz_path_edit.setText(path)
        self._load_sfz_map(path)

    def _load_sfz_map(self, path: str):
        self.sfz_map_path = path or ""
        ok = self.sfz_sampler.load_map(self.sfz_map_path)
        self._update_sfz_status(ok)

    def _update_sfz_status(self, ok: bool | None = None):
        if ok is None:
            ok = self.sfz_sampler.is_ready()
        if hasattr(self, "ear_sample_status"):
            if ok:
                name = os.path.basename(self.sfz_map_path)
                self.ear_sample_status.setText(f"Sample map: {name}")
            else:
                msg = self.sfz_sampler.last_error or "Sample map not loaded."
                self.ear_sample_status.setText(f"Sample map: {msg}")

    def _select_practice_set(self):
        name = self.practice_set_combo.currentText()
        if not name:
            return
        self.current_set_name = name
        if self.practice_active:
            self._new_practice_target()

    def _refresh_practice_sets(self):
        if not hasattr(self, "practice_set_combo"):
            return
        self.practice_set_combo.blockSignals(True)
        self.practice_set_combo.clear()
        self.practice_set_combo.addItem("All Notes")
        for name in sorted(self.practice_sets.keys()):
            self.practice_set_combo.addItem(name)
        if self.current_set_name in [self.practice_set_combo.itemText(i) for i in range(self.practice_set_combo.count())]:
            self.practice_set_combo.setCurrentText(self.current_set_name)
        else:
            self.practice_set_combo.setCurrentIndex(0)
            self.current_set_name = "All Notes"
        self.practice_set_combo.blockSignals(False)

    def _parse_note_list(self, text: str):
        tokens = [t.strip() for t in text.replace(",", " ").split()]
        notes = []
        for token in tokens:
            try:
                midi = name_to_midi(token)
            except Exception:
                continue
            if midi < MIN_MIDI:
                continue
            notes.append(midi)
        return sorted(set(notes))

    def _save_current_set(self):
        name = self.practice_set_name.text().strip()
        if not name:
            return
        notes = self._parse_note_list(self.practice_set_editor.toPlainText())
        if not notes:
            return
        self.practice_sets[name] = notes
        self._save_sets()
        self.current_set_name = name
        self._refresh_practice_sets()

    def _load_selected_set(self):
        name = self.practice_set_combo.currentText()
        if name in self.practice_sets:
            notes = self.practice_sets[name]
            text = " ".join(midi_to_name(n) for n in notes)
            self.practice_set_editor.setPlainText(text)
            self.practice_set_name.setText(name)

    def _selected_note_set(self):
        if self.current_set_name == "All Notes":
            return None
        return set(self.practice_sets.get(self.current_set_name, []))

    def _refresh_presets(self):
        self.preset_combo.blockSignals(True)
        self.preset_combo.clear()
        for name in sorted(self.presets.keys()):
            self.preset_combo.addItem(name)
        self.preset_combo.blockSignals(False)

    def _select_preset(self):
        pass

    def _save_preset(self):
        name = self.preset_name.text().strip()
        if not name:
            return
        self.presets[name] = self._capture_preset()
        self._save_presets()
        self._refresh_presets()

    def _load_selected_preset(self):
        name = self.preset_combo.currentText()
        if name in self.presets:
            self._apply_preset(self.presets[name])

    def _capture_preset(self):
        return {
            "instrument": self.instrument_combo.currentText(),
            "max_fret": self.max_fret_spin.value(),
            "min_rms": self.min_rms_spin.value(),
            "min_conf": self.min_conf_spin.value(),
            "hold_frames": self.hold_frames_spin.value(),
            "hold_cents": self.hold_cents_spin.value(),
            "show_labels": self.show_labels_check.isChecked(),
            "practice_exact": self.practice_position_check.isChecked(),
            "practice_box": self.practice_box_check.isChecked(),
            "practice_box_low": self.practice_box_low_spin.value(),
            "practice_box_high": self.practice_box_high_spin.value(),
            "practice_string": self.practice_string_lock.currentIndex(),
            "scale_box": self.scale_box_check.isChecked(),
            "scale_box_low": self.scale_box_low_spin.value(),
            "scale_box_high": self.scale_box_high_spin.value(),
            "arp_box": self.arpeggio_box_check.isChecked(),
            "arp_box_low": self.arpeggio_box_low_spin.value(),
            "arp_box_high": self.arpeggio_box_high_spin.value(),
        }

    def _apply_preset(self, preset: dict):
        self.instrument_combo.blockSignals(True)
        self.max_fret_spin.blockSignals(True)
        self.min_rms_spin.blockSignals(True)
        self.min_conf_spin.blockSignals(True)
        self.hold_frames_spin.blockSignals(True)
        self.hold_cents_spin.blockSignals(True)
        self.show_labels_check.blockSignals(True)
        self.practice_position_check.blockSignals(True)
        self.practice_box_check.blockSignals(True)
        self.practice_box_low_spin.blockSignals(True)
        self.practice_box_high_spin.blockSignals(True)
        self.practice_string_lock.blockSignals(True)
        self.scale_box_check.blockSignals(True)
        self.scale_box_low_spin.blockSignals(True)
        self.scale_box_high_spin.blockSignals(True)
        self.arpeggio_box_check.blockSignals(True)
        self.arpeggio_box_low_spin.blockSignals(True)
        self.arpeggio_box_high_spin.blockSignals(True)

        self.instrument_combo.setCurrentText(preset.get("instrument", "Bass"))
        self.max_fret_spin.setValue(int(preset.get("max_fret", self.max_fret)))
        self.min_rms_spin.setValue(float(preset.get("min_rms", self.engine.min_rms)))
        self.min_conf_spin.setValue(float(preset.get("min_conf", self.engine.min_confidence)))
        self.hold_frames_spin.setValue(int(preset.get("hold_frames", self.engine.stable_required)))
        self.hold_cents_spin.setValue(float(preset.get("hold_cents", self.engine.stable_cents)))
        self.show_labels_check.setChecked(bool(preset.get("show_labels", self.show_note_labels)))
        self.practice_position_check.setChecked(bool(preset.get("practice_exact", self.practice_require_position)))
        self.practice_box_check.setChecked(bool(preset.get("practice_box", self.practice_box_enabled)))
        self.practice_box_low_spin.setValue(int(preset.get("practice_box_low", self.practice_box_low)))
        self.practice_box_high_spin.setValue(int(preset.get("practice_box_high", self.practice_box_high)))
        self.practice_string_lock.setCurrentIndex(int(preset.get("practice_string", 0)))
        self.scale_box_check.setChecked(bool(preset.get("scale_box", self.scale_box_enabled)))
        self.scale_box_low_spin.setValue(int(preset.get("scale_box_low", self.scale_box_low)))
        self.scale_box_high_spin.setValue(int(preset.get("scale_box_high", self.scale_box_high)))
        self.arpeggio_box_check.setChecked(bool(preset.get("arp_box", self.arpeggio_box_enabled)))
        self.arpeggio_box_low_spin.setValue(int(preset.get("arp_box_low", self.arpeggio_box_low)))
        self.arpeggio_box_high_spin.setValue(int(preset.get("arp_box_high", self.arpeggio_box_high)))

        self.instrument_combo.blockSignals(False)
        self.max_fret_spin.blockSignals(False)
        self.min_rms_spin.blockSignals(False)
        self.min_conf_spin.blockSignals(False)
        self.hold_frames_spin.blockSignals(False)
        self.hold_cents_spin.blockSignals(False)
        self.show_labels_check.blockSignals(False)
        self.practice_position_check.blockSignals(False)
        self.practice_box_check.blockSignals(False)
        self.practice_box_low_spin.blockSignals(False)
        self.practice_box_high_spin.blockSignals(False)
        self.practice_string_lock.blockSignals(False)
        self.scale_box_check.blockSignals(False)
        self.scale_box_low_spin.blockSignals(False)
        self.scale_box_high_spin.blockSignals(False)
        self.arpeggio_box_check.blockSignals(False)
        self.arpeggio_box_low_spin.blockSignals(False)
        self.arpeggio_box_high_spin.blockSignals(False)

        self._set_instrument(self.instrument_combo.currentText())
        self._set_max_fret(self.max_fret_spin.value())
        self._set_min_rms(self.min_rms_spin.value())
        self._set_min_confidence(self.min_conf_spin.value())
        self._set_hold_frames(self.hold_frames_spin.value())
        self._set_hold_cents(self.hold_cents_spin.value())
        self._toggle_note_labels()
        self._toggle_position_mode()
        self._toggle_box_mode()
        self._set_box_range()
        self._set_practice_string_lock()
        self._toggle_scale_box()
        self._set_scale_box_range()
        self._toggle_arpeggio_box()
        self._set_arpeggio_box_range()

    def _presets_path(self):
        return os.path.join(os.path.dirname(__file__), "presets.json")

    def _load_presets(self):
        path = self._presets_path()
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
        except Exception:
            pass
        return {}

    def _save_presets(self):
        path = self._presets_path()
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.presets, f)
        except Exception:
            pass

    def _refresh_devices(self):
        self.device_combo.blockSignals(True)
        self.device_combo.clear()
        self._device_map = []
        try:
            devices = sd.query_devices()
        except Exception:
            devices = []
        for idx, dev in enumerate(devices):
            if dev.get("max_input_channels", 0) > 0:
                label = f"{idx}: {dev.get('name', 'Unknown')}"
                self.device_combo.addItem(label)
                self._device_map.append(idx)
        self.device_combo.blockSignals(False)
        default_in = sd.default.device[0] if sd.default.device else None
        if default_in in self._device_map:
            self.device_combo.setCurrentIndex(self._device_map.index(default_in))
            self.engine.set_device(default_in)
        elif self._device_map:
            self.device_combo.setCurrentIndex(0)
            self.engine.set_device(self._device_map[0])

    def _set_device(self, index: int):
        if 0 <= index < len(self._device_map):
            self.engine.set_device(self._device_map[index])

    def _auto_calibrate_noise(self):
        self._noise_samples = []
        self._noise_until = time.time() + 1.5
        if self._noise_timer is None:
            self._noise_timer = QtCore.QTimer(self)
            self._noise_timer.setInterval(50)
            self._noise_timer.timeout.connect(self._collect_noise_sample)
        self._noise_timer.start()

    def _collect_noise_sample(self):
        self._noise_samples.append(self.engine.last_rms)
        if time.time() >= self._noise_until:
            self._noise_timer.stop()
            if self._noise_samples:
                noise = float(np.mean(self._noise_samples))
                suggested = max(0.001, noise * 3.0)
                self.engine.min_rms = suggested
                self.min_rms_spin.blockSignals(True)
                self.min_rms_spin.setValue(suggested)
                self.min_rms_spin.blockSignals(False)

    def _toggle_scale_box(self):
        self.scale_box_enabled = self.scale_box_check.isChecked()
        if self.scale_active:
            self._update_scale_target()

    def _set_scale_box_range(self):
        low = min(self.scale_box_low_spin.value(), self.scale_box_high_spin.value())
        high = max(self.scale_box_low_spin.value(), self.scale_box_high_spin.value())
        self.scale_box_low = low
        self.scale_box_high = high
        self.scale_box_low_spin.blockSignals(True)
        self.scale_box_high_spin.blockSignals(True)
        self.scale_box_low_spin.setValue(low)
        self.scale_box_high_spin.setValue(high)
        self.scale_box_low_spin.blockSignals(False)
        self.scale_box_high_spin.blockSignals(False)
        if self.scale_active:
            self._update_scale_target()

    def _toggle_arpeggio_box(self):
        self.arpeggio_box_enabled = self.arpeggio_box_check.isChecked()
        if self.arpeggio_active:
            self._update_arpeggio_target()

    def _set_arpeggio_box_range(self):
        low = min(self.arpeggio_box_low_spin.value(), self.arpeggio_box_high_spin.value())
        high = max(self.arpeggio_box_low_spin.value(), self.arpeggio_box_high_spin.value())
        self.arpeggio_box_low = low
        self.arpeggio_box_high = high
        self.arpeggio_box_low_spin.blockSignals(True)
        self.arpeggio_box_high_spin.blockSignals(True)
        self.arpeggio_box_low_spin.setValue(low)
        self.arpeggio_box_high_spin.setValue(high)
        self.arpeggio_box_low_spin.blockSignals(False)
        self.arpeggio_box_high_spin.blockSignals(False)
        if self.arpeggio_active:
            self._update_arpeggio_target()

    def _toggle_interval_random(self):
        self.interval_random = self.interval_random_check.isChecked()
        if self.interval_active:
            self._new_interval_target()

    def _toggle_song_demo(self):
        if self.song_start.text() == "Start Demo":
            self.song_fretboard.start()
            self.song_start.setText("Stop Demo")
        else:
            self.song_fretboard.stop()
            self.song_start.setText("Start Demo")

    def _convert_psarc_oneclick(self):
        path = getattr(self, "_psarc_current_path", None)
        cli = os.path.join(os.path.dirname(__file__), "rockysmithereens-main", "target", "release", "psarc_extract.exe")
        toolkit = os.path.join(os.path.dirname(__file__), "RocksmithToolkit", "sng2014.exe")
        vgmstream = os.path.join(os.path.dirname(__file__), "vgsteam-win64", "vgmstream-cli.exe")
        if not path or not cli or not toolkit or not vgmstream:
            self.psarc_list.setPlainText("Load PSARC and ensure CLI/Toolkit/vgmstream paths are set.")
            return
        if not (os.path.exists(cli) and os.path.exists(toolkit) and os.path.exists(vgmstream)):
            self.psarc_list.setPlainText("Missing tools. Make sure rockysmithereens, RocksmithToolkit, and vgmstream are in this folder.")
            return

        code, out, err = self._run_cli([cli, path, "list"])
        if code != 0:
            self.psarc_list.setPlainText(f"CLI error ({code}):\n{err or out}")
            return
        lines = out.splitlines()
        sng_path = next((l for l in lines if l.endswith("_bass.sng")), None)
        manifest_path = next((l for l in lines if l.endswith("_bass.json")), None)
        wem_paths = [l for l in lines if l.endswith(".wem")]
        if not sng_path or not manifest_path or not wem_paths:
            self.psarc_list.setPlainText("Could not find bass SNG/manifest/WEM in PSARC list.")
            return

        base_name = os.path.splitext(os.path.basename(path))[0]
        out_dir = os.path.join(os.path.dirname(__file__), "songs", "converted", base_name)
        os.makedirs(out_dir, exist_ok=True)
        sng_out = os.path.join(out_dir, os.path.basename(sng_path))
        man_out = os.path.join(out_dir, os.path.basename(manifest_path))
        wem_outs = []
        for wp in wem_paths:
            wem_outs.append(os.path.join(out_dir, os.path.basename(wp)))

        for src, dst in [(sng_path, sng_out), (manifest_path, man_out)]:
            code, out, err = self._run_cli([cli, path, "extract", src, dst])
            if code != 0:
                self.psarc_list.setPlainText(f"Extract error ({code}):\n{err or out}")
                return
        for src, dst in zip(wem_paths, wem_outs):
            code, out, err = self._run_cli([cli, path, "extract", src, dst])
            if code != 0:
                self.psarc_list.setPlainText(f"Extract error ({code}):\n{err or out}")
                return

        # Convert SNG -> XML
        code, out, err = self._run_cli(
            [toolkit, "-x", "-i", sng_out, "-m", man_out, "-a", "Bass", "-f", "Pc"],
            workdir=out_dir,
        )
        if code != 0:
            self.psarc_list.setPlainText(f"Toolkit error ({code}):\n{err or out}")
            return

        xml_out = os.path.splitext(sng_out)[0] + ".xml"
        if not os.path.exists(xml_out):
            self.psarc_list.setPlainText("XML not found after conversion.")
            return

        # Parse XML -> song.json + load
        song = parse_song_xml(xml_out)
        out_path = os.path.join(out_dir, "song.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(song, f, indent=2)
        notes = []
        for n in song["notes"]:
            lane = int(n["string"])
            fret = int(n["fret"])
            time_val = float(n["time"])
            duration = float(n.get("sustain") or 0.0)
            slide_to = n.get("slide_to")
            notes.append((lane, fret, time_val, duration, slide_to))
        self.song_fretboard.set_notes(notes, duration=song.get("length", 0), ebeats=song.get("ebeats", []))
        if hasattr(self, "tab_view"):
            self.tab_view.set_notes(notes, duration=song.get("length", 0))
        self.song_title = song["title"]
        self.song_artist = song["artist"]
        self.song_title_label.setText(song["title"])
        self.song_artist_label.setText(song["artist"])
        self.song_offset = float(song.get("offset", 0.0))
        self.song_offset_ms = -300
        self.offset_spin.setValue(self.song_offset_ms)

        # Convert WEM -> WAV using vgmstream and load audio
        best_wav = None
        best_len = -1
        best_data = None
        best_sr = None
        import soundfile as sf
        for wem_out in wem_outs:
            wav_out = os.path.splitext(wem_out)[0] + ".wav"
            code, out, err = self._run_cli([vgmstream, "-o", wav_out, wem_out])
            if code != 0:
                continue
            try:
                data, sr = sf.read(wav_out, dtype="float32")
                if data.ndim > 1:
                    data = np.mean(data, axis=1)
                length = len(data) / max(1, sr)
                if length > best_len:
                    best_len = length
                    best_wav = wav_out
                    best_data = data
                    best_sr = sr
            except Exception:
                continue
        if best_wav is None:
            self.psarc_list.setPlainText("Failed to convert any WEM to WAV.")
            return
        self.song_audio = best_data
        self.song_audio_sr = best_sr

        self.psarc_list.setPlainText(
            f"Converted and loaded:\n{os.path.basename(path)}\nNotes: {len(notes)}\nAudio: {os.path.basename(best_wav)}"
        )
        self.song_json_path = out_path
        self.song_audio_path = best_wav
        self._add_current_to_library()
        self._refresh_song_library()

    def _convert_psarc_bulk(self):
        songs_dir = os.path.join(os.path.dirname(__file__), "songs")
        psarcs = [p for p in os.listdir(songs_dir) if p.lower().endswith(".psarc")]
        if not psarcs:
            self.psarc_list.setPlainText("No .psarc files found in songs/")
            return
        converted = 0
        for name in psarcs:
            base = os.path.splitext(name)[0]
            out_dir = os.path.join(songs_dir, "converted", base)
            if os.path.exists(os.path.join(out_dir, "song.json")):
                continue
            self._psarc_current_path = os.path.join(songs_dir, name)
            self._convert_psarc_oneclick()
            converted += 1
        self.psarc_list.setPlainText(f"Bulk convert complete. New: {converted}")

    def _load_psarc(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Open PSARC",
            os.path.join(os.path.dirname(__file__), "songs"),
            "PSARC Files (*.psarc)",
        )
        if not path:
            return
        self.psarc_path_label.setText(f"PSARC: {os.path.basename(path)}")
        self._psarc_current_path = path
        self.psarc_list.setPlainText(
            "PSARC selected. Use 'List via CLI' to view contents (in-app parser disabled)."
        )

    def _browse_psarc_cli(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select psarc_extract.exe",
            os.path.dirname(__file__),
            "Executable (*.exe);;All Files (*.*)",
        )
        if path:
            self.psarc_cli_path.setText(path)

    def _browse_toolkit(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select sng2014.exe",
            os.path.dirname(__file__),
            "Executable (*.exe);;All Files (*.*)",
        )
        if path:
            self.toolkit_path.setText(path)

    def _browse_wem(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select .wem file",
            os.path.join(os.path.dirname(__file__), "songs"),
            "WEM Files (*.wem)",
        )
        if path:
            self.audio_wem_path.setText(path)

    def _browse_ffmpeg(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select ffmpeg.exe",
            os.path.dirname(__file__),
            "Executable (*.exe);;All Files (*.*)",
        )
        if path:
            self.ffmpeg_path.setText(path)

    def _browse_vgmstream(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select vgmstream-cli.exe",
            os.path.dirname(__file__),
            "Executable (*.exe);;All Files (*.*)",
        )
        if path:
            self.vgmstream_path.setText(path)

    def _sng_to_xml(self):
        toolkit = self.toolkit_path.text().strip()
        sng = self.sng_path.text().strip()
        manifest = self.manifest_path.text().strip()
        if not toolkit or not sng or not manifest:
            self.psarc_list.setPlainText("Set toolkit, SNG, and manifest paths first.")
            return
        out_dir = os.path.join(os.path.dirname(__file__), "songs")
        os.makedirs(out_dir, exist_ok=True)
        code, out, err = self._run_cli(
            [
                toolkit,
                "-x",
                "-i",
                sng,
                "-m",
                manifest,
                "-a",
                "Bass",
                "-f",
                "Pc",
            ],
            workdir=out_dir,
        )
        if code == 0:
            self.psarc_list.setPlainText("SNG -> XML complete. Next: we'll parse XML into song.json.")
        else:
            self.psarc_list.setPlainText(f"Toolkit error ({code}):\n{err or out}")

    def _xml_to_song(self):
        xml_path = self.xml_path.text().strip()
        if not xml_path or not os.path.exists(xml_path):
            self.psarc_list.setPlainText("Set a valid XML path first.")
            return
        try:
            song = parse_song_xml(xml_path)
            out_path = os.path.join(os.path.dirname(__file__), "songs", "song.json")
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(song, f, indent=2)
            notes = []
            for n in song["notes"]:
                lane = int(n["string"])
                fret = int(n["fret"])
                time_val = float(n["time"])
                duration = float(n.get("sustain") or 0.0)
                slide_to = n.get("slide_to")
                notes.append((lane, fret, time_val, duration, slide_to))
            self.song_fretboard.set_notes(notes, duration=song.get("length", 0), ebeats=song.get("ebeats", []))
            if hasattr(self, "tab_view"):
                self.tab_view.set_notes(notes, duration=song.get("length", 0))
            self.song_title = song["title"]
            self.song_artist = song["artist"]
            self.song_title_label.setText(song["title"])
            self.song_artist_label.setText(song["artist"])
            self.song_offset = float(song.get("offset", 0.0))
            self.song_offset_ms = -300
            self.offset_spin.setValue(self.song_offset_ms)
            self.song_json_path = out_path
            self.psarc_list.setPlainText(f"Loaded song: {song['title']} ({len(notes)} notes)\nSaved: {out_path}")
        except Exception as exc:
            self.psarc_list.setPlainText(f"XML parse error:\n{exc}")

    def _convert_wem(self):
        wem_path = self.audio_wem_path.text().strip()
        vgmstream = self.vgmstream_path.text().strip()
        if not wem_path or not vgmstream:
            self.psarc_list.setPlainText("Set WEM and vgmstream paths first.")
            return
        if not os.path.exists(wem_path):
            self.psarc_list.setPlainText("WEM file not found.")
            return
        out_path = os.path.splitext(wem_path)[0] + ".wav"
        code, out, err = self._run_cli([vgmstream, "-o", out_path, wem_path])
        if code == 0:
            self.psarc_list.setPlainText(f"Converted to:\n{out_path}")
        else:
            self.psarc_list.setPlainText(f"vgmstream error ({code}):\n{err or out}")

    def _load_audio(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select audio file",
            os.path.join(os.path.dirname(__file__), "songs"),
            "Audio Files (*.wav *.ogg)",
        )
        if not path:
            return
        try:
            import soundfile as sf
            data, sr = sf.read(path, dtype="float32")
            if data.ndim > 1:
                data = np.mean(data, axis=1)
            self.song_audio = data
            self.song_audio_sr = sr
            self.song_audio_path = path
            self.psarc_list.setPlainText(f"Loaded audio: {os.path.basename(path)}")
        except Exception as exc:
            self.psarc_list.setPlainText(f"Audio load error:\n{exc}")

    def _play_audio(self):
        if self.song_audio is None or self.song_audio_sr is None:
            self.psarc_list.setPlainText("Load audio first.")
            return
        sd.stop()
        sd.play(self.song_audio, self.song_audio_sr)
        self.song_audio_start = time.time()
        self.song_fretboard.set_progress(0.0)

    def _stop_audio(self):
        sd.stop()
        self.song_audio_start = None
        self.song_fretboard.set_progress(None)

    def _set_sync_offset(self, value: int):
        self.song_offset_ms = int(value)

    def _pause_audio(self):
        sd.stop()
        self.song_audio_start = None
        self.song_fretboard.set_progress(None)
        if hasattr(self, "tab_view"):
            self.tab_view.set_progress(None)

    def _set_display_delay(self, value: int):
        if hasattr(self, "song_fretboard"):
            self.song_fretboard._display_delay = max(0.0, value / 1000.0)


    def _run_cli(self, args, workdir=None):
        try:
            result = subprocess.run(
                args,
                cwd=workdir,
                capture_output=True,
                text=True,
                check=False,
            )
            out = result.stdout.strip()
            err = result.stderr.strip()
            return result.returncode, out, err
        except Exception as exc:
            return 1, "", str(exc)

    def _library_path(self):
        return os.path.join(os.path.dirname(__file__), "songs", "library.json")

    def _load_song_library(self):
        path = self._library_path()
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
        except Exception:
            pass
        return []

    def _save_song_library(self):
        path = self._library_path()
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.song_library, f, indent=2)
        except Exception:
            pass

    def _refresh_song_library(self):
        self.song_library_combo.blockSignals(True)
        self.song_library_combo.clear()
        self.song_library_combo.addItem("Select a song...", None)
        for entry in self.song_library:
            label = f"{entry.get('title','Unknown')} - {entry.get('artist','')}"
            self.song_library_combo.addItem(label, entry)
        self.song_library_combo.blockSignals(False)
        if hasattr(self, "tab_library_combo"):
            self.tab_library_combo.blockSignals(True)
            self.tab_library_combo.clear()
            self.tab_library_combo.addItem("Select a song...", None)
            for entry in self.song_library:
                label = f"{entry.get('title','Unknown')} - {entry.get('artist','')}"
                self.tab_library_combo.addItem(label, entry)
            self.tab_library_combo.blockSignals(False)

    def _add_current_to_library(self):
        json_path = getattr(self, "song_json_path", None)
        audio_path = getattr(self, "song_audio_path", None)
        if not json_path or not audio_path:
            self.psarc_list.setPlainText("Load song JSON and audio first.")
            return
        entry = {
            "title": self.song_title,
            "artist": self.song_artist,
            "json_path": json_path,
            "audio_path": audio_path,
        }
        self.song_library.append(entry)
        self._save_song_library()
        self._refresh_song_library()
        self.psarc_list.setPlainText("Added to library.")

    def _load_library_selection(self):
        # Use the sender combo so both Song and Tab dropdowns work.
        sender = self.sender()
        combo = sender if isinstance(sender, QtWidgets.QComboBox) else self.song_library_combo
        data = combo.currentData()
        if not data:
            return
        json_path = data.get("json_path")
        audio_path = data.get("audio_path")
        if json_path and os.path.exists(json_path):
            try:
                with open(json_path, "r", encoding="utf-8") as f:
                    song = json.load(f)
                notes = []
                for n in song["notes"]:
                    lane = int(n["string"])
                    fret = int(n["fret"])
                    time_val = float(n["time"])
                    duration = float(n.get("sustain") or 0.0)
                    slide_to = n.get("slide_to")
                    notes.append((lane, fret, time_val, duration, slide_to))
                self.song_fretboard.set_notes(notes, duration=song.get("length", 0), ebeats=song.get("ebeats", []))
                if hasattr(self, "tab_view"):
                    self.tab_view.set_notes(notes, duration=song.get("length", 0))
                self.song_title = song.get("title", "Song")
                self.song_artist = song.get("artist", "")
                self.song_title_label.setText(self.song_title)
                self.song_artist_label.setText(self.song_artist)
                self.song_offset = float(song.get("offset", 0.0))
                self.song_offset_ms = -300
                self.offset_spin.setValue(self.song_offset_ms)
                self.song_json_path = json_path
            except Exception as exc:
                self.psarc_list.setPlainText(f"Song JSON load error:\n{exc}")
        if audio_path and os.path.exists(audio_path):
            try:
                import soundfile as sf
                data_audio, sr = sf.read(audio_path, dtype="float32")
                if data_audio.ndim > 1:
                    data_audio = np.mean(data_audio, axis=1)
                self.song_audio = data_audio
                self.song_audio_sr = sr
                self.song_audio_path = audio_path
            except Exception as exc:
                self.psarc_list.setPlainText(f"Audio load error:\n{exc}")
        self.psarc_list.setPlainText(
            f"Loaded from library:\n{os.path.basename(json_path or '')}\n{os.path.basename(audio_path or '')}"
        )
        if hasattr(self, "tab_loaded_label"):
            self.tab_loaded_label.setText(f"Loaded: {self.song_title}")

    def _psarc_cli_list(self):
        cli = self.psarc_cli_path.text().strip()
        path = getattr(self, "_psarc_current_path", None)
        if not cli or not path:
            self.psarc_list.setPlainText("Set CLI path and load a PSARC first.")
            return
        code, out, err = self._run_cli([cli, path, "list"])
        if code == 0 and out:
            self.psarc_list.setPlainText(out)
        else:
            self.psarc_list.setPlainText(f"CLI error ({code}):\n{err or out}")

    def _psarc_cli_extract_bass(self):
        cli = self.psarc_cli_path.text().strip()
        path = getattr(self, "_psarc_current_path", None)
        if not cli or not path:
            self.psarc_list.setPlainText("Set CLI path and load a PSARC first.")
            return
        internal_path, ok = QtWidgets.QInputDialog.getText(
            self,
            "Extract File",
            "Path inside PSARC (copy from list output):",
        )
        if not ok or not internal_path.strip():
            return
        save_path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Save Extracted File",
            os.path.join(os.path.dirname(__file__), "songs"),
            "All Files (*.*)",
        )
        if not save_path:
            return
        code, out, err = self._run_cli([cli, path, "extract", internal_path.strip(), save_path])
        if code == 0:
            self.psarc_list.setPlainText(f"Extracted to:\n{save_path}")
        else:
            self.psarc_list.setPlainText(f"CLI error ({code}):\n{err or out}")

    def _toggle_ear_hide_label(self):
        self.ear_hide_label = self.ear_hide_label_check.isChecked()
        if self.ear_active and self.ear_target_midi is not None:
            self._update_ear_label()

    def _toggle_ear_hide_target(self):
        self.ear_hide_target = self.ear_hide_target_check.isChecked()
        self._update_fretboard(self.engine.last_midi)

    def _toggle_ear_training(self):
        if self.ear_active:
            self.ear_active = False
            self.ear_start_btn.setText("Start")
            self.ear_target_label.setText("Target: --")
            self.ear_feedback_label.setText("Feedback: --")
            self.ear_target_midi = None
            self.ear_combo_sequence = []
            self.ear_combo_index = 0
            self.ear_combo_attempted_notes = 0
            self.ear_combo_positions = []
            self.ear_combo_grace_until = 0.0
            self.ear_combo_last_match_time = 0.0
            self.ear_combo_last_midi = None
            self.ear_combo_last_advance_time = 0.0
            self.ear_last_play = 0.0
            self._update_fretboard(None)
        else:
            self.ear_active = True
            self.ear_score = 0
            self.ear_score_label.setText("Score: 0")
            self.ear_start_btn.setText("Stop")
            self._new_ear_target(play_tone=True)

    def _play_ear_tone(self):
        if self.ear_combo_enabled and self.ear_combo_sequence:
            self._play_ear_combo()
            return
        if self.ear_target_midi is None:
            return
        self._play_ear_midi(self.ear_target_midi, duration=1.0, update_last_play=True)

    def _play_ear_midi(self, midi_note: int, duration: float | None = None, update_last_play: bool = False):
        if update_last_play:
            self.ear_last_play = time.time()
        play_duration = duration if duration is not None else 1.0
        if self.ear_playback_mode.startswith("Sampled") and self.sfz_sampler.is_ready():
            midi = midi_note + self.sfz_octave_offset
            self.sfz_sampler.play_midi(midi, duration=play_duration)
            if self.sfz_sampler.last_error:
                self.ear_feedback_label.setText(f"Feedback: {self.sfz_sampler.last_error}")
            return
        if self.ear_playback_mode.startswith("Sampled") and not self.sfz_sampler.is_ready():
            self.ear_feedback_label.setText("Feedback: sample map not loaded, using tone")
        freq = midi_to_freq(midi_note)
        self._play_tone_for(freq, duration=play_duration)

    def _play_ear_combo(self):
        if not self.ear_combo_sequence:
            return
        self.ear_last_play = time.time()
        duration = max(0.3, float(self.ear_combo_note_duration))
        gap = max(duration + 0.1, float(self.ear_combo_gap))
        gap_ms = int(gap * 1000)
        for i, midi in enumerate(self.ear_combo_sequence):
            QtCore.QTimer.singleShot(
                i * gap_ms,
                lambda m=midi, d=duration: self._play_ear_midi(m, duration=d),
            )

    def _play_tone_for(self, freq: float, duration: float = 1.0):
        self.audio_tools.set_tone_freq(freq)
        self.audio_tools.set_tone(True)
        QtCore.QTimer.singleShot(int(duration * 1000), lambda: self.audio_tools.set_tone(False))

    def _ear_note_pool(self):
        pool = []
        tuning = self._current_tuning()
        if self.ear_single_string and tuning:
            string_index = min(max(0, self.ear_single_string_index), len(tuning) - 1)
            _name, open_midi = tuning[string_index]
            for fret in range(0, self.max_fret + 1):
                midi = open_midi + fret
                if midi >= MIN_MIDI:
                    pool.append(midi)
        else:
            for _string_index, (_string_name, open_midi) in enumerate(tuning):
                for fret in range(0, self.max_fret + 1):
                    midi = open_midi + fret
                    if midi < MIN_MIDI:
                        continue
                    pool.append(midi)
        return sorted(set(pool))

    def _ear_sr_pick(self, pool):
        now = time.time()
        due = []
        next_due = []
        for midi in pool:
            entry = self.ear_sr_stats.get(str(midi))
            if not isinstance(entry, dict):
                entry = {"box": 0, "due": 0.0, "correct": 0, "wrong": 0}
                self.ear_sr_stats[str(midi)] = entry
            if now >= float(entry.get("due", 0.0)):
                due.append(midi)
            else:
                next_due.append((float(entry.get("due", 0.0)), midi))
        if due:
            return random.choice(due)
        if not next_due:
            return random.choice(pool)
        next_due.sort(key=lambda x: x[0])
        head = [m for _d, m in next_due[:5]]
        return random.choice(head)

    def _ear_sr_mark(self, midi_note: int, correct: bool):
        key = str(midi_note)
        entry = self.ear_sr_stats.get(key)
        if not isinstance(entry, dict):
            entry = {"box": 0, "due": 0.0, "correct": 0, "wrong": 0}
        box = int(entry.get("box", 0))
        if correct:
            entry["correct"] = int(entry.get("correct", 0)) + 1
            box = min(box + 1, len(self.ear_sr_intervals) - 1)
        else:
            entry["wrong"] = int(entry.get("wrong", 0)) + 1
            box = 0
        entry["box"] = box
        entry["due"] = time.time() + float(self.ear_sr_intervals[box])
        self.ear_sr_stats[key] = entry
        self._save_ear_stats()

    def _new_ear_target(self, play_tone: bool = False):
        if self.ear_combo_enabled:
            length = max(2, min(5, int(self.ear_combo_length)))
            seq, positions = self._build_ear_combo_sequence(length)
            if seq:
                self.ear_combo_sequence = seq
                self.ear_combo_positions = positions
                self.ear_combo_index = 0
                self.ear_combo_attempted_notes = 0
                self.ear_combo_grace_until = 0.0
                self.ear_combo_last_match_time = 0.0
                self.ear_combo_last_midi = None
                self.ear_combo_last_advance_time = 0.0
                self.ear_target_midi = seq[0]
                self._update_ear_label()
                self.ear_feedback_label.setText("Feedback: listen and play it back")
                self._update_fretboard(None)
                if play_tone:
                    self._play_ear_tone()
                return
        pool = self._ear_note_pool()
        if not pool:
            return
        self.ear_combo_sequence = []
        self.ear_combo_index = 0
        self.ear_combo_attempted_notes = 0
        self.ear_combo_positions = []
        self.ear_combo_grace_until = 0.0
        self.ear_combo_last_match_time = 0.0
        self.ear_combo_last_midi = None
        self.ear_combo_last_advance_time = 0.0
        if self.ear_sr_enabled:
            self.ear_target_midi = self._ear_sr_pick(pool)
        else:
            self.ear_target_midi = random.choice(pool)
        self._update_ear_label()
        self.ear_feedback_label.setText("Feedback: listen and play it back")
        self._update_fretboard(None)
        if play_tone:
            self._play_ear_tone()

    def _update_ear_label(self):
        if self.ear_target_midi is None:
            self.ear_target_label.setText("Target: --")
            return
        if self.ear_hide_label:
            if self.ear_combo_enabled and self.ear_combo_sequence:
                self.ear_target_label.setText(
                    f"Target: (hidden) {self.ear_combo_index + 1}/{len(self.ear_combo_sequence)}"
                )
            else:
                self.ear_target_label.setText("Target: (hidden)")
        else:
            if self.ear_combo_enabled and self.ear_combo_sequence:
                names = [midi_to_name(m) for m in self.ear_combo_sequence]
                self.ear_target_label.setText(
                    f"Target: {' -> '.join(names)} ({self.ear_combo_index + 1}/{len(self.ear_combo_sequence)})"
                )
            else:
                note = midi_to_name(self.ear_target_midi)
                self.ear_target_label.setText(f"Target: {note}")

    def _build_ear_combo_sequence(self, length: int) -> tuple[list[int], list[tuple[int, int, str]]]:
        positions = []
        for string_index, (_string_name, open_midi) in enumerate(self._current_tuning()):
            for fret in range(0, self.max_fret + 1):
                midi = open_midi + fret
                if midi < MIN_MIDI:
                    continue
                positions.append((string_index, fret, midi))
        if not positions:
            return [], []

        def candidates_for_fret(start_fret: int) -> list[int]:
            low = max(0, start_fret - 2)
            high = min(self.max_fret, start_fret + 2)
            cands = []
            for _sidx, (_sname, open_midi) in enumerate(self._current_tuning()):
                for f in range(low, high + 1):
                    midi = open_midi + f
                    if midi >= MIN_MIDI:
                        cands.append(midi)
            return sorted(set(cands))

        interval_pool = [2, 3, 4, 5, 7, 12]
        for _ in range(80):
            start = random.choice(positions)
            _sidx, start_fret, start_midi = start
            cands = candidates_for_fret(start_fret)
            if len(cands) < 2:
                continue
            seq = [start_midi]
            for _step in range(1, length):
                interval = random.choice(interval_pool)
                direction = random.choice([-1, 1])
                target = seq[-1] + interval * direction
                options = [m for m in cands if m != seq[-1]]
                if not options:
                    options = cands
                best_dist = min(abs(m - target) for m in options)
                close = [m for m in options if abs(m - target) == best_dist]
                seq.append(random.choice(close))
            pos_list = []
            for midi in seq:
                fret_choices = []
                low = max(0, start_fret - 2)
                high = min(self.max_fret, start_fret + 2)
                for string_index, (_name, open_midi) in enumerate(self._current_tuning()):
                    fret = midi - open_midi
                    if low <= fret <= high:
                        fret_choices.append((string_index, fret, midi_to_name(midi)))
                if not fret_choices:
                    # Fall back to any valid position if none in range.
                    for string_index, (_name, open_midi) in enumerate(self._current_tuning()):
                        fret = midi - open_midi
                        if 0 <= fret <= self.max_fret:
                            fret_choices.append((string_index, fret, midi_to_name(midi)))
                pos_list.append(random.choice(fret_choices))
            return seq, pos_list
        return [], []

    def _toggle_chords(self):
        if self.chord_active:
            self.chord_active = False
            self.chord_start_btn.setText("Start")
            self.chord_label.setText("Chord: --")
            self.chord_conf_label.setText("Confidence: --")
            self.chord_smoothed = np.zeros(12, dtype=np.float64)
        else:
            self.chord_active = True
            self.chord_start_btn.setText("Stop")
            self.chord_last_time = 0.0

    def _update_chord_types(self):
        selected = {k: v for k, v in CHORD_TYPES.items() if self.chord_type_checks[k].isChecked()}
        if not selected:
            selected = {"Major": CHORD_TYPES["Major"]}
            self.chord_type_checks["Major"].setChecked(True)
        self.chord_templates = build_chord_templates(selected)

    def _update_chord_threshold(self, value: int):
        self.chord_conf_threshold = value / 100.0

    def _update_chord_smoothing(self, value: int):
        self.chord_smooth_alpha = value / 100.0

    def _toggle_metronome(self):
        self.audio_tools.set_metronome(self.metronome_check.isChecked())

    def _set_metronome_bpm(self, value: int):
        self.audio_tools.set_bpm(float(value))

    def _set_metronome_volume(self, value: int):
        self.audio_tools.set_click_volume(float(value) / 100.0)

    def _toggle_tone(self):
        self.audio_tools.set_tone(self.tone_check.isChecked())

    def _update_tone_freq(self):
        note = self.tone_note.currentText()
        octave = int(self.tone_octave.currentText())
        midi = clamp_min_midi(name_to_midi(f"{note}{octave}"))
        freq = midi_to_freq(midi)
        if self.tone_octave_boost.isChecked():
            while freq < 110.0:
                freq *= 2.0
        self.tone_freq_label.setText(f"Freq: {freq:.1f} Hz")
        self.audio_tools.set_tone_freq(freq)

    def _set_tone_volume(self, value: int):
        self.audio_tools.set_tone_volume(float(value) / 100.0)

    def _update_tone_harmonic(self):
        self.audio_tools.set_tone_harmonic_mix(0.4 if self.tone_harm_check.isChecked() else 0.0)

    def _update_low_tone_boost(self, value: int):
        self.audio_tools.set_low_tone_boost_db(float(value))

    def _update_loudness_balance(self):
        self.audio_tools.set_loudness_balance(self.tone_loudness_check.isChecked())

    def _bind_note_octave_pairs(self):
        self._note_octave_pairs = [
            (self.scale_root, self.scale_octave),
            (self.interval_root, self.interval_octave),
            (self.arpeggio_root, self.arpeggio_octave),
            (self.tone_note, self.tone_octave),
        ]
        for note_combo, octave_combo in self._note_octave_pairs:
            octave_combo.currentIndexChanged.connect(
                lambda _idx, n=note_combo, o=octave_combo: self._refresh_note_combo(n, o)
            )
            self._refresh_note_combo(note_combo, octave_combo)

    def _refresh_note_combo(self, note_combo: QtWidgets.QComboBox, octave_combo: QtWidgets.QComboBox):
        octave = int(octave_combo.currentText())
        allowed = NOTE_NAMES if octave > 1 else ["E", "F", "F#", "G", "G#", "A", "A#", "B"]
        current = note_combo.currentText()
        note_combo.blockSignals(True)
        note_combo.clear()
        note_combo.addItems(allowed)
        if current in allowed:
            note_combo.setCurrentText(current)
        else:
            note_combo.setCurrentIndex(0)
        note_combo.blockSignals(False)
        if note_combo is self.tone_note:
            self._update_tone_freq()

    def _current_tuning(self):
        return BASS_TUNING if self.instrument == "Bass" else GUITAR_TUNING

    def _note_positions(self, midi_note: int):
        positions = []
        for string_index, (string_name, open_midi) in enumerate(self._current_tuning()):
            fret = midi_note - open_midi
            if 0 <= fret <= self.max_fret:
                positions.append((string_index, fret))
        return positions

    def _position_label(self, string_index: int, fret: int) -> str:
        tuning = self._current_tuning()
        if 0 <= string_index < len(tuning):
            _, open_midi = tuning[string_index]
            return midi_to_name(open_midi + fret)
        return ""

    def _note_positions_labeled(self, midi_note: int):
        positions = []
        for string_index, (string_name, open_midi) in enumerate(self._current_tuning()):
            fret = midi_note - open_midi
            if 0 <= fret <= self.max_fret:
                positions.append((string_index, fret, midi_to_name(midi_note)))
        return positions

    def _note_positions_text(self, midi_note: int):
        positions = []
        for string_index, (string_name, open_midi) in enumerate(self._current_tuning()):
            fret = midi_note - open_midi
            if 0 <= fret <= self.max_fret:
                positions.append(f"{string_name} fret {fret}")
        return positions

    def _current_target_midi(self):
        if self.practice_active and self.practice_target_midi is not None:
            return self.practice_target_midi
        if self.scale_active and self.scale_index < len(self.scale_notes):
            return self.scale_notes[self.scale_index]
        if self.interval_active and self.interval_target_midi is not None:
            return self.interval_target_midi
        if self.arpeggio_active and self.arpeggio_index < len(self.arpeggio_notes):
            return self.arpeggio_notes[self.arpeggio_index]
        if self.ear_active and self.ear_combo_enabled and self.ear_combo_sequence:
            idx = max(0, min(self.ear_combo_index, len(self.ear_combo_sequence) - 1))
            return self.ear_combo_sequence[idx]
        if self.ear_active and self.ear_target_midi is not None:
            return self.ear_target_midi
        return None

    def _update_fretboard(self, current_midi: int | None):
        target_midi = self._current_target_midi()
        current_positions = self._note_positions_labeled(current_midi) if current_midi is not None else []
        if self.practice_active and self.practice_require_position and self.practice_target_position is not None:
            string_index, fret = self.practice_target_position
            target_positions = [(string_index, fret, self._position_label(string_index, fret))]
        elif self.ear_active and self.ear_hide_target:
            target_positions = []
        elif self.ear_active and self.ear_combo_enabled and self.ear_combo_sequence:
            bright = QtGui.QColor("#3ddc84")
            soft = QtGui.QColor("#9ac9b0")
            target_positions = []
            for i, pos in enumerate(self.ear_combo_positions):
                string_index, fret, label = pos
                color = bright if i == self.ear_combo_index else soft
                target_positions.append((string_index, fret, label, color))
        elif self.scale_active and self.scale_box_enabled and target_midi is not None:
            target_positions = [
                (s, f, self._position_label(s, f))
                for s, f in self._note_positions(target_midi)
                if self.scale_box_low <= f <= self.scale_box_high
            ]
        elif self.arpeggio_active and self.arpeggio_box_enabled and target_midi is not None:
            target_positions = [
                (s, f, self._position_label(s, f))
                for s, f in self._note_positions(target_midi)
                if self.arpeggio_box_low <= f <= self.arpeggio_box_high
            ]
        else:
            target_positions = self._note_positions_labeled(target_midi) if target_midi is not None else []
        self.fretboard.set_state(self._current_tuning(), self.max_fret, current_positions, target_positions, self.show_note_labels)

    def _toggle_position_mode(self):
        self.practice_require_position = self.practice_position_check.isChecked()
        if self.practice_require_position:
            self.practice_mode_note.setText("Mode: Exact position (unique notes)")
        else:
            self.practice_mode_note.setText("Mode: Note only")
        if self.practice_active:
            self._new_practice_target()

    def _toggle_box_mode(self):
        self.practice_box_enabled = self.practice_box_check.isChecked()
        if self.practice_active:
            self._new_practice_target()

    def _set_box_range(self):
        low = min(self.practice_box_low_spin.value(), self.practice_box_high_spin.value())
        high = max(self.practice_box_low_spin.value(), self.practice_box_high_spin.value())
        self.practice_box_low = low
        self.practice_box_high = high
        self.practice_box_low_spin.blockSignals(True)
        self.practice_box_high_spin.blockSignals(True)
        self.practice_box_low_spin.setValue(low)
        self.practice_box_high_spin.setValue(high)
        self.practice_box_low_spin.blockSignals(False)
        self.practice_box_high_spin.blockSignals(False)
        if self.practice_active:
            self._new_practice_target()

    def _set_practice_string_lock(self):
        index = self.practice_string_lock.currentIndex()
        if index <= 0:
            self.practice_string_lock_index = None
        else:
            self.practice_string_lock_index = index - 1
        if self.practice_active:
            self._new_practice_target()

    def _refresh_practice_string_lock(self):
        if not hasattr(self, "practice_string_lock"):
            return
        self.practice_string_lock.blockSignals(True)
        self.practice_string_lock.clear()
        self.practice_string_lock.addItem("Any")
        for string_name, _ in self._current_tuning():
            self.practice_string_lock.addItem(string_name)
        self.practice_string_lock.setCurrentIndex(0)
        self.practice_string_lock_index = None
        self.practice_string_lock.blockSignals(False)
    def _toggle_practice(self):
        if self.practice_active:
            self._end_practice()
            self.practice_start_btn.setText("Start")
            self.practice_target.setText("Target: --")
        else:
            self.practice_active = True
            self.practice_score = 0
            self.practice_score_label.setText("Score: 0")
            self.practice_correct = 0
            self.practice_total_time = 0.0
            self.practice_stats_label.setText("Stats: --")
            self.practice_start_btn.setText("Stop")
            self.practice_end_time = time.time() + self.practice_duration_seconds
            self._new_practice_target()

    def _new_practice_target(self):
        positions = []
        tuning = self._current_tuning()
        note_set = self._selected_note_set()
        for string_index, (string_name, open_midi) in enumerate(tuning):
            if self.practice_string_lock_index is not None and string_index != self.practice_string_lock_index:
                continue
            for fret in range(0, self.max_fret + 1):
                midi = open_midi + fret
                if midi < MIN_MIDI:
                    continue
                label = f"{midi_to_name(midi)} ({string_name} fret {fret})"
                if self.practice_box_enabled:
                    if fret < self.practice_box_low or fret > self.practice_box_high:
                        continue
                if note_set is not None and midi not in note_set:
                    continue
                positions.append((midi, label, string_index, fret))
        if not positions:
            return
        if self.practice_require_position:
            unique_positions = []
            for midi, label, string_index, fret in positions:
                if len(self._note_positions(midi)) == 1:
                    unique_positions.append((midi, label, string_index, fret))
            if unique_positions:
                positions = unique_positions
            else:
                self.practice_mode_note.setText("Mode: Exact position (no unique notes, using note-only)")
        midi, label, string_index, fret = random.choice(positions)
        self.practice_target_midi = midi
        self.practice_target_label = label
        self.practice_target_position = (string_index, fret)
        self.practice_target.setText(f"Target: {label}")
        self.practice_grace_until = time.time() + self.practice_grace_seconds
        self.practice_target_started = time.time()
        self._update_fretboard(None)

    def _score_for_time(self, elapsed: float) -> int:
        if elapsed <= 0:
            return 10
        score = int(round(10.0 / max(0.4, elapsed)))
        return max(1, min(10, score))

    def _end_practice(self):
        if not self.practice_active:
            return
        self.practice_active = False
        self.practice_start_btn.setText("Start")
        self.practice_target.setText("Target: --")
        self.practice_end_time = None
        self._maybe_record_high_score()
        self._record_session()

    def _maybe_record_high_score(self):
        if self.practice_score <= 0:
            return
        self.high_scores.append(self.practice_score)
        self.high_scores = sorted(self.high_scores, reverse=True)[:10]
        self._save_scores()
        self.practice_high_scores.setText(self._high_scores_text())

    def _history_path(self):
        return os.path.join(os.path.dirname(__file__), "history.json")

    def _load_history(self):
        path = self._history_path()
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
        except Exception:
            pass
        return []

    def _sets_path(self):
        return os.path.join(os.path.dirname(__file__), "sets.json")

    def _load_sets(self):
        path = self._sets_path()
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                cleaned = {}
                for k, v in data.items():
                    if not isinstance(v, list):
                        continue
                    notes = [int(x) for x in v if isinstance(x, (int, float)) and int(x) >= MIN_MIDI]
                    if notes:
                        cleaned[k] = notes
                return cleaned
        except Exception:
            pass
        return {}

    def _save_sets(self):
        path = self._sets_path()
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.practice_sets, f)
        except Exception:
            pass

    def _save_history(self):
        path = self._history_path()
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.practice_history, f)
        except Exception:
            pass

    def _record_session(self):
        if self.practice_end_time is not None:
            return
        if self.practice_correct <= 0:
            return
        avg_time = self.practice_total_time / max(1, self.practice_correct)
        entry = {
            "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "score": int(self.practice_score),
            "correct": int(self.practice_correct),
            "avg_time": round(avg_time, 2),
        }
        self.practice_history.append(entry)
        self.practice_history = self.practice_history[-10:]
        self._save_history()
        self.practice_history_label.setText(self._history_text())

    def _history_text(self):
        if not self.practice_history:
            return "History: --"
        lines = []
        for entry in reversed(self.practice_history):
            lines.append(
                f"{entry.get('time','--')} | score {entry.get('score','--')} | "
                f"{entry.get('correct','--')} notes | avg {entry.get('avg_time','--')}s"
            )
        return "History:\n" + "\n".join(lines)

    def _scores_path(self):
        return os.path.join(os.path.dirname(__file__), "scores.json")

    def _load_scores(self):
        path = self._scores_path()
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return [int(x) for x in data if isinstance(x, (int, float))]
        except Exception:
            pass
        return []

    def _save_scores(self):
        path = self._scores_path()
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.high_scores, f)
        except Exception:
            pass

    def _high_scores_text(self):
        if not self.high_scores:
            return "High Scores: --"
        scores = ", ".join(str(s) for s in self.high_scores)
        return f"High Scores: {scores}"

    def _toggle_scale(self):
        if self.scale_active:
            self.scale_active = False
            self.scale_start_btn.setText("Start Scale")
            self.scale_target.setText("Target: --")
            self.scale_progress.setText("Progress: --")
            self._update_fretboard(None)
        else:
            root = self.scale_root.currentText()
            octave = int(self.scale_octave.currentText())
            root_midi = clamp_min_midi(name_to_midi(f"{root}{octave}"))
            scale = MAJOR_SCALE if self.scale_type.currentText() == "Major" else NATURAL_MINOR_SCALE
            self.scale_notes = [root_midi + step for step in scale]
            self.scale_index = 0
            self.scale_active = True
            self.scale_start_btn.setText("Stop Scale")
            self._update_scale_target()

    def _update_scale_target(self):
        if not self.scale_active:
            return
        while self.scale_index < len(self.scale_notes):
            midi = self.scale_notes[self.scale_index]
            if not self.scale_box_enabled:
                break
            positions = self._note_positions(midi)
            if any(self.scale_box_low <= fret <= self.scale_box_high for _, fret in positions):
                break
            self.scale_index += 1
        if self.scale_index >= len(self.scale_notes):
            self.scale_target.setText("Target: done!")
            self.scale_progress.setText("Progress: complete")
            self.scale_active = False
            self.scale_start_btn.setText("Start Scale")
            self._update_fretboard(None)
            return
        midi = self.scale_notes[self.scale_index]
        self.scale_target.setText(f"Target: {midi_to_name(midi)}")
        self.scale_progress.setText(f"Progress: {self.scale_index + 1}/{len(self.scale_notes)}")
        self._update_fretboard(None)

    def _toggle_interval(self):
        if self.interval_active:
            self.interval_active = False
            self.interval_start_btn.setText("Start Interval")
            self.interval_target.setText("Target: --")
            self.interval_target_midi = None
            self._update_fretboard(None)
        else:
            self.interval_active = True
            self.interval_start_btn.setText("Stop Interval")
            self._new_interval_target()

    def _new_interval_target(self):
        if self.interval_random:
            octave = random.choice([1, 2, 3, 4, 5])
            if octave == 1:
                root = random.choice(["E", "F", "F#", "G", "G#", "A", "A#", "B"])
            else:
                root = random.choice(NOTE_NAMES)
            interval_name, interval_semitones = random.choice(INTERVALS)
        else:
            root = self.interval_root.currentText()
            octave = int(self.interval_octave.currentText())
            interval_name, interval_semitones = INTERVALS[self.interval_type.currentIndex()]
        root_midi = clamp_min_midi(name_to_midi(f"{root}{octave}"))
        target_midi = root_midi + interval_semitones
        self.interval_target_midi = target_midi
        self.interval_label = f"{root}{octave} + {interval_name} = {midi_to_name(target_midi)}"
        self.interval_target.setText(f"Target: {self.interval_label}")
        self._update_fretboard(None)

    def _toggle_arpeggio(self):
        if self.arpeggio_active:
            self.arpeggio_active = False
            self.arpeggio_start_btn.setText("Start Arpeggio")
            self.arpeggio_target.setText("Target: --")
            self.arpeggio_progress.setText("Progress: --")
            self._update_fretboard(None)
        else:
            root = self.arpeggio_root.currentText()
            octave = int(self.arpeggio_octave.currentText())
            root_midi = clamp_min_midi(name_to_midi(f"{root}{octave}"))
            pattern = ARPEGGIOS[self.arpeggio_type.currentText()]
            self.arpeggio_notes = [root_midi + step for step in pattern]
            self.arpeggio_index = 0
            self.arpeggio_active = True
            self.arpeggio_start_btn.setText("Stop Arpeggio")
            self._update_arpeggio_target()

    def _update_arpeggio_target(self):
        if not self.arpeggio_active:
            return
        while self.arpeggio_index < len(self.arpeggio_notes):
            midi = self.arpeggio_notes[self.arpeggio_index]
            if not self.arpeggio_box_enabled:
                break
            positions = self._note_positions(midi)
            if any(self.arpeggio_box_low <= fret <= self.arpeggio_box_high for _, fret in positions):
                break
            self.arpeggio_index += 1
        if self.arpeggio_index >= len(self.arpeggio_notes):
            self.arpeggio_target.setText("Target: done!")
            self.arpeggio_progress.setText("Progress: complete")
            self.arpeggio_active = False
            self.arpeggio_start_btn.setText("Start Arpeggio")
            self._update_fretboard(None)
            return
        midi = self.arpeggio_notes[self.arpeggio_index]
        self.arpeggio_target.setText(f"Target: {midi_to_name(midi)}")
        self.arpeggio_progress.setText(f"Progress: {self.arpeggio_index + 1}/{len(self.arpeggio_notes)}")
        self._update_fretboard(None)

    def _vocal_note_pool(self):
        low = min(self.vocal_range_low, self.vocal_range_high)
        high = max(self.vocal_range_low, self.vocal_range_high)
        if high - low < 3:
            high = low + 3
        return list(range(low, high + 1))

    def _set_vocal_range_low(self):
        try:
            self.vocal_range_low = name_to_midi(
                f"{self.vocal_low_note.currentText()}{self.vocal_low_octave.currentText()}"
            )
        except Exception:
            return
        if self.vocal_active and self.vocal_target_midi is not None:
            low = min(self.vocal_range_low, self.vocal_range_high)
            high = max(self.vocal_range_low, self.vocal_range_high)
            if self.vocal_target_midi < low or self.vocal_target_midi > high:
                self._new_vocal_target()

    def _set_vocal_range_high(self):
        try:
            self.vocal_range_high = name_to_midi(
                f"{self.vocal_high_note.currentText()}{self.vocal_high_octave.currentText()}"
            )
        except Exception:
            return
        if self.vocal_active and self.vocal_target_midi is not None:
            low = min(self.vocal_range_low, self.vocal_range_high)
            high = max(self.vocal_range_low, self.vocal_range_high)
            if self.vocal_target_midi < low or self.vocal_target_midi > high:
                self._new_vocal_target()

    def _new_vocal_target(self):
        pool = self._vocal_note_pool()
        if not pool:
            self.vocal_target_midi = None
            self.vocal_target_label.setText("Target: --")
            return
        self.vocal_target_midi = random.choice(pool)
        self.vocal_target_label.setText(f"Target: {midi_to_name(self.vocal_target_midi)}")
        if self.vocal_active:
            self.vocal_feedback_label.setText("Feedback: match the target note")

    def _toggle_vocal_training(self):
        if self.vocal_active:
            self.vocal_active = False
            self.vocal_start_btn.setText("Start Vocal Training")
            self.vocal_target_midi = None
            self.vocal_target_label.setText("Target: --")
            self.vocal_feedback_label.setText("Feedback: --")
            self.vocal_current_label.setText("Current: --")
            self.vocal_graph.clear()
            if self._vocal_prev_pitch_bounds is not None:
                self.engine.fmin, self.engine.fmax = self._vocal_prev_pitch_bounds
                self._vocal_prev_pitch_bounds = None
            return

        self.vocal_active = True
        self.vocal_score = 0
        self.vocal_cooldown_until = 0.0
        self.vocal_score_label.setText("Score: 0")
        self.vocal_feedback_label.setText("Feedback: match the target note")
        self.vocal_start_btn.setText("Stop Vocal Training")
        self.vocal_graph.clear()
        self._vocal_prev_pitch_bounds = (self.engine.fmin, self.engine.fmax)
        self.engine.fmin = 70.0
        self.engine.fmax = 1400.0
        self._new_vocal_target()

    def _calibrate(self):
        if self.engine.last_freq is None:
            return
        target_name = self.calib_note.currentText()
        target_midi = name_to_midi(target_name)
        midi_raw = 69 + 12 * math.log2(self.engine.last_freq / 440.0)
        offset_cents = (midi_raw - target_midi) * 100.0
        self.engine.cents_offset = offset_cents
        self.calib_status.setText(f"Calibration offset: {offset_cents:.1f} cents")

    def _reset_calibration(self):
        self.engine.cents_offset = 0.0
        self.calib_status.setText("Calibration offset: 0.0 cents")

    def _update_ui(self):
        freq = self.engine.last_freq
        self.live_rms.setText(f"Level: {self.engine.last_rms:.3f}")
        self.live_conf.setText(f"Conf: {self.engine.last_confidence:.2f}")
        if self.song_audio_start is not None:
            elapsed = time.time() - self.song_audio_start
            # Keep timing simple: use audio time + manual offset only.
            elapsed += self.song_offset_ms / 1000.0
            self.song_fretboard.set_progress(elapsed)
            if hasattr(self, "tab_view"):
                self.tab_view.set_progress(elapsed)
        if freq is None:
            if hasattr(self, "vocal_graph"):
                self.vocal_graph.push_point(None)
            self.live_note.setText("--")
            self.live_freq.setText("Hz: --")
            self.live_cents.setText("Cents: --")
            self.positions_label.setText("Positions: --")
            self.tuner_meter.setValue(0)
            self.tuner_status.setText("Status: --")
            self._tuner_samples.clear()
            self._update_fretboard(None)
            if hasattr(self, "vocal_current_label"):
                self.vocal_current_label.setText("Current: --")
            if self.practice_active:
                self._update_practice_timer()
            return

        midi = self.engine.last_midi
        cents = self.engine.last_cents
        note = self.engine.last_note

        self.live_note.setText(note)
        self.live_freq.setText(f"Hz: {freq:.1f}")
        self.live_cents.setText(f"Cents: {cents:+.1f}")
        if hasattr(self, "vocal_graph"):
            self.vocal_graph.push_point(float(midi) + (float(cents) / 100.0))
        if hasattr(self, "vocal_current_label"):
            self.vocal_current_label.setText(f"Current: {note} ({cents:+.1f} cents)")

        positions_text = self._note_positions_text(midi)
        if positions_text:
            self.positions_label.setText("Positions: " + ", ".join(positions_text))
        else:
            self.positions_label.setText("Positions: out of range")
        self._update_fretboard(midi)

        now = time.time()
        if self.practice_active and now >= self.practice_cooldown_until:
            if now < self.practice_grace_until:
                pass
            elif abs(cents) <= 25:
                if midi == self.practice_target_midi:
                    elapsed = now - self.practice_target_started
                    points = self._score_for_time(elapsed)
                    self.practice_score += points
                    self.practice_correct += 1
                    self.practice_total_time += elapsed
                    self.practice_score_label.setText(f"Score: {self.practice_score}")
                    avg_time = self.practice_total_time / max(1, self.practice_correct)
                    self.practice_stats_label.setText(
                        f"Stats: {self.practice_correct} notes | avg {avg_time:.2f}s"
                    )
                    self.practice_cooldown_until = now + 0.6
                    self._new_practice_target()

        if self.practice_active:
            self._update_practice_timer()

        if self.scale_active and now >= self.scale_cooldown_until:
            if abs(cents) <= 25 and self.scale_index < len(self.scale_notes):
                if midi == self.scale_notes[self.scale_index]:
                    self.scale_index += 1
                    self.scale_cooldown_until = now + 0.6
                    self._update_scale_target()

        if self.interval_active and now >= self.interval_cooldown_until:
            if abs(cents) <= 25 and midi == self.interval_target_midi:
                self.interval_cooldown_until = now + 0.6
                self._new_interval_target()

        if self.arpeggio_active and now >= self.arpeggio_cooldown_until:
            if abs(cents) <= 25 and self.arpeggio_index < len(self.arpeggio_notes):
                if midi == self.arpeggio_notes[self.arpeggio_index]:
                    self.arpeggio_index += 1
                    self.arpeggio_cooldown_until = now + 0.6
                    self._update_arpeggio_target()

        if self.ear_active and now >= self.ear_cooldown_until:
            if self.ear_combo_enabled and self.ear_combo_sequence:
                current = self.ear_combo_sequence[self.ear_combo_index]
                prev = None
                if self.ear_combo_index > 0:
                    prev = self.ear_combo_sequence[self.ear_combo_index - 1]
                current_freq = midi_to_freq(current)
                combo_cents_tol = 25.0
                if current_freq < 55.0:
                    combo_cents_tol = 45.0
                elif current_freq < 70.0:
                    combo_cents_tol = 35.0
                if now < self.ear_combo_grace_until:
                    pass
                elif abs(cents) <= combo_cents_tol:
                    if (
                        self.ear_combo_last_midi == midi
                        and now - self.ear_combo_last_match_time < 0.25
                    ):
                        pass
                    else:
                        self.ear_combo_last_midi = midi
                        self.ear_combo_last_match_time = now
                        self.ear_combo_grace_until = now + 0.35
                    self.ear_combo_attempted_notes = min(
                        len(self.ear_combo_sequence),
                        self.ear_combo_attempted_notes + 1,
                    )
                    if midi == current:
                        # Debounce advancing if the same note is still ringing.
                        if now - self.ear_combo_last_advance_time < 0.35:
                            pass
                        else:
                            self.ear_combo_last_advance_time = now
                            self.ear_combo_index += 1
                            if self.ear_combo_index >= len(self.ear_combo_sequence):
                                self.ear_score += 1
                                self.ear_score_label.setText(f"Score: {self.ear_score}")
                                self.ear_feedback_label.setText("Feedback: correct!")
                                self.ear_cooldown_until = now + 0.6
                                self._new_ear_target(play_tone=True)
                            else:
                                self.ear_feedback_label.setText("Feedback: good, next note")
                                self._update_ear_label()
                                self._update_fretboard(self.engine.last_midi)
                    elif prev is not None and midi == prev:
                        # Allow the previous note to keep ringing without resetting.
                        pass
                    else:
                        self.ear_feedback_label.setText("Feedback: wrong note, start over")
                        self.ear_combo_index = 0
                        self._update_ear_label()
                        self._update_fretboard(self.engine.last_midi)
                elif (
                    self.ear_repeat_seconds > 0
                    and self.ear_combo_attempted_notes >= len(self.ear_combo_sequence)
                    and now - self.ear_last_play >= self.ear_repeat_seconds
                ):
                    self.ear_feedback_label.setText("Feedback: replaying target")
                    self._play_ear_tone()
            else:
                if abs(cents) <= 25 and midi == self.ear_target_midi:
                    self.ear_score += 1
                    self.ear_score_label.setText(f"Score: {self.ear_score}")
                    self.ear_feedback_label.setText("Feedback: correct!")
                    if self.ear_sr_enabled:
                        self._ear_sr_mark(self.ear_target_midi, True)
                    self.ear_cooldown_until = now + 0.6
                    self._new_ear_target(play_tone=True)
                elif abs(cents) <= 25 and midi != self.ear_target_midi:
                    self.ear_feedback_label.setText("Feedback: wrong note, try again")
                    if self.ear_sr_enabled:
                        self._ear_sr_mark(self.ear_target_midi, False)
                    self.ear_cooldown_until = now + 0.3
                elif (
                    self.ear_target_midi is not None
                    and self.ear_repeat_seconds > 0
                    and now - self.ear_last_play >= self.ear_repeat_seconds
                ):
                    self.ear_feedback_label.setText("Feedback: replaying target")
                    self._play_ear_tone()

        if self.vocal_active and now >= self.vocal_cooldown_until and self.vocal_target_midi is not None:
            if abs(cents) <= 30 and midi == self.vocal_target_midi:
                self.vocal_score += 1
                self.vocal_score_label.setText(f"Score: {self.vocal_score}")
                self.vocal_feedback_label.setText("Feedback: matched!")
                self.vocal_cooldown_until = now + 0.6
                self._new_vocal_target()
            elif abs(cents) <= 35 and midi != self.vocal_target_midi:
                self.vocal_feedback_label.setText("Feedback: close, wrong note")
                self.vocal_cooldown_until = now + 0.25

        if self.chord_active:
            now = time.time()
            if now - self.chord_last_time >= self.chord_interval:
                self.chord_last_time = now
                if self.engine.last_rms < max(self.engine.min_rms * 1.2, 0.002):
                    self.chord_label.setText("Chord: --")
                    self.chord_conf_label.setText("Confidence: --")
                else:
                    audio = self.engine.get_buffer()
                    try:
                        if audio.size < 2048:
                            raise ValueError("Audio too short for chord analysis")
                        if audio.size < 4096:
                            audio = librosa.util.fix_length(audio, size=4096)
                        n_fft = 2048
                        hop = 512
                        chroma = librosa.feature.chroma_stft(
                            y=audio.astype(np.float32),
                            sr=self.engine.samplerate,
                            n_fft=n_fft,
                            hop_length=hop,
                            n_chroma=12,
                        )
                        chroma_vec = np.mean(chroma, axis=1)
                        chroma_vec = normalize_chroma(chroma_vec)
                        self.chord_smoothed = (
                            self.chord_smooth_alpha * self.chord_smoothed
                            + (1.0 - self.chord_smooth_alpha) * chroma_vec
                        )
                        best_label = None
                        best_score = 0.0
                        for label, template in self.chord_templates.items():
                            score = float(np.dot(self.chord_smoothed, normalize_chroma(template)))
                            if score > best_score:
                                best_score = score
                                best_label = label
                        if best_label is not None and best_score >= self.chord_conf_threshold:
                            self.chord_label.setText(f"Chord: {best_label}")
                            self.chord_conf_label.setText(f"Confidence: {best_score:.2f}")
                        else:
                            self.chord_label.setText("Chord: --")
                            self.chord_conf_label.setText(f"Confidence: {best_score:.2f}")
                    except Exception:
                        self.chord_label.setText("Chord: --")
                        self.chord_conf_label.setText("Confidence: --")

        now = time.time()
        self._tuner_samples.append((now, cents))
        while self._tuner_samples and now - self._tuner_samples[0][0] > self.tuner_window_seconds:
            self._tuner_samples.popleft()
        if self._tuner_samples:
            avg_cents = sum(c for _, c in self._tuner_samples) / len(self._tuner_samples)
        else:
            avg_cents = cents

        meter_cents = max(-50.0, min(50.0, avg_cents))
        self.tuner_meter.setValue(int(round(meter_cents)))
        if abs(avg_cents) <= 5.0:
            self.tuner_status.setText("Status: In tune")
        elif avg_cents < 0:
            self.tuner_status.setText("Status: Flat (too low)")
        else:
            self.tuner_status.setText("Status: Sharp (too high)")

    def _update_practice_timer(self):
        if self.practice_end_time is None:
            return
        remaining = self.practice_end_time - time.time()
        if remaining <= 0:
            self.practice_timer_label.setText("Time: 0.0s")
            self._end_practice()
        else:
            self.practice_timer_label.setText(f"Time: {remaining:.1f}s")


if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    app.setStyle(ArrowSpinStyle())
    window = MainWindow()
    window.show()
    app.exec()
