# BassProgram

A simple desktop practice tool for bass (or guitar) that listens to your audio input and helps with fretboard notes and scales.

## Features (prototype)
- Live pitch detection with note and cents offset
- Random note practice with scoring
- Major / minor scale practice
- Tuning view and calibration offset
- Basic string/fret position hints

## Setup
1. Install Python 3.10+
2. Install dependencies:
   python -m pip install -r requirements.txt
3. Run:
   python main.py

## Notes
- Low-latency audio on Windows usually works best with ASIO drivers. The app currently uses the default Windows audio device via `sounddevice`.
- String/fret detection is *not unique* from pitch alone. The app shows possible positions; it does not guarantee the exact string/fret unless you constrain your position.

If you want improvements, tell me and we can extend it.
